import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import routing
import urllib
import requests
import json

from xbmcaddon import Addon
from lib.broadcaster_result import BroadcasterResult
from lib.install import install, installInputStreamAdaptive, installWidevine
from lib import logger, config, utils, player

plugin = routing.Plugin()

####
# Starting point: the first page appearing to User
####
@plugin.route("/")
def start():
    handle = plugin.handle
    utils.checkSettings()
    config.cleaunUpSettings()

    # Compose "MAKER" listitem
    utils.addMenuItem(handle, 30010, plugin.url_for(maker), icon="compose")

    # Compose "SWITCHER" listitem
    utils.addMenuItem(handle, 30002, plugin.url_for(switch), icon="list")

    # Compose "Internal TV" listitem
    if config.getSetting("internalListNavigation") == True:
        utils.addMenuItem(handle, 30177, plugin.url_for(wltvlist), icon="tv")

    # Compose "Internationals TV" listitem
    utils.addMenuItem(handle, 30126, plugin.url_for(worldtv), icon="globe")

    # Compose "United Music Radio" listitem
    utils.addMenuItem(handle, 30127, plugin.url_for(unitedmusic), icon="unitedmusic_xs", thumb="unitedmusic", fanart="unitedmusic")

    # Compose "International Radios" listitem
    utils.addMenuItem(handle, 30159, plugin.url_for(worldradio), icon="globe")

    # Compose "SkyLine WebCam" listitem
    utils.addMenuItem(handle, 30128, plugin.url_for(skylinewebcams), icon="webcam")

    # Compose "YouTube Music & Karaoke" listitem
    utils.addMenuItem(handle, 30149, plugin.url_for(youtubemusic), icon="youtube")

    # Compose "Player List VOD Manager" listitem
    utils.addMenuItem(handle, 30141, plugin.url_for(listvodmanager), icon="compose")

    # Compose "SETTINGS" listitem
    utils.addMenuItem(handle, 30003, plugin.url_for(setting), icon="settings")

    # Compose "SEND LOG" listitem
    utils.addMenuItem(handle, 30122, plugin.url_for(uploadLog), icon="log", isFolder=False)

    # Compose "FORCE UPDATE"
    strMsg = utils.getCurrentVersionAndHotfixString()
    utils.addMenuItem(handle, strMsg, plugin.url_for(forceCheckUpdate), icon="log", isFolder=False)

    xbmcplugin.endOfDirectory(handle=handle, succeeded=True)


####
# Open Internals TV section
###
@plugin.route("/wltvlist")
@plugin.route("/wltvlist/<code>")
def wltvlist(code=""):
    from lib import wltvlist
    wltvlist


####
# Open UnitedMusic
###
@plugin.route("/unitedmusic")
@plugin.route("/unitedmusic/showstations/<name>/<code>")
def unitedmusic(name="", code=""):
    from lib import unitedmusic
    unitedmusic


####
# Open Internationals TV section
###
@plugin.route("/worldtv")
@plugin.route("/worldtv/showcountries/<continentcode>")
@plugin.route("/worldtv/switchlist/<name>/<code>")
def worldtv(continentcode="", name="", code=""):
    from lib import worldtv
    worldtv


####
# Open Internationals Radios section
###
@plugin.route("/worldradio")
@plugin.route("/worldradio/showcities/<countrycode>")
@plugin.route("/worldradio/showradios/<countrycode>/<citycode>")
def worldradio(countrycode="", citycode=""):
    from lib import worldradio
    worldradio


####
# Open SkyLineWebCams
###
@plugin.route("/skylinewebcams")
@plugin.route("/skylinewebcams/showcountries/<continentcode>")
@plugin.route("/skylinewebcams/showregion/<continentcode>/<countrycode>")
@plugin.route("/skylinewebcams/showcities/<continentcode>/<countrycode>/<regioncode>")
@plugin.route("/skylinewebcams/showwebcams/<continentcode>/<countrycode>/<regioncode>/<citycode>")
def skylinewebcams(continentcode="",countrycode="",regioncode="",citycode=""):
    from lib import skylinewebcams
    skylinewebcams


####
# Open YouTube Music & Karaoke
###
@plugin.route("/youtubemusic")
@plugin.route("/youtubemusic/showchannels/<group>")
@plugin.route("/youtubemusic/showvideos/<name>/<code>")
def youtubemusic(name="",code="",group=""):
    from lib import youtubemusic
    youtubemusic


####
# Open Player List VOD Manager
###
@plugin.route("/vodmanager")
@plugin.route("/vodmanager/showchoice/<itemId>")
@plugin.route("/vodmanager/showchoice/<itemId>/<streamType>")
@plugin.route("/vodmanager/showgroups/<itemId>/<streamType>/<subGroup>/<searchType>")
@plugin.route("/vodmanager/showgroups/<itemId>/<streamType>/<subGroup>/<searchType>/<txtSearch>")
@plugin.route("/vodmanager/globalsearch/<streamType>")
@plugin.route("/vodmanager/showsearch/<itemId>/<streamType>")
@plugin.route("/vodmanager/showfiltered/<itemId>/<streamType>/<subGroup>/<txtSearch>/<isUserSearch>")
def listvodmanager(itemId="", streamType="", subGroup="", searchType="", txtSearch="", isUserSearch=False):
    from lib import listvodmanager
    listvodmanager


####
# Start playing importing broadcaster module
####
@plugin.route("/play/<broadcaster>/<channel>")
def play(broadcaster, channel): #, userAgent=None):
    player.play(broadcaster, channel)
    ## import broadcaster and start playing
    #c = __import__("broadcaster." + broadcaster, None, None, ["broadcaster." + broadcaster])
    #res = c.play(channel)

    ## NOTE: user_agent WON'T be used in this way!
    ## it causes error in case of broadcaster!
    #if res.PlayableMediaItems:
    #    utils.createPlayableMediaListItemsMenu(plugin.handle, "", True, res.PlayableMediaItems)
    #else:
    #    player.makeListItemToPlay(res)

####
# Start playing importing broadcaster module
####
@plugin.route("/play/yt/<chtype>/<id>")
@plugin.route("/play/yt/<chtype>/<id>/<chname>")
def playYT(chtype, id, chname=""):
    # import broadcaster and start playing
    c = __import__("broadcaster.yt", None, None, ["broadcaster.yt"])
    res = c.play(chtype,id,chname)
    player.makeListItemToPlay(res)


@plugin.route("/play/<broadcaster>/<channel>/<listName>/<groupId>/<channelId>")
def playFromTvChannels(broadcaster, channel, listName, groupId, channelId):
    userAgent = None
    userAgentIdx = channelId.find("|User")
    if userAgentIdx > -1:
        logger.debug(f"{channelId} has user agent! Removing")
        userAgent = channelId[userAgentIdx + 1:]  # get the UA removing `|`
        channelId = channelId[0:userAgentIdx]
        logger.debug("UserAgent is:", userAgent)

    logger.debug(f'Requested channel for play: "{broadcaster}" "{channel}" "{listName}" "{groupId}" "{channelId}"')

    forceDirectLink = config.getSetting("forceDirectLink")

    hasBroadcaster = broadcaster != "none" and broadcaster != "none/none"

    logger.debug(f"Requested link hasBroadcaster: {hasBroadcaster} - forceDirectLink: {forceDirectLink}")

    if hasBroadcaster and not forceDirectLink:
        # forward request to `play()`
        play(broadcaster, channel) #, userAgent)
    else:
        logger.debug("No broadcaster requested or forceDirectLink, proceed with tvchannels")
        # no broadcaster has been requested: proceed forwarding request to tvchannels.
        # Use `list_name`, `group_id` and `chl_id`

        apiKeyParameter = utils.getApikeyParameter()
        url = f"{utils.API_DOMAIN}/{listName}/live?{apiKeyParameter}channel={channelId}&group={groupId}"
        logger.debug("The initial url is: ", url)

        finalUrl = check_url_redirect(url)
        logger.debug("The final url is: ", finalUrl)
        if not finalUrl:
            raise "No redirect url found"

        bdcRes = BroadcasterResult()
        bdcRes.Url = finalUrl

        player.makeListItemToPlay(bdcRes, userAgent)


@plugin.route("/webcam/<broadcaster>/<country>/<region>/<city>/<part>")
def playWebcam(broadcaster, country, region, city, part):
    linkWebCam = f"{country}/{region}/{city}/{part}"
    play(broadcaster, linkWebCam)


####
# Start installing additional/required addons
####
@plugin.route("/install")
def installDeps():
    install()


####
# Switch between iptv lists.
# This method compute the 'tvchannels-url' and put it into PVR Simple Client settings
####
@plugin.route("/switch")
def switch():
    from lib import switcher
    switcher


####
# Open the XML windows in order to compose a personal IPTV list (using 'tvchannels-merge' function)
###
@plugin.route("/maker")
def maker():
    from lib import userlistmaker
    userlistmaker.launch()


####
# Open addon's settings
####
@plugin.route("/settings")
def setting():
    config.openSettings()


####
# Open Input Helper addon's settings
####
@plugin.route("/openinputhelper")
def openInputStreamHelper():
    inputStreamHelper = Addon("script.module.inputstreamhelper")
    inputStreamHelper.openSettings()


####
# Cleanup cache files
####
@plugin.route("/cachecleanup")
def cacheCleanup():
    utils.cacheCleanup()


####
# Force check update
####
@plugin.route("/forcecheckupdate")
def forceCheckUpdate():
    utils.forceCheckUpdate()


####
# Force hotfix apply
####
@plugin.route("/forcehotfix")
def forceHotfix():
    utils.forceCheckUpdate(True)


####
# Send log file
####
@plugin.route("/uploadlog")
def uploadLog():
    logger.info(f"WLTV {utils.getCurrentVersionAndHotfixString()}")
    from lib import loguploader, listmanager
    repl = listmanager.getUserListUrls()
    loguploader.Main(repl)


#####
## Build a fake-listitem in order to set all details to make kodi simply playing
####
#def makeListItemToPlay(bdcRes: BroadcasterResult, userAgent: str = None):
#    if bdcRes:
#        # res = string
#        # or
#        # input = {'url':      required,
#        #          'manifestType': required only for inputstream, values mpd/hls,
#        #          'licenceKey':   optional, required for drm streams,
#        #          'licenceType':  optional, default 'com.widevine.alpha'}
#        #          'streamHeader': optional, streams header,

#        #bdcRes.ManifestType = 'mpd' if '.mpd' in bdcRes.Url else ''

#        xlistitem = None

#        if bdcRes.Url:
#            # make item
#            if userAgent:
#                logger.debug(f"UserAgent will be appending: {userAgent}")
#                bdcRes.Url = f"{bdcRes.Url}|{userAgent}"

#            xlistitem = xbmcgui.ListItem(path=bdcRes.Url)
#            logger.debug("Playing: ", bdcRes.Url)

#        if not xlistitem:
#            logger.error("NO URL found for channel")
#            xbmcgui.Dialog().notification(config.getString(30000),config.getString(30123),xbmcgui.NOTIFICATION_WARNING)
#            return

#        if bdcRes.ManifestType:
#            installInputStreamAdaptive()  # Check if inputstream is installed otherwise install it

#            # add parameters for inputstream
#            xlistitem.setProperty("inputstream","inputstream.adaptive")
#            xlistitem.setProperty("inputstream.adaptive.manifest_type",bdcRes.ManifestType)
#            xlistitem.setMimeType("application/dash+xml" if bdcRes.ManifestType == "mpd" else "application/x-mpegURL")

#            if bdcRes.ManifestUpdateParameter:
#                xlistitem.setProperty("inputstream.adaptive.manifest_update_parameter",bdcRes.ManifestUpdateParameter)

#        if bdcRes.LicenseKey:
#            # add parameters for drm
#            installWidevine()
#            xlistitem.setProperty("inputstream.adaptive.license_key",  bdcRes.LicenseKey)
#            xlistitem.setProperty("inputstream.adaptive.license_type", bdcRes.LicenseType)

#        if bdcRes.StreamHeader:
#            xlistitem.setProperty("inputstream.adaptive.stream_headers",bdcRes.StreamHeader)

#        forceStopForSwitch = config.getSetting("forceStopForSwitch")

#        # Stop Video Before Playing (For underperforming devices)
#        if forceStopForSwitch:
#            logger.debug("force stop as per user settings")
#            xbmc.Player().stop()

#        bdcRes = None
#        # play item
#        xbmcplugin.setResolvedUrl(plugin.handle, True, xlistitem)


def check_url_redirect(url):
    resp = requests.get(url, allow_redirects=False)
    if resp.status_code > 299 and resp.status_code < 304:
        # redirect url
        redirect = resp.headers["Location"]
        if redirect.startswith("plugin://"):
            logger.debug("URL points to plugin, follow!")
            return redirect
    return url


# start router
utils.checkForUpdates()

plugin.run()
