# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

BASE_URL = "https://sportitalia.com/"

CHANNELS = {
    "sihd": "9",
    "calcio": "10",
    "live24": "11"
}

def play(search):
    res = BroadcasterResult
    url = ""

    api = f"{BASE_URL}video/getlivestreaminginevidence"
    if search in CHANNELS:
        chId = CHANNELS[search]
        headers, csrf = getHeaders(f"{BASE_URL}video/index")
        formdata = {"channel":chId, "_csrf": csrf}
        jsonData = requests.post(api, headers=headers, data=formdata, verify=False).json()
        url = jsonData["urlVideo"][0]["url"]

    if url:
        res.Url = url
        #res.ManifestType = "hls"

    return res

def getHeaders(url):
    headers = utils.getBrowserHeaders()
    response = requests.get(url, headers=headers, verify=False)

    csrf_token = scrapers.findSingleMatch(response.text, r'name="csrf-token" content="([^"]+)"')
    headers["content-type"] = "application/x-www-form-urlencoded;charset=UTF-8"
    headers["Referer"] = url
    headers["x-csrf-token"] = csrf_token
    headers["Cookie"] = '; '.join([x.name + '=' + x.value for x in response.cookies])

    return headers, csrf_token