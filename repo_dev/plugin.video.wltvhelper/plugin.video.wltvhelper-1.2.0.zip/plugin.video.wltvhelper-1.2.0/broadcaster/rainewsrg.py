# -*- coding: utf-8 -*-

import requests, json
from datetime import datetime
from lib import scrapers, config, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.rainews.it"

mpd = config.getSetting("mpd")


def play(search):
    res = BroadcasterResult()

    manifest = "mpd" if mpd else "hls"
    streamTypeLive = "mediaUri" if mpd else "m3u8"
    url = ""
    isLive = False

    data = requests.get("{}/tgr/{}/notiziari".format(HOST, search)).text
    strWashiContext = scrapers.findSingleMatch(data, r"WashiContext\s?=\s?(.*?);")

    isWashi = strWashiContext != ""

    if isWashi:
        strJson = json.loads(strWashiContext)
        strJson = strJson["itemToPlay"]
        isLive = strJson["data_type"] == "diretta"
        matchedUrl = strJson["content_url"]
    else:
        weekday = [1, 2, 3, 4, 5, 6, 0]
        today = datetime.now()
        date = today.date()
        dayNumber = weekday[today.weekday()]
        hour = today.hour * 60 + today.minute

        schedule = requests.get( HOST + "/dl/rai24/assets/json/palinsesto-tgr.json" ).json()

        for key, value in schedule.items():
            if (key == "TGR"):
                for v in value:
                    start = int(v["from"].split(":")[0]) * 60 + int(v["from"].split(":")[1])
                    end = int(v["to"].split(":")[0]) * 60 + int(v["to"].split(":")[1])
                    if start <= hour < end and ( "days" in v and dayNumber in v["days"] or "day" in v and v["day"] == date ):
                        isLive = True
                        break
                    if isLive:
                        break

    if isWashi:
        if isLive:
            url = requests.get(matchedUrl + "&output=47").json().get("video", [""])[0]
        else:
            url = requests.get(matchedUrl).url
    else:
        if isLive:
            data = requests.get("{}/tgr/{}/notiziari/index.html?/tgr/live.html".format(HOST, search)).text
            matchedUrl = scrapers.findSingleMatch(data, streamTypeLive + r'\s*:\s*"([^"]+)')
            if matchedUrl:
                url = (requests.get(matchedUrl + "&output=47").json().get("video", [""])[0])
                res.ManifestType = manifest

            else:
                isLive = False

        if not isLive:
            data = requests.get("{}/tgr/{}/notiziari/index.html?/tgr/rainews.html".format(HOST, search)).text
            url = scrapers.findSingleMatch(data, r'data-mediaurl="(.*?)"')
            #if url == "":
            #    url = scrapers.find_single_match(data, r'mediaUrl":"(.*?)"')
            url = requests.get(url).url

    res.Url = url

    return res
