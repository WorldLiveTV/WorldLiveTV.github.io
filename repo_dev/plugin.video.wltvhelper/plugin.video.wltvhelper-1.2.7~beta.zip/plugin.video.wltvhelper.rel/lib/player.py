# -*- coding: utf-8 -*-

import xbmcgui
import xbmc
import xbmcplugin
import routing

from lib.broadcaster_result import BroadcasterResult
from lib.install import install, installInputStreamAdaptive, installWidevine
from lib import logger, config, utils

plugin = routing.Plugin()

def play(broadcaster, channel): #, userAgent=None):
    # import broadcaster and start playing
    c = __import__("broadcaster." + broadcaster, None, None, ["broadcaster." + broadcaster])
    res = c.play(channel)

    # NOTE: user_agent WON'T be used in this way!
    # it causes error in case of broadcaster!
    if res.PlayableMediaItems:
        utils.createPlayableMediaListItemsMenu(plugin.handle, "", True, res.PlayableMediaItems)
    else:
        makeListItemToPlay(res)

####
# Build a fake-listitem in order to set all details to make kodi simply playing
###
def makeListItemToPlay(bdcRes: BroadcasterResult, userAgent: str = None):
    if bdcRes:
        # res = string
        # or
        # input = {'url':      required,
        #          'manifestType': required only for inputstream, values mpd/hls,
        #          'licenceKey':   optional, required for drm streams,
        #          'licenceType':  optional, default 'com.widevine.alpha'}
        #          'streamHeader': optional, streams header,

        #bdcRes.ManifestType = 'mpd' if '.mpd' in bdcRes.Url else ''

        xlistitem = None

        if bdcRes.Url:
            # make item
            if userAgent:
                logger.debug(f"UserAgent will be appending: {userAgent}")
                bdcRes.Url = f"{bdcRes.Url}|{userAgent}"

            xlistitem = xbmcgui.ListItem(path=bdcRes.Url)
            logger.debug("Playing: ", bdcRes.Url)

        if not xlistitem:
            logger.error("NO URL found for channel")
            xbmcgui.Dialog().notification(config.getString(30000),config.getString(30123),xbmcgui.NOTIFICATION_WARNING)
            return

        if bdcRes.ManifestType:
            installInputStreamAdaptive()  # Check if inputstream is installed otherwise install it

            # add parameters for inputstream
            xlistitem.setProperty("inputstream","inputstream.adaptive")
            xlistitem.setProperty("inputstream.adaptive.manifest_type",bdcRes.ManifestType)
            xlistitem.setMimeType("application/dash+xml" if bdcRes.ManifestType == "mpd" else "application/x-mpegURL")

            if bdcRes.ManifestUpdateParameter:
                xlistitem.setProperty("inputstream.adaptive.manifest_update_parameter",bdcRes.ManifestUpdateParameter)

        if bdcRes.LicenseKey:
            # add parameters for drm
            installWidevine()
            xlistitem.setProperty("inputstream.adaptive.license_key",  bdcRes.LicenseKey)
            xlistitem.setProperty("inputstream.adaptive.license_type", bdcRes.LicenseType)

        if bdcRes.StreamHeader:
            xlistitem.setProperty("inputstream.adaptive.stream_headers",bdcRes.StreamHeader)

        forceStopForSwitch = config.getSetting("forceStopForSwitch")

        # Stop Video Before Playing (For underperforming devices)
        if forceStopForSwitch:
            logger.debug("force stop as per user settings")
            xbmc.Player().stop()

        bdcRes = None
        # play item
        xbmcplugin.setResolvedUrl(plugin.handle, True, xlistitem)