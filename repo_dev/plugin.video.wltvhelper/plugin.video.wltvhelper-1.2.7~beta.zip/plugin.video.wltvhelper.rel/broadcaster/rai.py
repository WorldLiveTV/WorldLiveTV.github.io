# -*- coding: utf-8 -*-

import requests
from lib import logger
from lib.broadcaster_result import BroadcasterResult


def play(search):
    res = BroadcasterResult()

    url = ""
    reqUrl = "https://www.raiplay.it/dirette.json"
    json = requests.get(reqUrl).json()["contents"]

    for key in json:
        channel = key["channel"]
        if search == channel:
            url = key["video"]["content_url"]
            break

    if url:
        res.Url = requests.get(url+"&output=7").url if "relinkerServlet" in url else url

        if not ".mp4" in url:
            res.ManifestType = "hls"

    return res
