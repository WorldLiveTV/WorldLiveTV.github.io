#
# -*- coding: utf-8 -*-
#

import requests

from lib import scrapers
from lib.broadcaster_result import BroadcasterResult

# /vimeo/e$id
# /vimeo/v$id

def play(search):
    baseUrl = "https://vimeo.com"
    res = BroadcasterResult()
    url = ""

    sSplit = search.split("$")
    itemType = sSplit[0].lower()
    id = sSplit[1]
    videoId = ""
    
    if itemType == "e":
        videoId = getVideoId(baseUrl, id)
    else: 
        videoId = id
    
    if videoId:
        url = f"plugin://plugin.video.vimeo/play/?video_id={videoId}"
    
    if url:
        res.Url = url 

    return res

def getVideoId(baseUrl, eventId) -> str:
    videoId = ""
    pageUrl = f"{baseUrl}/event/{eventId}/embed/"
    
    data = requests.get(pageUrl).text
    if data:
        videoId = scrapers.findSingleMatch(data, r'data-clip-id="([^"]+)"')
        data = None

    return videoId
