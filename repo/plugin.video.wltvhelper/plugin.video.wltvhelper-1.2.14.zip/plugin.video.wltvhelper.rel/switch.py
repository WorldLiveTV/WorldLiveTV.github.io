import xbmc

if __name__ == '__main__':
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.wltvhelper/switch)")