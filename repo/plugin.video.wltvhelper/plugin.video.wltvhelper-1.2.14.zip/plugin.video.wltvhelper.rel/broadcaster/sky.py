# -*- coding: utf-8 -*-

import requests
from lib import utils
from lib.broadcaster_result import BroadcasterResult

SKY_HOST = "https://tg24.sky.it"

def play(search):
    res = BroadcasterResult()

    channels = {"Sky TG24": 1, "Cielo": 2, "TV8": 7, "Sport24": 4}

    url = ""
    if search in channels:
        requrl = "https://video.sky.it/api/v1/getLivestream?id={}".format(channels[search])
        data = requests.get(requrl, headers=utils.getBrowserHeaders(host=SKY_HOST)).json()
        if data.get("currentStatus", 0) == 1:
            url = data.get("streaming_url", "")

    if url:
        res.Url = url
        res.UseInputStreamAdaptive = True
        res.ManifestHeaders = utils.getBrowserHeaders(host=SKY_HOST)
        res.StreamHeaders = utils.getBrowserHeaders(host=SKY_HOST)

    return res
