# API

import json, requests
from lib import config

API_DOMAIN = 'http://tvchannels.worldlivetv.eu/tv'
EPG_URL = 'http://epg-guide.com/wltv.gz'

# import web_pdb;

RemoteLists = []

PARAM_LIST_NAME = 'personal_list'

def apiRequester(par=''):
    return requests.get(API_DOMAIN + par).json()


def getRemoteLists():
    res = apiRequester('/all.json')
    for l in res:
        if l['Enabled']:
            RemoteLists.append( transformListItem(l) )

    return RemoteLists


def transformListItem(item, official = True):
    return {
        'Name': item['Name'],
        'Choose': {},
        'Official': official
    }


def getPersonalLists():
    if not config.getSetting(PARAM_LIST_NAME):
        return []
    listDict = json.loads(config.getSetting(PARAM_LIST_NAME))
    if type(listDict) is str:
        try:
            listDict = json.loads(listDict)
        except:
            # TODO: print error or log?
            listDict = []
    return listDict


def computeListUrl(selectedList):
    selectedGroups = []
    if selectedList['Choose']:
        choosedLists = selectedList['Choose']
        for listKey in choosedLists:
            groups = choosedLists[ listKey ]
            queryGroups = []
            for group in groups:
                queryGroups.append( group )
            selectedGroups.append( '{}={}'.format(listKey, ','.join(queryGroups) ) )

    if len(selectedGroups) == 0:
        # user has selected a full list
        return '{}/{}/list.m3u8?'.format(API_DOMAIN, selectedList['Name'])
    else:
        return '{}/all/groups/merge.m3u8?{}'.format(API_DOMAIN, '&'.join(selectedGroups) )
