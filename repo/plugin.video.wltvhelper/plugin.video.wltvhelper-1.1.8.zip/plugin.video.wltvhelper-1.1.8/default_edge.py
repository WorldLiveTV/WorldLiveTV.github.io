# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# XBMC entry point
# ------------------------------------------------------------

import os, sys, xbmcgui, xbmcplugin

from lib.install import install
from lib import logger, config

PY3 = True if sys.version_info[0] >= 3 else False

if sys.argv[2] and 'play' in sys.argv[2]:
    sp = sys.argv[2].split('/')

    if sp[1] != 'none':
        broadcaster=sp[1]
        channel=sp[2]
        c = __import__('broadcaster.' + broadcaster, None, None, ['broadcaster.' + broadcaster])
        res = c.play(channel)
    else:
        listname = sp [3]
        group = sp[4]
        channel = sp[5]
        res = 'http://tvchannels.worldlivetv.eu/tv/{}/live?channel={}&group={}'.format(listname, channel, group)

    if res:
        # res = string
        # or 
        # res = {'url': required,
        #        'manifest': required only for inputstrama, values mpd/hls),
        #        'key': required for drm streams,
        #        'type': optional, default 'com.widevine.alpha'}
        if type(res) == dict:
            url = res.get('url','')
            Manifest = res.get('manifest','')
            Key = res.get('key','')
            Type = res.get('Type','com.widevine.alpha')
        else:
            url = res
            Manifest = 'mpd' if '.mpd' in url else ''
            Key = None

        logger.debug('Play: ', url)
        xlistitem = xbmcgui.ListItem(path=url)

        if Manifest:
            install()
            xlistitem.setProperty('inputstream' if PY3 else 'inputstreamaddon', 'inputstream.adaptive')
            xlistitem.setProperty('inputstream.adaptive.manifest_type', Manifest)
            xlistitem.setMimeType('application/dash+xml' if Manifest == 'mpd' else 'application/x-mpegURL')
        if Key:
            xlistitem.setProperty("inputstream.adaptive.license_key", Key)
            xlistitem.setProperty("inputstream.adaptive.license_type", Type)

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xlistitem)

elif sys.argv[2] and 'install' in sys.argv[2]:
    install()
elif sys.argv[2] and 'switch' in sys.argv[2]:
    from lib import switcher
    switcher
elif sys.argv[2] and 'maker' in sys.argv[2]:
    from lib import listmaker
    listmaker
elif sys.argv[2] and 'setting' in sys.argv[2]:
    config.openSettings()
else:
    handle = int(sys.argv[1])
    li = xbmcgui.ListItem(config.getString(30010))
    li.setArt({'icon': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'thumb': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'poster': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?maker', listitem=li, isFolder=True)
    li = xbmcgui.ListItem(config.getString(30002))
    li.setArt({'icon': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'thumb': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'poster': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
               'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?switch', listitem=li, isFolder=True)
    li = xbmcgui.ListItem(config.getString(30003))
    li.setArt({'icon': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
               'thumb': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
               'poster': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
               'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?setting', listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle=handle, succeeded=True)


