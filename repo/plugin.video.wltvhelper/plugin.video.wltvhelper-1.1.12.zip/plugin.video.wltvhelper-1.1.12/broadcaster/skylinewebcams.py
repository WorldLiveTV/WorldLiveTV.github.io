# -*- coding: utf-8 -*-

import requests
from lib import scrapers

BASE_URL='https://www.skylinewebcams.com/it/webcam/'
BASE_URL_STREAMS='https://hd-auth.skylinewebcams.com/'
def play(link_part):
    url=BASE_URL+link_part+'.html'
    data = requests.get(url).text
    m3u8 = scrapers.find_single_match(data, r'source:\'(live.m3u8\?.*?)\'')
    stream = BASE_URL_STREAMS+m3u8
    return stream
