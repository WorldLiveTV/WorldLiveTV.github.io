# -*- coding: utf-8 -*-

import requests, xbmcgui
from lib import config, utils, logger
from lib.broadcaster_result import BroadcasterResult
from broadcaster import rainewsrg

HOST = "https://www.raiplay.it"

def play(search):
    res = BroadcasterResult()
    url = ""

    try:
        url = play_hbbtv(search)
    except:
        url = play_raiplay(search)
    
    if url:
        jsonConfig = requests.get(f"{url}&output=62", headers=utils.getBrowserHeaders()).json()
        url = jsonConfig.get("video", [""])[0]
        res.Url = url

        res.ManifestType = "hls"
        if ".mpd" in url:
            res.ManifestType = "mpd"

    return res


def play_raiplay(search):
    url = ""
    reqUrl = "https://www.raiplay.it/dirette.json"
    jsonChannels = requests.get(reqUrl, headers=utils.getBrowserHeaders()).json()["contents"]

    for key in jsonChannels:
        channel = key["channel"]
        if search == channel:
            url = key["video"]["content_url"]
            break

    return url


def play_hbbtv(search):
    url = ""
    rai3config = config.getSetting("rai3config")

    items = items = getServices(search)

    service = list()
    if search == "Rai 3" and rainewsrg.isRai3NewsLive():
        service = next( iter( filter( lambda c: (c["dvbTriplet"] == rai3config), items["Service"] ) ) )
    else:
        service = items["Service"][0]
    
    if service:
        url = service.get("url", "")

    return url


def chooseRai3Region():
    rai3config = "0.0.300"
    try:
        items = getServices("Rai 3")
        items = items["Service"]

        suffix = "Rai 3 TGR "
        lst = list()
        li = xbmcgui.ListItem("Default HD")
        li.setProperties({"dvbTriplet": rai3config})
        lst.append(li)

        for x in items:
            if x["name"].startswith(suffix):
                title = x["name"].replace(suffix, "")
                li = xbmcgui.ListItem(title)
                li.setProperties({"dvbTriplet": x["dvbTriplet"]})
                lst.append(li)

        idx = xbmcgui.Dialog().select(f"Select your region", lst)
        if idx > 0:
            rai3config = lst[idx].getProperty("dvbTriplet")
    except:
        utils.MessageBox("An error occurs... pleas try later")

    config.setSetting("rai3config", rai3config)


def getServices(search):
    reqUrl = "https://www.replaytvmhp.rai.it/hbbtv/launcher/RemoteControl/resources/srvConfig.json"
    items = requests.get(reqUrl).json()["Configuration"]["Editors"]["Editor"]
    items = next( iter( filter( lambda c: (c["name"] == search), items ) ) )
    items = next( iter( filter( lambda s: (s["delivery"] == "3"), items["Services"] ) ) )
    return items