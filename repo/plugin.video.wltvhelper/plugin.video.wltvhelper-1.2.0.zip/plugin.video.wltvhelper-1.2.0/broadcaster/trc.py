# -*- coding: utf-8 -*-

import requests, json
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

CHANNELS = {
    "reggio": "https://www.reggionline.com/telereggio-streaming-diretta/",
    "modena": "https://www.modenaindiretta.it/trc-modena-streaming-diretta/",
    "bologna": "https://www.bolognaindiretta.it/trc-bologna-streaming-diretta/"
}

def play(search):
    res = BroadcasterResult()
    url = ""

    data = requests.get(CHANNELS[search.lower()]).text
    playerUrl = scrapers.findSingleMatch(data, r"iframe\sid=\"ls_embed.*?\"\ssrc=\"([^\?]+)")
    data = requests.get(playerUrl).text
    jsonStr = scrapers.findSingleMatch(data, r"window\.config\s?=\s?([^;]+);<")
    jsonData = json.loads(jsonStr)

    url = jsonData["event"]["stream_info"]["secure_m3u8_url"]
    
    if url:
        res.Url = url
        res.ManifestType = "hls"

    return res
