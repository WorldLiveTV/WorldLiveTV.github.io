# -*- coding: utf-8 -*-
# youtube channel & video broadcaster

#example: 
    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO",Abao a Tokyo1
    #   plugin://plugin.video.wltvhelper/play/yt/c/UC84whx2xxsiA1gXHXXqKGOA/videoname

    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO",VIDEO YT
    #   plugin://plugin.video.wltvhelper/play/yt/v/TbhcfUPYKEU/-

import json
import requests
from urllib.parse import unquote
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

def play(chtype:str,chId:str,chName:str):
    chName = unquote(chName)
    if chtype == "c":
        return playChannel(chId,chName)
    elif chtype == "v":
        return playVideo(chId)
    else:
        return playVideo(chId)


def playChannel(chId:str,chName:str):
    HOST = "https://www.youtube.com"
    videoInfoUrl = f"/channel/{chId}"

    videoId = ""
    chItems  = {}
    liveItems = []

    headers = utils.getBrowserHeaders();
    headers["Cookie"] ="YSC=uhMbKwwwD3g; CONSENT=YES+cb.20300101-18-p0.it+FX+133; GPS=1; VISITOR_INFO1_LIVE=NnmAzzluXtu; PREF=tz=Europe.Rome"

    data = requests.get(f"{HOST}{videoInfoUrl}", headers=headers).text 
    regex = r"ytInitialData\s?=\s?(.*?);<"
    jsonData = scrapers.findSingleMatch(data, regex)
    
    if not jsonData: #try with channelname
        videoInfoUrl = f"/c/{chId}"
        data = requests.get(f"{HOST}{videoInfoUrl}", headers=headers).text 
        regex = r"ytInitialData\s?=\s?(.*?);<"
        jsonData = scrapers.findSingleMatch(data, regex)

    jsonData = json.loads(jsonData)
    tabs = jsonData["contents"]["twoColumnBrowseResultsRenderer"]["tabs"]
    
    data = None
    jsonData = None

    for tab in tabs:
        if tab["tabRenderer"]["title"] == "Home":
            chItems = tab["tabRenderer"]["content"]["sectionListRenderer"]["contents"][0]["itemSectionRenderer"]["contents"][0].get("channelFeaturedContentRenderer", "")
            if chItems:
                liveItems = chItems["items"]
            break
    
    tab = None
    tabs = None
    chItems = None

    for liveItem in liveItems:
        title = liveItem["videoRenderer"]["title"]["runs"][0]["text"]
        if chName == '0' or chName.lower() in title.lower():
            videoId = liveItem["videoRenderer"]["videoId"]
            break
    
    return playVideo(videoId)


def playVideo(videoId):
    res = BroadcasterResult()
    url = ""

    if videoId:
        url = f"plugin://plugin.video.youtube/play/?video_id={videoId}"

    if url:
        res.Url = url

    return res
