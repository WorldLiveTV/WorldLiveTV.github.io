# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult


def play(search):
    res = BroadcasterResult()
    url = ""

    host = f"https://ssh101.com/securelive/index.php?id={search}"
    req = requests.get(host)
    data = req.text 
    url = scrapers.findSingleMatch(data, r"source\s?src=\"([^\"]+)")

    cookies = req.headers.get("Set-Cookie", "")
    phpSession = scrapers.findSingleMatch(cookies, r"PHPSESSID=([^;]+)")
    
    if url:
        res.Url = url
        res.ManifestType = "hls"
        res.LicenseType  = "com.widevine.alpha"
        res.LicenseKey   = f"|referer={host}&user-agent={utils.USER_AGENT}&cookie=PHPSESSID%3D{phpSession}"

    return res
