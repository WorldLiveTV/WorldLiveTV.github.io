# -*- coding: utf-8 -*-

import requests, uuid
from lib import config, utils, logger
from lib.broadcaster_result import BroadcasterResult

mpd = config.getSetting("mpd")

HOST = "https://discoveryplus.com"

#mpd = False  # temporaneamente disattivato per bug di IA

def play(search):
    res = BroadcasterResult()
    id = ""
    
    deviceId = uuid.uuid4().hex

    headers = {
        "User-Agent": utils.USER_AGENT,
        "Referer": HOST,
    }

    domain = requests.get("https://prod-realmservice.mercury.dnitv.com/realm-config/www.discoveryplus.com%2Fit%2Fepg", headers=headers).json()["domain"]
    token = requests.get(f"https://{domain}/token?deviceId={deviceId}&realm=dplay&shortlived=true", headers=headers).json()["data"]["attributes"]["token"]
    headers["Cookie"] = f"st={token}"
    chs = requests.get(f"https://{domain}/cms/routes/home?include=default&decorators=playbackAllowed", headers=headers).json()["included"]
    
    for key in chs:
        if (key["type"] == "channel"
            and key.get("attributes", {}).get("hasLiveStream", "")
            and "Free" in key.get("attributes", {}).get("packages", [])
            and search == key["attributes"]["channelCode"]):
            id = key["id"]
            break

    if id:
        postJsonData = f'{{"channelId": "{id}","deviceInfo": {{"adBlocker": false,"drmSupported": true}}}}'

        headers["content-type"] = "application/json"
        headers["x-disco-params"] = "realm=dplay,siteLookupKey=dplus_it"
        headers["Origin"] = HOST
        
        cookies = {"st": "token"}
        jsonData = requests.post(f"https://{domain}/playback/v3/channelPlaybackInfo", headers=headers, cookies=cookies, data=postJsonData).json()
        data = jsonData.get("data", {}).get("attributes", {}).get("streaming", {})

        if data[0]["protection"]["drmEnabled"] == True and mpd:
            res.Url = data["streaming"]["dash"]["url"]
            res.ManifestType = "mpd"
            res.LicenseKey = (
                data["protection"]["schemes"]["widevine"]["licenseUrl"]
                + "|PreAuthorization="
                + data["protection"]["drmToken"]
                + "|R{SSM}|"
            )
            res.LicenseType = "com.widevine.alpha"
        else:
            res.Url = data[0]["url"]
            res.ManifestType = "hls"

    return res
