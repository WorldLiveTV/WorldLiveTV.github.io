# -*- coding: utf-8 -*-

import requests
from lib import logger
from lib.broadcaster_result import BroadcasterResult


def play(search):
    res = BroadcasterResult()
    url = ""

    try:
        url = play_hbbtv(search)
    except :
        url = play_raiplay(search)
    
    if url:
        res.Url = requests.get(url+"&output=7").url if "relinkerServlet" in url else url

        if not ".mp4" in url:
            res.ManifestType = "hls"

    return res


def play_raiplay(search):
    url = ""
    reqUrl = "https://www.raiplay.it/dirette.json"
    jsonChannels = requests.get(reqUrl).json()["contents"]

    for key in jsonChannels:
        channel = key["channel"]
        if search == channel:
            url = key["video"]["content_url"]
            break

    return url


def play_hbbtv(search):
    url = ""
    reqUrl = "http://www.replaytvmhp.rai.it/hbbtv/launcher/RemoteControl/resources/srvConfig.json"
    items = requests.get(reqUrl).json()["Configuration"]["Editors"]["Editor"]
    
    items = next( iter( filter( lambda c: (c["name"] == search), items ) ) )
    items = next( iter( filter( lambda s: (s["delivery"] == "3"), items["Services"] ) ) )
    url = items["Service"][0]["url"]

    return url
