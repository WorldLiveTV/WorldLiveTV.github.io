# -*- coding: utf-8 -*-

import requests, json
from lib import scrapers, config, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://play.xdevel.com"


def play(search):
    res = BroadcasterResult()
    url = ""

    data = requests.get(f"{HOST}/{search}").text
    jsonStr = scrapers.findSingleMatch(data, r"PLAYER_CONFIG\s+=\s+([^$]+);\s+window")
    jsonData = json.loads(jsonStr)

    url = jsonData["stations"][jsonData["defaultStation"]]["channel"]["sources"][0]["source"]

    if url:
        res.Url = url
        res.Manifest = "hls"

    return res
