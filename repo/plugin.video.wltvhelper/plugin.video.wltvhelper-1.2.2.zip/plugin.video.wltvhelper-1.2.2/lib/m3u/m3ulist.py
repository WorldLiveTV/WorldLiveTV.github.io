import uuid
from typing import List, Any, TypeVar, Callable, Type, cast

T = TypeVar("T")


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_bool(x: Any) -> bool:
    assert isinstance(x, bool)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


class M3UList:
    Id: str
    Name: str
    DisplayName: str
    Enabled: bool
    Tags: List[str]
    List: str
    Epg: str
    Groups: List[str]
    IsEmergency: bool
    IsUserList: bool
    IsPersonal: bool
    IsValid: bool
    #LastUpdate: date

    def __init__(self, Id: str = "", Name: str = "", DisplayName: str = "", Enabled: bool = False, Tags: List[str] = [], List: str = "", Epg: str = "", Groups: List[Any] = [], IsEmergency: bool = False, IsUserList: bool = False, IsPersonal: bool = False, IsValid: bool = False) -> None:
        if not Id: Id = self.__get_newid()
        if not DisplayName: DisplayName = Name
        
        normalizedGroup = list()
        if isinstance(Groups, dict):
            normalizedGroup = list(filter(lambda item: item.get("Name", "Unknown"), Groups))
        elif isinstance(Groups, list):
            normalizedGroup = Groups
        elif isinstance(Groups, str):
            normalizedGroup = [Groups]
        
        self.Id   = Id
        self.Name = Name
        self.DisplayName = DisplayName
        self.Enabled = Enabled
        self.Tags    = Tags
        self.List    = List
        self.Epg     = Epg
        self.Groups  = normalizedGroup
        self.IsEmergency = IsEmergency
        self.IsUserList  = IsUserList
        self.IsPersonal  = IsPersonal
        self.IsValid     = IsValid

    def AllGroupsSelected(self) -> bool:
        return self.Groups == ["*"]
    def PartialGroupsSelected(self) -> bool:
        return len(self.Groups) > 0

    def __get_newid(self):
        iDs = str(uuid.uuid4()).split("-")
        uId = iDs[0]+iDs[1]+iDs[2]
        return uId

    @staticmethod
    def from_dict(obj: Any) -> 'M3UList':
        assert isinstance(obj, dict)
        Id   = from_str(obj.get("Id"))
        Name = from_str(obj.get("Name"))
        DisplayName = from_str(obj.get("DisplayName"))
        Enabled = from_bool(obj.get("Enabled"))
        Tags    = from_list(from_str, obj.get("Tags", list()))
        List    = from_str(obj.get("List"))
        Epg     = from_str(obj.get("Epg"))
        Groups  = from_list(from_str, obj.get("Groups", list()))
        IsEmergency = from_bool(obj.get("IsEmergency"))
        IsUserList  = from_bool(obj.get("IsUserList"))
        IsPersonal  = from_bool(obj.get("IsPersonal"))
        IsValid     = from_bool(obj.get("IsValid"))
        return M3UList(Id, Name, DisplayName, Enabled, Tags, List, Epg, Groups, IsEmergency, IsUserList, IsPersonal, IsValid)

    def to_dict(self) -> dict:
        result: dict = {}
        result["Id"]   = from_str(self.Id)
        result["Name"] = from_str(self.Name)
        result["DisplayName"] = from_str(self.DisplayName)
        result["Enabled"] = from_bool(self.Enabled)
        result["Tags"]    = from_list(from_str, self.Tags)
        result["List"]    = from_str(self.List)
        result["Epg"]     = from_str(self.Epg)
        result["Groups"]  = from_list(from_str, self.Groups)
        result["IsEmergency"] = from_bool(self.IsEmergency)
        result["IsUserList"]  = from_bool(self.IsUserList)
        result["IsPersonal"]  = from_bool(self.IsPersonal)
        result["IsValid"]     = from_bool(self.IsValid)
        return result


def M3UListfromdict(s: Any) -> M3UList:
    return M3UList.from_dict(s)


def M3UListtodict(x: M3UList) -> Any:
    return to_class(M3UList, x)
