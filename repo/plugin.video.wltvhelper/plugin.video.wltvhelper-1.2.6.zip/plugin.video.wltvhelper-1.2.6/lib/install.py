# -*- coding: utf-8 -*-

import xbmcgui, xbmc, os, sys
from lib import logger, config, utils
from inputstreamhelper import Helper
from xbmcaddon import Addon

dialog = xbmcgui.Dialog()

ADDON_ID_PVR = "pvr.iptvsimple"
ADDON_ID_INPUTSTREAM  = "inputstream.adaptive"
ADDON_ID_WEBPDB = "script.module.web-pdb"
ADDON_ID_BOTTLE = "script.module.bottle"

def install():
    res = installInputStreamAdaptive()
    installWidevine()
    if res:
        utils.MessageNotification(config.getString(30121))

def installPvr():
    return installAddon(ADDON_ID_PVR, "PVR Simple Client", True)

def installInputStreamAdaptive():
    return installAddon(ADDON_ID_INPUTSTREAM)

def installWidevine():
    if not Helper("mpd", drm="widevine").check_inputstream():
        Helper("mpd", drm="widevine").install_widevine()

def installWebPdb():
    res = None
    if installAddon(ADDON_ID_WEBPDB) and installAddon(ADDON_ID_BOTTLE):
        webpdb = Addon(ADDON_ID_WEBPDB)
        bottle = Addon(ADDON_ID_BOTTLE)
        res = config.translatePath(os.path.join(webpdb.getAddonInfo("Path"), "libs")), config.translatePath(os.path.join(bottle.getAddonInfo("Path"), "lib"))
    return res

def installAddon(addonId, addonName="", askActivation=False):
    # Check if an addon is installed, if it doesn't, ask to install it.
    isInstalled = xbmc.getCondVisibility(f"System.HasAddon({addonId})")
    isActive = False

    if(not isInstalled):
        logger.debug(f"{addonId} seems to be not installed")
        xbmc.executebuiltin(f"InstallAddon({addonId})", wait=True)
        isInstalled = xbmc.getCondVisibility(f"System.HasAddon({addonId})")

    if isInstalled:
        try:
            # Check if it's active
            isActive = Addon(id=addonId) != None
        except:
            # if it's not active ask to activate it
            activate = True
            if askActivation:
                if not addonName:
                    addonName = addonId
                activate = utils.MessageBoxQuestion(config.getString(30111).format(addonName))
            if activate:
                xbmc.executeJSONRPC('{{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": {{ "addonid": "{}", "enabled": true }}}}'.format(addonId))
                isActive = Addon(id=addonId)

    return isInstalled and isActive
