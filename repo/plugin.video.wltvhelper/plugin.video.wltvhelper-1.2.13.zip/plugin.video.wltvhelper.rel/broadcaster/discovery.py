# -*- coding: utf-8 -*-

import requests, uuid
from lib import config, utils, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.discoveryplus.com"

def play(search):
    res = BroadcasterResult()
    chId = ""
    
    deviceId = uuid.uuid4().hex
    dplusVer = "2.55.0"
    
    headers = utils.getBrowserHeaders(host=HOST)

    headers["Accept"] = "*/*"
    headers["x-disco-client"] = f"WEB:UNKNOWN:dplus_us:{dplusVer}"
    headers["x-disco-params"] = "bid=dplus,hn=www.discoveryplus.com,hth=it"

    infoUrl = "https://global-prod.disco-api.com/bootstrapInfo"
   
    jsonData = requests.get(infoUrl, headers=headers).json()
    baseApiUrl = jsonData.get("data", {}).get("attributes", {}).get("baseApiUrl", "")

    #get token
    headers["x-device-info"]  = f"dplus_us/{dplusVer} (desktop/desktop; Windows/NT 10.0; {deviceId})"
    headers["x-disco-params"] = "realm=dplay,bid=dplus,hn=www.discoveryplus.com,hth=it,features=ar"

    token = requests.get(f"{baseApiUrl}/token?deviceId={deviceId}&realm=dplay&shortlived=true", headers=headers).json()["data"]["attributes"]["token"]
    cookies = { "st": token }

    chs = requests.get(f"{baseApiUrl}/cms/routes/home?include=default&decorators=playbackAllowed", headers=headers, cookies=cookies).json()["included"]
    chs = list(filter(lambda x: x.get("type", "") == "channel", chs))

    for key in chs:
        if (key.get("attributes", {}).get("hasLiveStream", "") == True
            and "Free" in key.get("attributes", {}).get("packages", [])
            and search == key["attributes"]["channelCode"]):
            chId = key["id"]
            break
    chs = None

    if chId:
        postJsonData = f'{{ "channelId": "{chId}", "deviceInfo": {{ "adBlocker": false, "drmSupported": true }}, "wisteriaProperties": {{ "siteId": "dplus_it", "platform": "desktop" }} }}'

        headers.pop("x-device-info")
        headers["x-disco-params"] = "realm=dplay,siteLookupKey=dplus_it,bid=dplus,hn=www.discoveryplus.com,hth=it"
        
        jsonData = requests.post(f"{baseApiUrl}/playback/v3/channelPlaybackInfo", headers=headers, cookies=cookies, data=postJsonData).json()
        data = jsonData.get("data", {}).get("attributes", {}).get("streaming", {})[0]
        jsonData = None

        url = data["url"]

        if url:
            res.Url = url
            res.UserAgent = True
            res.StreamHeaders = headers
            
            if data["protection"]["drmEnabled"] == True:
                drmToken = data["protection"]["drmToken"]
                licenseUrl = data["protection"]["schemes"]["widevine"]["licenseUrl"]
                res.LicenseKey = f"{licenseUrl}|preauthorization={drmToken}|R{{SSM}}|"
        
    return res
