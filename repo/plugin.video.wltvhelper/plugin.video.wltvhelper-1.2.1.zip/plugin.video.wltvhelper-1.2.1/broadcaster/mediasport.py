# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://platform.wim.tv"
API = HOST + "/wimtv-server"

headers = {
    "User-Agent": utils.USER_AGENT,
    "Content-Type": "application/json",
    "Referer": HOST + "/",
    "X-Requested-With": "XMLHttpRequest",
}


def play(search):
    res = BroadcasterResult()

    session = requests.Session()
    session.headers.update(headers)

    if search == "extra":
        pageUrl = "https://mschannel.tv/extra"
    elif search == "acisport":
        pageUrl = "https://www.acisport.it/aci_sport_tv.htm"
    else:
        pageUrl = "https://{}.tv".format(search)

    data = session.get(pageUrl).text
    match = scrapers.findSingleMatch(data, r'iframe.*?src\s*="[^\?]+\?(\w+)=([^&]+)')

    if match:
        channelType, channelId = match
        logger.debug("channelType:", channelType, "channelId:", channelId)

        query = {"grant_type": "client_credentials"}
        token = (session.post("{}/oauth/token".format(API),auth=requests.auth.HTTPBasicAuth("www", ""),params=query,)
            .json()
            .get("access_token", ""))

        session.headers.update({"Authorization": "Bearer {}".format(token), "Origin": HOST})
        _json = (session.post("{}/api/public/{}/channel/{}/play".format(API, channelType, channelId),json={},)
            .json()
            .get("srcs", []))

        try:
            hlsStream = next( iter( filter( lambda item: (item["mimeType"] == "application/x-mpegurl"), _json, ) ) )
            res.Url = hlsStream["uniqueStreamer"]
        except (StopIteration, KeyError):
            logger.error("Something is changed on broadcaster side")

    return res
