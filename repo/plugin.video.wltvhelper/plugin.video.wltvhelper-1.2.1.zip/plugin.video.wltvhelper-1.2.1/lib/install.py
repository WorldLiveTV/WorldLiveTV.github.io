# -*- coding: utf-8 -*-

import xbmcgui, xbmc, os, sys
from lib import logger, config
from inputstreamhelper import Helper

if sys.version_info[0] >= 3:
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

from xbmcaddon import Addon
dialog = xbmcgui.Dialog()

ADDON_ID_PVR = "pvr.iptvsimple"
ADDON_ID_LOGUPLOADER  = "script.kodi.loguploader"
ADDON_ID_XMLTODICT    = "script.module.xmltodict"
ADDON_ID_INPUTSTREAM  = "inputstream.adaptive"
ADDON_ID_WEBPDB = "script.module.web-pdb"
ADDON_ID_BOTTLE = "script.module.bottle"

def install():
    res = installInputStreamAdaptive()
    res = res and installXml2dict()
    installWidevine()
    if res:
        dialog.notification( config.getString(30000), config.getString(30121) )

def installLogUploader():
    return installAddon(ADDON_ID_LOGUPLOADER)

def installPvr():
    return installAddon(ADDON_ID_PVR, "PVR Simple Client", True)

def installXml2dict():
    return installAddon(ADDON_ID_XMLTODICT)

def installInputStreamAdaptive():
    return installAddon(ADDON_ID_INPUTSTREAM)

def installWidevine():
    if not Helper("mpd", drm="widevine").check_inputstream():
        Helper("mpd", drm="widevine").install_widevine()

def installWebPdb():
    res = None
    if installAddon(ADDON_ID_WEBPDB) and installAddon(ADDON_ID_BOTTLE):
        webpdb = Addon(ADDON_ID_WEBPDB)
        bottle = Addon(ADDON_ID_BOTTLE)
        res = config.translatePath(os.path.join(webpdb.getAddonInfo("Path"), "libs")), config.translatePath(os.path.join(bottle.getAddonInfo("Path"), "lib"))
    return res

def installAddon(addonId, addonName="", askActivation=False):
    # Check if an addon is installed, if it doesn't, ask to install it.
    isInstalled = xbmc.getCondVisibility("System.HasAddon({})".format(addonId))
    isActive = False

    if(not isInstalled):
        logger.debug("{} seems to be not installed".format(addonId))
        xbmc.executebuiltin("InstallAddon({})".format(addonId), wait=True)
        isInstalled = xbmc.getCondVisibility("System.HasAddon({})".format(addonId))

    if isInstalled:
        try:
            # Check if it's active
            isActive = Addon(id=addonId) != None
        except:
            # if it's not active ask to activate it
            activate = True
            if askActivation:
                if not addonName:
                    addonName = addonId
                activate = dialog.yesno(config.getString(30000), config.getString(30111).format(addonName))
            if activate:
                xbmc.executeJSONRPC('{{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": {{ "addonid": "{}", "enabled": true }}}}'.format(addonId))
                isActive = Addon(id=addonId)

    return isInstalled and isActive
