# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.radiosaiuz.it"
LIVE_CHANNEL_URL = "/{}.html"

def play(search):
    res = BroadcasterResult()
    url = ""

    page_url = f"{HOST}{LIVE_CHANNEL_URL.format(search)}"
    data = requests.get(page_url).text

    url = scrapers.findSingleMatch(data, r"\"sourceURL\":\"([^\"]+)")
    if not url:
        url = scrapers.findSingleMatch(data, r"source\ssrc=\"([^\"]+)\"\s+type=\"application")

    if url:
        res.Url = url

    return res

