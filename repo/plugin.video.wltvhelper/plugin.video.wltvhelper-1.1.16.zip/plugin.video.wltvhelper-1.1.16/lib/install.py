# -*- coding: utf-8 -*-

import xbmcgui, xbmc, os, sys
from lib import logger, config
from inputstreamhelper import Helper

if sys.version_info[0] >= 3:
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

from xbmcaddon import Addon
dialog = xbmcgui.Dialog()

def install():
    ret = install_inputstream()
    install_widevine()
    if ret:
        dialog.notification( config.getString(30000), config.getString(30121) )



def install_pvr():
    # Check if PVR Simple Client is installed
    # if it doesn't exist, ask to install it.

    simple = None

    if not os.path.exists(translatePath('special://home/addons/pvr.iptvsimple')) and not os.path.exists(translatePath('special://xbmcbinaddons/pvr.iptvsimple')):
        xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)', wait=True)

    try:
        # Check if it's active
        simple = Addon(id='pvr.iptvsimple')
    except:
        # if it's not active ask to activate it
        if dialog.yesno(config.getString(30000), config.getString(30111)):
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')
            simple = Addon(id='pvr.iptvsimple')

    return simple


def install_inputstream():
    if not os.path.exists(os.path.join(translatePath('special://home/addons/'),'inputstream.adaptive')) and not os.path.exists(os.path.join(translatePath('special://xbmcbinaddons/'),'inputstream.adaptive')):
        try:
            # See if there's an installed repo that has it
            xbmc.executebuiltin('InstallAddon(inputstream.adaptive)', wait=True)

            # Check if InputStream add-on exists!
            Addon('inputstream.adaptive')

            logger.debug('InputStream add-on installed from repo.')
        except RuntimeError:
            logger.debug('InputStream add-on not installed.')
            dialog.ok(config.getString(30100), config.getString(30101))
            return False
    else:
        try:
            Addon('inputstream.adaptive')
            logger.debug('InputStream add-on is installed and enabled')
        except:
            logger.debug('enabling InputStream add-on')
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "inputstream.adaptive", "enabled": true }}')

    return True

def install_widevine():
    if not Helper('mpd', drm='widevine').check_inputstream():
        Helper('mpd', drm='widevine').install_widevine()

def install_web_pdb():
    if not os.path.exists(translatePath('special://home/addons/script.module.web-pdb')) and not os.path.exists(translatePath('special://xbmcbinaddons/script.module.web-pdb')):
        xbmc.executebuiltin('InstallAddon(script.module.web-pdb)', wait=True)
        try:
            webpdb = Addon(id='script.module.web-pdb')
        except:
            pass
            # TODO Show dialog?

    try:
        # Check if it's active
        webpdb = Addon(id='script.module.web-pdb')
    except:
        # if it's not active ask to activate it
        if xbmcgui.Dialog().yesno(config.getString(30000), config.getString(30111)):
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "script.module.web-pdb", "enabled": true }}')
            webpdb = Addon(id='script.module.web-pdb')

    bottle = Addon(id='script.module.bottle')
    return config.translatePath(os.path.join(webpdb.getAddonInfo('Path'), 'libs')), config.translatePath(os.path.join(bottle.getAddonInfo('Path'), 'lib'))
