# Module: WorldLiveTV
# Author: CrAcK75
# Created on: 06/05/2021
#
#
import os
import sys
import xbmcgui
import xbmcplugin
import requests
import routing
import json
from lib import logger, config, utils

_name = 'WorldLiveTV'
fileName = 'listIntChannels.bin'
#urlbase = 'https://iptv-org.github.io/iptv/countries/'
plugin = routing.Plugin()

@plugin.route('/worldtv')
def Start():
    ShowContinentsList()

def ShowContinentsList():
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, 'International TVs')
    
    imagedir = 'world'
    lstItem = GetLists()
    if (not lstItem): return

    for item in lstItem['worlditems']:
        name = item['name']
        code = item['code']
        png = '{}.png'.format(code)

        li = xbmcgui.ListItem(name)

        li.setArt({
            'thumb':  os.path.join(config.ADDONPATH, 'resources', imagedir, png),
            'poster': os.path.join(config.ADDONPATH, 'resources', imagedir, png),
            'fanart': os.path.join(config.ADDONPATH, 'resources', imagedir, png),
            })

        url = plugin.url_for(ShowCountries, code)
        xbmcplugin.addDirectoryItem(handle, url, li, True)
        
    xbmcplugin.endOfDirectory(handle)

@plugin.route('/worldtv/showcountries/<continentcode>')
def ShowCountries(continentcode):
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, continentcode)

    lstItem = GetLists()
    lstItem = GetItems(continentcode, lstItem)
    for item in lstItem['worlditems']:
        code = item['code']
        name = item['name']
        url = item['url']
        png = '{}.png'.format(code)
        if (code == 'it'): continue

        li = xbmcgui.ListItem(name)
        li.setArt({
            'icon': os.path.join(config.ADDONPATH, 'resources','flags', png),
            'thumb': os.path.join(config.ADDONPATH, 'resources','flags', png),
           #'poster': os.path.join(config.ADDONPATH, 'resources','flags', png),
            'fanart': os.path.join(config.ADDONPATH, 'resources', 'background.png')
            })

        url = plugin.url_for(SwitchList, name, url)
        xbmcplugin.addDirectoryItem(handle, url, li, False)

    xbmcplugin.addSortMethod(handle , xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle , True)

def GetCountries(continentcode):
    return [x for x in ContinentsList if x['code'] == continentcode][0]['worlditems']

@plugin.route('/worldtv/switchlist/<name>/<code>')
def SwitchList(name, code):
    #url = '{}{}.m3u'.format(urlbase, code)
    url = utils.DecodeFromBase64(code)
    utils.setList(name, url, '')

def GetItems(code, lstItem):
    lstItem = [x for x in lstItem['worlditems'] if x['code'] == code][0]
    return lstItem 

def GetLists():
    strJson = ''
    compressed = utils.ReadFileOrDownloadFromPersonal(fileName)

    strJson = utils.Decompress(compressed)
    if (not strJson):
        compressed = utils.ReadFileOrDownloadFromPersonal(fileName, True)
        strJson = utils.Decompress(compressed)

    if(strJson):
        try:
            strJson = json.loads(strJson)
        except:
            strJson = ''
    
    if (not strJson):
        xbmcgui.Dialog().notification(config.getString(30000), 'Service Not available')

    return strJson

plugin.run()
