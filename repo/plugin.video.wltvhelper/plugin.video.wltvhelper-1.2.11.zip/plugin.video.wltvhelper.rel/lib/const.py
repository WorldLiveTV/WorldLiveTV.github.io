# -*- coding: utf-8 -*-

CUSTOM_LIST = "personal_list"
USER_LIST = "user_list"

SELECTED_LIST = "selected"
LAST_SELECTED_ONLINE_LIST = "last_selected_online_list"

ITEM_SELECTED = "selected"
ITEM_UNSELECTED = "unselected"
ITEM_PARTIALSELECTED = "partial"