# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config #, logger

DRM = 'com.widevine.alpha'
host = 'https://supertennis.tv/'

headers = {'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
           'Referer': host,
           'Sec-Fetch-Site': 'cross-site',
           'Sec-Fetch-Mode': 'navigate',
           'Sec-Fetch-Dest': 'iframe'}

def play(search):
    res = []
    url = ''
    data = requests.get(host).text
    url = scrapers.find_single_match(data, r'iframe.*?src="([^"]+)')
    data = requests.get(url, headers=headers).text

    streamType = 'M3U8'
    if config.getSetting('mpd'):
        streamType = 'DASH'

    url = scrapers.find_single_match(data, r'videoFormat.*?'+streamType+'.*?:\s"(.*?)"')

    if url:
        if config.getSetting('mpd'):
            res = [url, '', DRM]
        else:
            res = [url]

    return res