# -*- coding: utf-8 -*-

import xbmcaddon, sys, os
if sys.version_info[0] >= 3:
    import xbmcvfs
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

ADDON     = xbmcaddon.Addon()
ADDONID   = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONUSERPATH = ADDON.getAddonInfo('profile')

def getSetting(name):
    value = ADDON.getSetting(name)
    if value == "true":
        value = True
    elif value == "false":
        value = False
    else:
        try:
            value = int(value)
        except ValueError:
            pass
    return value

def setSetting(name, value):
    if value == True:
        value = 'true'
    elif value == False:
        value = 'false'
    else:
        value = str(value)
    ADDON.setSetting(name, value)

def openSettings():
    ADDON.openSettings()

def getAddonInfo(name):
    return ADDON.getAddonInfo(name)

def quality(qualities):
    resolutions = [1080, 720, 480]
    resolution = resolutions[int(getSetting('resolutions'))]
    selected = [min(range(len(qualities)), key = lambda i: abs(int(qualities[i])-resolution))][0]
    return selected

def getString(ID):
    return ADDON.getLocalizedString(ID)

def isDEV():
    return os.path.isdir(os.path.join(ADDONPATH, '.git'))
