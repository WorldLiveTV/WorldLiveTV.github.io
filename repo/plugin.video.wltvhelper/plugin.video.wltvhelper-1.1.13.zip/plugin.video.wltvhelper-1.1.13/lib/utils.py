import os
import xbmc
import xbmcgui
import xbmcvfs
import sys
import json
import base64
import zlib
import requests

IsPY3  = True if sys.version_info[0] >= 3 else False

if IsPY3:
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

from lib import config, logger, install
import datetime

API_DOMAIN = 'http://tvchannels.worldlivetv.eu/tv'
EPG_URL = 'http://epg-guide.com/wltv.gz'
FILE_REPO = 'http://www.worldlivetv.eu/world/files'
DEFAULT_DATE = 20210101

RemoteLists = []

PARAM_LIST_NAME = 'personal_list'

def PY3():
    return IsPY3

def apiRequester(par=''):
    return requests.get(API_DOMAIN + par).json()

def readFile(filePath):
    file = xbmcvfs.File(filePath)
    c = file.read()
    file.close()

    return c

def writeFile(filePath, txt):
    file = xbmcvfs.File(filePath, 'w')
    file.write(str(txt))
    file.close()

def getPersonalPathFile(filename):
    file_path = os.path.join(config.ADDONUSERPATH, filename)

    return translatePath(file_path)

def readLocalOrDownload(fileName, checkServerFileTimeStamp=True, onceaday=True):
    fileContent = ''
    filePath = os.path.join(config.ADDONUSERPATH, fileName)

    forceDownload = needsUpdate(fileName, checkServerFileTimeStamp, onceaday)

    if(not forceDownload):
        try:
            fileContent = readFile(filePath)
        except:
            fileContent = ''

    if (not fileContent or forceDownload):
        url = '{}/{}'.format(FILE_REPO ,fileName)
        fileContent = requests.get(url).text
        writeFile(filePath, fileContent)

    return fileContent

def needsUpdate(filename, checkServerFileTimeStamp=False, onceaday=True):
    res = False
    filePath = translatePath(os.path.join(config.ADDONUSERPATH, filename))

    if not os.path.exists(filePath):
        logger.info('Cannot get localfile {}, needs update'.format(filename))
        res = True
    else:
        try:
            if (checkServerFileTimeStamp):
                mtime = os.path.getmtime(filePath)
                last_modified_date = datetime.datetime.fromtimestamp(mtime)
                day = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][last_modified_date.weekday()]
                
                if(onceaday):
                    modified_since = last_modified_date.strftime("%d %b %Y 23:59:59 GTM") #once a day it's enought
                else:
                    modified_since = last_modified_date.strftime("%d %b %Y %H:%M:%S GTM")

                url = '{}/{}'.format(FILE_REPO , filename)
                req = requests.get(url, headers={'If-Modified-Since': '{}, {}'.format(day, modified_since) })
                if req.status_code != 304: # cannot read from local file because of CACHE, needs update
                    res = True
            else:
                dt = datetime.datetime.now()
                file_datetime = datetime.datetime.fromtimestamp(os.path.getctime(filePath))
                res = (dt - file_datetime).days > 1
        except OSError as e:
            logger.info('Error getting localfile info {}, needs update'.format(filename), e)
            res = True
        except Exception as e:
            logger.info('Error during needsUpdate check: [{}]'.format(e))
            logger.info('Force download {}'.format(filename))
            res = True

    return res

def downloadRemoteFromPersonal(filename, forceDownload=False):
    file_path = os.path.join(config.ADDONUSERPATH, filename)
    traslatedPath = translatePath(file_path)
    mtime = 0
    if not os.path.exists(traslatedPath) :
        forceDownload = True

    if not forceDownload:
        try:
            mtime = os.path.getmtime(traslatedPath)
        except OSError as e:
            logger.info('Cannot get localfile {}'.format(filename), e)
    else:
        # use mtime = 0 to force download file from 1970
        # this is also in case of `file_not_exists`
        logger.info('force download {}'.format(filename))


    last_modified_date = datetime.datetime.fromtimestamp(mtime)
    day = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][last_modified_date.weekday()]
    modified_since = last_modified_date.strftime("%d %b %Y %H:%M:%S GTM")

    url = '{}/{}'.format(FILE_REPO , filename)
    req = requests.get(url, headers={'If-Modified-Since': '{}, {}'.format(day, modified_since) })

    filecontent = ''

    if req.status_code == 304:
        # read from local file because of CACHE
        filecontent = readFile(file_path)
    else:
        filecontent = req.text
        writeFile(file_path, filecontent)

    return filecontent

#def DecodeFromBase64(Json):
#    if PY3:
#        return base64.b64encode(json.dumps(Json).encode()).decode()
#    else:
#        return base64.b64encode(json.dumps(Json))
def decodeFromBase64(input):
    return base64.b64decode(input)

###################
def decompress(input):
    decomp = ''
    try:
        decomp = (zlib.decompress(base64.b64decode(input),-15))
    except Exception as e:
        logger.info('Error decompressin files: ', e)

    return decomp

def getRemoteLists():
    res = apiRequester('/all.json')
    for l in res:
        if l['Enabled'] or config.isDEV():
            RemoteLists.append(transformListItem(l))

    return RemoteLists

def transformListItem(item, official=True):
    return {
        'Name': item['Name'],
        'Choose': {},
        'Official': official
    }

def CheckSettings():
    import datetime

    useDL = config.getSetting("forceDirectLink")

    dt = int(datetime.datetime.now().date().strftime('%Y%m%d'))
    expDt = int(config.getSetting("forceDirectLinkExp"))

    if(useDL == True and expDt == DEFAULT_DATE):
        config.setSetting("forceDirectLinkExp", dt)
        expDt = dt

    if(abs(dt - expDt) >= 1):
        config.setSetting("forceDirectLink", False)
        config.setSetting("forceDirectLinkExp", DEFAULT_DATE)

    return

def getPersonalLists():
    if not config.getSetting(PARAM_LIST_NAME):
        return []
    listDict = json.loads(config.getSetting(PARAM_LIST_NAME))
    if type(listDict) is str:
        try:
            listDict = json.loads(listDict)
        except:
            # TODO: print error or log?
            listDict = []
    return listDict

def computeListUrl(selectedList):
    selectedGroups = []
    if selectedList['Choose']:
        choosedLists = selectedList['Choose']
        for listKey in choosedLists:
            groups = choosedLists[listKey]
            queryGroups = []
            for group in groups:
                queryGroups.append(group)
            selectedGroups.append('{}={}'.format(listKey, ','.join(queryGroups)))

    if len(selectedGroups) == 0:
        # user has selected a full list
        return '{}/{}/list.m3u8?'.format(API_DOMAIN, selectedList['Name'])
    else:
        return '{}/all/groups/merge.m3u8?{}'.format(API_DOMAIN, '&'.join(selectedGroups))

def setList(listName, m3uList, epgUrl):
    simple = install.install_pvr()

    if simple:
        if PY3():
            xbmc.executebuiltin('xbmc.StopPVRManager')
        else:
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": false }}')

        if simple.getSetting('m3uPathType') != '1': simple.setSetting('m3uPathType', '1')
        if simple.getSetting('epgPathType') != '1': simple.setSetting('epgPathType', '1')

        if (epgUrl):
            if simple.getSetting('logoFromEpg') != '2': simple.setSetting('logoFromEpg', '2')
            if simple.getSetting('epgUrl') != epgUrl: simple.setSetting('epgUrl', epgUrl)
            elif simple.getSetting('epgUrl') and not config.getSetting('enable_epg'): simple.setSetting('epgUrl','')
        else:
            simple.setSetting('epgUrl', '')
            simple.setSetting('logoFromEpg', '0')

        simple.setSetting('m3uUrl', m3uList)

        xbmc.sleep(500)

        if PY3():
            xbmc.executebuiltin('xbmc.StartPVRManager')
        else:
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')
            xbmc.sleep(500)
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": false }}')
            xbmc.sleep(500)
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')

        # show a simple notification informing user new IPTV list has been set
        if(listName): listName += ' '
        xbmcgui.Dialog().notification(config.getString(30000), config.getString(30120).format(listName))
