# -*- coding: utf-8 -*-

import requests, json
from lib import scrapers, config, logger

host = 'https://supertennis.tv/'

headers = {'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
           'Referer': host,
           'Sec-Fetch-Site': 'cross-site',
           'Sec-Fetch-Mode': 'navigate',
           'Sec-Fetch-Dest': 'iframe'}

mpd = config.getSetting('mpd')
#if not utils.PY3():
mpd = False #temporaneamente disattivato per bug di IA

def play(search):
    res = {}
    url = ''
    streamType = 'm3u8'
    if mpd:
        streamType = 'mdp'

    data = requests.get(host).text
    urlData = scrapers.find_single_match(data, r'iframe.*?src="([^"]+)')
    data = requests.get(urlData, headers=headers).text
    jsonData = json.loads(scrapers.find_single_match(data, r'JSON\.parse.*?\'(.*?)\''))

    urls = []
    for urlData in jsonData['renditions']:
        urls.append(urlData['url'])
            
    for url in urls:
        if streamType in url:
            break 

    if url:
        res['url'] = url
        if mpd:
            res['manifest'] = 'mpd'
        else:
            res['manifest'] = 'hls'

    return res