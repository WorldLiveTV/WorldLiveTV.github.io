# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config, logger

post_url = '?assetTypes=HD,browser,widevine:HD,browser:SD,browser,widevine:SD,browser:SD&auto=true&balance=true&format=smil&formats=MPEG-DASH,MPEG4,M3U&tracking=true'
lic_url = 'https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid=%s&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}' + \
          '|Accept=*/*&Content-Type=&User-Agent=Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0|R{{SSM}}|'

session = requests.Session()
session.headers.update({'Content-Type': 'application/json', 'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
                                'Referer': 'https://www.mediasetplay.mediaset.it'})

def play(search):
    res = {}

    json = session.get('https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations?sort=ShortTitle').json()['entries']

    for it in json:
        urls = []
        if search.startswith("$"):
            _search = "$" + it['callSign']
        else:
            _search = it['title']

        if it['tuningInstruction'] and not it['mediasetstation$digitalOnly'] and _search == search:
            for key in it['tuningInstruction']['urn:theplatform:tv:location:any']:
                if (key['format'] == 'application/dash+xml' or key['format'] == 'application/x-mpegURL'):
                    urls += key['publicUrls']
            break

    for url in urls:
        uri = session.get(url).url
        if '.mpd' in uri and config.getSetting('mpd'):
            #logger.info("url: ",url)
            #logger.info("uri: ",uri)
            res['url'] = uri
            res['manifest'] = 'mpd'
            break
        else:
            #logger.info("url: ",url)
            res['url'] = url

    return res
