import os
import xbmc
import xbmcgui
import sys
import json
import base64
import zlib
import requests

PY3 = True if sys.version_info[0] >= 3 else False

if(PY3):
    from lib import config, logger, install
else:
    import config, logger, install


API_DOMAIN = 'http://tvchannels.worldlivetv.eu/tv'
EPG_URL = 'http://epg-guide.com/wltv.gz'
FILE_REPO = 'http://www.worldlivetv.eu/world/files'
DEFAULT_DATE = 20210101

# import web_pdb;
RemoteLists = []

PARAM_LIST_NAME = 'personal_list'

def apiRequester(par=''):
    return requests.get(API_DOMAIN + par).json()

def ReadFile(filePath):
    import xbmcvfs

    c = ''

    if PY3:
        with xbmcvfs.File(filePath) as file:
            c = file.read()
    else:
        file = xbmcvfs.File(filePath)
        c = file.read()
        file.close()
        
    return c

def WriteFile(filePath, txt):
    import xbmcvfs

    if PY3:
        with xbmcvfs.File(filePath, 'w') as file:
            file.write(txt)
    else:
        file = xbmcvfs.File(filePath, 'w')
        file.write(txt)
        file.close()

def ReadFileOrDownloadFromPersonal(fileName, forceDownload=False):
    fileContent = ''
    filePath = os.path.join(config.ADDONUSERPATH, fileName)

    if(NeedsUpdate(filePath)):
        forceDownload = True

    try:
        fileContent = ReadFile(filePath)
    except IOError:
        fileContent = ''
        
    if (not fileContent or forceDownload):
        url = '{}/{}'.format(FILE_REPO ,fileName)
        fileContent = requests.get(url).text
        WriteFile(filePath, fileContent)

    return fileContent

#def DecodeFromBase64(Json):
#    if PY3:
#        return base64.b64encode(json.dumps(Json).encode()).decode()
#    else:
#        return base64.b64encode(json.dumps(Json))
def DecodeFromBase64(input):
    return base64.b64decode(input)

def NeedsUpdate(filePath):
    import datetime
    import os.path
    import time
    if PY3:
        import xbmcvfs
        from xbmcvfs import translatePath
    else:
        from xbmc import translatePath

    filePath = translatePath(filePath)
    dt = datetime.datetime.now()
    try:
        cdt = datetime.datetime.fromtimestamp(os.path.getctime(filePath))
    except:
        cdt = datetime.datetime(2020, 1, 1)

    return (dt - cdt).days > 1

###################
def Decompress(input):
    decomp = ''
    try:
        decomp = zlib.decompress(base64.b64decode(input),-15).decode()
    except:
        decomp = ''

    return decomp 

def getRemoteLists():
    res = apiRequester('/all.json')
    for l in res:
        if l['Enabled'] or isDEV():
            RemoteLists.append(transformListItem(l))

    return RemoteLists

def transformListItem(item, official=True):
    return {
        'Name': item['Name'],
        'Choose': {},
        'Official': official
    }

def isDEV():
    return os.path.isdir(os.path.join(config.ADDONPATH, '.git'))

def CheckSettings():
    import datetime
    
    useDL = config.getSetting("forceDirectLink")

    dt = int(datetime.datetime.now().date().strftime('%Y%m%d'))
    expDt = int(config.getSetting("forceDirectLinkExp"))

    if(useDL == True and expDt == DEFAULT_DATE):
        config.setSetting("forceDirectLinkExp", dt)
        expDt = dt

    if(abs(dt - expDt) >= 1):
        config.setSetting("forceDirectLink", False)
        config.setSetting("forceDirectLinkExp", DEFAULT_DATE)
    
    return 
    

def getPersonalLists():
    if not config.getSetting(PARAM_LIST_NAME):
        return []
    listDict = json.loads(config.getSetting(PARAM_LIST_NAME))
    if type(listDict) is str:
        try:
            listDict = json.loads(listDict)
        except:
            # TODO: print error or log?
            listDict = []
    return listDict

def computeListUrl(selectedList):
    selectedGroups = []
    if selectedList['Choose']:
        choosedLists = selectedList['Choose']
        for listKey in choosedLists:
            groups = choosedLists[listKey]
            queryGroups = []
            for group in groups:
                queryGroups.append(group)
            selectedGroups.append('{}={}'.format(listKey, ','.join(queryGroups)))

    if len(selectedGroups) == 0:
        # user has selected a full list
        return '{}/{}/list.m3u8?'.format(API_DOMAIN, selectedList['Name'])
    else:
        return '{}/all/groups/merge.m3u8?{}'.format(API_DOMAIN, '&'.join(selectedGroups))

def setList(listName, m3uList, epgUrl):
    simple = install.install_pvr()

    if simple:
        if PY3:
            xbmc.executebuiltin('xbmc.StopPVRManager')
        else:
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": false }}')

        if simple.getSetting('m3uPathType') != '1': simple.setSetting('m3uPathType', '1')
        if simple.getSetting('epgPathType') != '1': simple.setSetting('epgPathType', '1')
 
        if (epgUrl):
            if simple.getSetting('logoFromEpg') != '2': simple.setSetting('logoFromEpg', '2')
            if simple.getSetting('epgUrl') != epgUrl: simple.setSetting('epgUrl', epgUrl)
            elif simple.getSetting('epgUrl') and not config.getSetting('enable_epg'): simple.setSetting('epgUrl','')
        else:
            simple.setSetting('epgUrl', '')
            simple.setSetting('logoFromEpg', '0')
                
        simple.setSetting('m3uUrl', m3uList)

        xbmc.sleep(500)

        if PY3:
            xbmc.executebuiltin('xbmc.StartPVRManager')
        else:
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')
            xbmc.sleep(500)
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": false }}')
            xbmc.sleep(500)
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')

        # show a simple notification informing user new IPTV list has been set
        if(listName): listName += ' '
        xbmcgui.Dialog().notification(config.getString(30000), config.getString(30120).format(listName))
