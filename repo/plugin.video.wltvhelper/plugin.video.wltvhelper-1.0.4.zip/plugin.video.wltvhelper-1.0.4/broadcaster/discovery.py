# -*- coding: utf-8 -*-

import requests
from lib import config

api = 'https://disco-api.discoveryplus.it'
token = requests.get(api + '/token?realm=dplayit').json()['data']['attributes']['token']
headers = {'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
           'Referer': 'https://discoveryplus.it',
           'Cookie' : 'st=' + token}

def play(search):
    res = {}
    Id = ''

    json = requests.get(api + '/cms/routes/home?decorators=viewingHistory&include=default', headers=headers).json()['included']

    for key in json:
        if key['type'] == 'channel' \
            and key.get('attributes',{}).get('hasLiveStream', '') \
            and 'Free' in key.get('attributes',{}).get('packages', []) \
            and search == key['attributes']['name']:
            Id = key['id']
            break

    if Id:
        data = requests.get('{}/playback/v2/channelPlaybackInfo/{}?usePreAuth=true'.format(api, Id), headers=headers).json().get('data',{}).get('attributes',{})
        if data['protection'].get('drm_enabled',True):
            if config.getSetting('mpd'):
                res['url'] = data['streaming']['dash']['url']
                res['manifest'] = 'mpd'
                res['key'] = data['protection']['schemes']['widevine']['licenseUrl'] + '|PreAuthorization=' + data['protection']['drmToken'] + '|R{SSM}|'
                res['type'] = 'com.widevine.alpha'
            else:
                res['url'] = data['streaming']['hls']['url']
                res['manifest'] = 'hls'

        else:
            res['url'] = data['streaming']['hls']['url']
            res['manifest'] = 'hls'

    return res