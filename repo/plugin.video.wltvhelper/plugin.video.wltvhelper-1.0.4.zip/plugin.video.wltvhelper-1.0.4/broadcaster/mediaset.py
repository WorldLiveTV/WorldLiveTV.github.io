# -*- coding: utf-8 -*-

import requests
from lib import scrapers

post_url = '?assetTypes=HD,browser,widevine:HD,browser:SD,browser,widevine:SD,browser:SD&auto=true&balance=true&format=smil&formats=MPEG-DASH,MPEG4,M3U&tracking=true'
lic_url = 'https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid=%s&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}' + \
          '|Accept=*/*&Content-Type=&User-Agent=Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0|R{{SSM}}|'

session = requests.Session()
session.headers.update({'Content-Type': 'application/json', 'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
                                'Referer': 'https://www.mediasetplay.mediaset.it'})

def play(search):
    res = {}

    json = session.get('https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations?sort=ShortTitle').json()['entries']

    for it in json:
        urls = []
        if search.startswith("$"):
            _search = "$" + it['callSign']
        else: 
            _search = it['title']

        if it['tuningInstruction'] and not it['mediasetstation$digitalOnly'] and _search == search :
            guide=session.get('https://static3.mediasetplay.mediaset.it/apigw/nownext/' + it['callSign'] + '.json').json()['response']
            if 'restartUrl' in guide['currentListing']:
                urls = [guide['currentListing']['restartUrl']]
            else:
                for key in it['tuningInstruction']['urn:theplatform:tv:location:any']:
                    urls += key['publicUrls']
            break

    for url in urls:
        new_url = session.get(url).url
        if '.mpd' in new_url:
            data = new_url
            sec_data = session.get(url + post_url).text

            uri = scrapers.find_single_match(sec_data, r'<video src="([^"]+)"')
            if uri:
                lic = lic_url % scrapers.find_single_match(sec_data, r'pid=([^|]+)')
                res['url'] = uri
                res['manifest'] = 'mpd'
                res['key'] = lic
                break
        else:
            res = url

    return res