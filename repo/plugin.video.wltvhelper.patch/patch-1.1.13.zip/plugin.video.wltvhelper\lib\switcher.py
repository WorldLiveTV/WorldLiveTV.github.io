# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import sys
from lib import config, install, utils
PY3 = True if sys.version_info[0] >= 3 else False

canChoose = True
simple = install.install_pvr()

if simple:

    addon = config.ADDON
    addonpath = config.ADDONPATH
    data = utils.getRemoteLists() if not config.getSetting('hide_default_list') else []

    personalLists = utils.getPersonalLists()
    for pList in personalLists:
        pList['Official'] = False
        data.append(pList)

    LIST = 1
    CLOSE = 2
    SETTING = 3
    LEFT = 1
    RIGHT = 2
    UP = 3
    DOWN = 4
    EXIT = 10
    BACKSPACE = 92

    class ListSelection(xbmcgui.WindowXMLDialog):
        def __init__(self, *args):
            self.preselected = config.getSetting('selected')
            self.list = []
            self.doModal()

        def onInit(self):
            self.preselected = config.getSetting('selected')
            self.List = self.getControl(LIST)

            for key in data:
                listItem = xbmcgui.ListItem(key['Name'])
                listItem.setProperty('Offical', ''.format(key['Official']))
                self.list.append(listItem)

            self.List.reset()
            self.List.addItems(self.list)
            self.setFocusId(LIST)
            for n, item in enumerate(self.list):
                if item.getLabel() == self.preselected:
                    self.List.selectItem(n)
                    break

        def onClick(self, control):
            if control == LIST:
                selection = self.List.getSelectedPosition()
                selectedList = data[selection]
                config.setSetting('selected', selectedList['Name'])

                m3uList = utils.computeListUrl(selectedList) + '&rewrite=true'

                utils.setList(selectedList['Name'], m3uList, utils.EPG_URL)
                self.exit()
            elif control == CLOSE:
                self.exit()
            elif control == SETTING:
                addon.openSettings()

        def onAction(self, action):
            action = action.getId()
            if action in [EXIT, BACKSPACE, LEFT]:
                self.exit()

        def exit(self):
            self.close()

    if canChoose:
        ListSelection('ListSelection.xml', addonpath, 'Default')
