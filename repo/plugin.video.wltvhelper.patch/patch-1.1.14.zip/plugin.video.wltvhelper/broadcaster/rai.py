# -*- coding: utf-8 -*-

import requests
from lib import logger

def play(search):
    res = {}
    url = ''
    requrl = 'https://www.raiplay.it/dirette.json'
    json = requests.get(requrl).json()['contents']
    for key in json:
        channel = key['channel']
        if search == channel:
            url = key['video']['content_url']
            break

    if url:
        if "relinkerServlet" in url: 
            # force redirect
            url = requests.get(url).url

        res['url'] = url
        res['manifest'] = 'hls'


    return res
