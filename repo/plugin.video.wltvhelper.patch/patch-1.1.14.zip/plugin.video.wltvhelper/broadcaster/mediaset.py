# -*- coding: utf-8 -*-
import xbmcgui
import requests
from lib import config, logger

host =  'https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true'

loginUrl = 'https://api-ott-prod-fe.mediaset.net/PROD/play/idm/anonymous/login/v2.0'
clientid = 'f66e2a01-c619-4e53-8e7c-4761449dd8ee'
loginData = {"client_id": clientid, "platform": "pc", "appName": "web//mediasetplay-web/5.1.493-plus-da8885b"}
res = requests.post(loginUrl, json=loginData, verify=False)
Token = res.json()['response']['beToken']
lic_url = 'https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid={pid}&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}|Accept=*/*&Content-Type=|R{{SSM}}|'

mpd = config.getSetting('mpd')
mpd = False # temporaneamente disattivato per bug di IA

def play(search):
    res = {}
    url = ''
    pid = ''
    if search == '20': mpd = True
    strmFormat = 'dash+xml' if mpd else 'x-mpegURL'

    # get Json
    items = requests.get(host).json()['entries']

    # search

    for item in items:
        if search.startswith("$"):
            _search = "$" + item['callSign']
        else:
            _search = item['title']

        if item.get('tuningInstruction') and _search == search:

            for key in item['tuningInstruction']['urn:theplatform:tv:location:any']:
                if key['format'] == 'application/{}'.format(strmFormat):
                    try:
                        url = key['publicUrls'][0]
                        if mpd and 'widevine' in key['assetTypes']:
                            pid = key['releasePids'][0]
                            break
                        elif not mpd:
                            break
                    except:
                        logger.debug('No PublicUrls for', search, 'with format', strmFormat)

        if url:
            # set manifest for IA
            if mpd:
                res['manifest'] = 'mpd'
                if pid: res['key'] = lic_url.format(pid=pid, token=Token)
                #res['update_parameter'] = 'full'
            else:
                res['manifest'] = 'hls'

            # get real url
            #r = requests.get(url)
            #if(r.status_code==403):
            #    xbmcgui.Dialog().ok("Not Allowed", "Channel view is not allowed")
            #else:
            #    res['url'] = r.url if "theplatform" in url else url
            
            res['url'] = requests.get(url).url if "theplatform" in url else url
            break
        else:
            logger.debug('No url found for', search)

    return res

#def play_old(search):
#    res = {}
#    json = requests.get('https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations?sort=ShortTitle').json()['entries']
#
#    for it in json:
#        urls = []
#        if search.startswith("$"):
#            _search = "$" + it['callSign']
#        else:
#            _search = it['title']
#
#        if it['tuningInstruction'] and not it['mediasetstation$digitalOnly'] and _search == search:
#            for key in it['tuningInstruction']['urn:theplatform:tv:location:any']:
#                if key['format'] == 'application/{}'.format(format):
#                    urls += key['publicUrls']
#            break
#
#    for url in urls:
#        uri = url
#        if "theplatform" in uri:
#            uri = requests.get(uri).url
#
#        if(uri):
#            if mpd: 
#                res['manifest'] = 'mpd'
#                res['update_parameter'] = 'full'
#                break
#            else:
#                res['manifest'] = 'hls'
#                break
#
#    res['url'] = uri
#
#    return res