# -*- coding: utf-8 -*-
import xbmcgui
import requests
from lib import config, logger

host =  'https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true'
mpd = config.getSetting('mpd')
mpd = False # temporaneamente disattivato per bug di IA
strmFormat = 'dash+xml' if mpd else 'x-mpegURL'

def play(search):
    res = {}
    url = ''

    # get Json
    items = requests.get(host).json()['entries']

    # search
    for item in items:
        if search.startswith("$"):
            _search = "$" + item['callSign']
        else:
            _search = item['title']

        if item.get('tuningInstruction') and _search == search:
            for key in item['tuningInstruction']['urn:theplatform:tv:location:any']:
                if key['format'] == 'application/{}'.format(strmFormat):
                    try:
                        url = key['publicUrls'][0]
                        break
                    except:
                        logger.debug('No PublicUrls for', search, 'with format', strmFormat)

        if url:
            # set manifest for IA
            if mpd:
                res['manifest'] = 'mpd'
                #res['update_parameter'] = 'full'
            else:
                res['manifest'] = 'hls'

            # get real url
            #r = requests.get(url)
            #if(r.status_code==403):
            #    xbmcgui.Dialog().ok("Not Allowed", "Channel view is not allowed")
            #else:
            #    res['url'] = r.url if "theplatform" in url else url
            
            res['url'] = requests.get(url).url if "theplatform" in url else url
            break
        else:
            logger.debug('No url found for', search)

    return res

#def play_old(search):
#    res = {}
#    json = requests.get('https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations?sort=ShortTitle').json()['entries']
#
#    for it in json:
#        urls = []
#        if search.startswith("$"):
#            _search = "$" + it['callSign']
#        else:
#            _search = it['title']
#
#        if it['tuningInstruction'] and not it['mediasetstation$digitalOnly'] and _search == search:
#            for key in it['tuningInstruction']['urn:theplatform:tv:location:any']:
#                if key['format'] == 'application/{}'.format(format):
#                    urls += key['publicUrls']
#            break
#
#    for url in urls:
#        uri = url
#        if "theplatform" in uri:
#            uri = requests.get(uri).url
#
#        if(uri):
#            if mpd: 
#                res['manifest'] = 'mpd'
#                res['update_parameter'] = 'full'
#                break
#            else:
#                res['manifest'] = 'hls'
#                break
#
#    res['url'] = uri
#
#    return res