# -*- coding: utf-8 -*-
import requests
from lib import config, logger

host =  'https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true'
mpd = config.getSetting('mpd')
# mpd = False # temporaneamente disattivato per bug di IA
strmFormat = 'dash+xml' if mpd else 'x-mpegURL'


def play(search):
    res = {}
    url = ''

    # get Json
    items = requests.get(host).json()['entries']

    # search
    for item in items:
        if search.startswith("$"):
            _search = "$" + item['callSign']
        else:
            _search = item['title']

        if item.get('tuningInstruction') and _search == search:
            for key in item['tuningInstruction']['urn:theplatform:tv:location:any']:
                if key['format'] == 'application/{}'.format(strmFormat):
                    try:
                        url = key['publicUrls'][0]
                        break
                    except:
                        logger.debug('No PublicUrls for', search, 'with format', strmFormat)

        if url:
            # set manifest for IA
            if mpd:
                res['manifest'] = 'mpd'
                res['update_parameter'] = 'full'
            else:
                res['manifest'] = 'hls'

            # get real url
            res['url'] = requests.head(url).headers['Location'] if "theplatform" in url else url
            break
        else:
            logger.debug('No url found for', search)

    return res
