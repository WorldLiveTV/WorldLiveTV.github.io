import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import routing
import urllib

from lib.install import install, install_inputstream, install_widevine
from lib import logger, config, utils
from xbmcaddon import Addon

PY3 = True if sys.version_info[0] >= 3 else False

plugin = routing.Plugin()

####
# Starting point: the first page appearing to User
####
@plugin.route('/')
def start():
    handle = plugin.handle
    utils.checkSettings()

    # Compose 'MAKER' listitem
    li = xbmcgui.ListItem(config.getString(30010))
    li.setArt({
        'icon': os.path.join(config.ADDONPATH, 'resources', 'compose.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'compose.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'compose.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(maker), listitem=li, isFolder=True)

    # Compose 'SWITCHER' listitem
    li = xbmcgui.ListItem(config.getString(30002))
    li.setArt({
        'icon': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'list.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(switch), listitem=li, isFolder=True)

    # Compose 'Internationals TV' listitem
    li = xbmcgui.ListItem(config.getString(30126))
    li.setArt({
        'icon':  os.path.join(config.ADDONPATH, 'resources', 'globe.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'globe.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'globe.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')
    })
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(worldtv), listitem=li, isFolder=True)

    # Compose 'United Music Radio' listitem
    li = xbmcgui.ListItem(config.getString(30127))
    li.setArt({
        'icon':  os.path.join(config.ADDONPATH, 'resources', 'UnitedMusic_sx.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'UnitedMusic.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'UnitedMusic.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')
    })
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(unitedmusic), listitem=li, isFolder=True)

    # Compose 'SkyLine WebCam' listitem
    li = xbmcgui.ListItem(config.getString(30128))
    li.setArt({
        'icon':  os.path.join(config.ADDONPATH, 'resources', 'webcam.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'webcam.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'webcam.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')
    })
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(skylinewebcams), listitem=li, isFolder=True)

    # Compose 'SETTINGS' listitem
    li = xbmcgui.ListItem(config.getString(30003))
    li.setArt({
        'icon': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'settings.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')})
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(setting), listitem=li, isFolder=True)

    # Compose 'SEND LOG' listitem
    li = xbmcgui.ListItem(config.getString(30122))
    li.setArt({
        'icon': os.path.join(config.ADDONPATH, 'resources', 'log.png'),
        'thumb': os.path.join(config.ADDONPATH, 'resources', 'log.png'),
        'poster': os.path.join(config.ADDONPATH, 'resources', 'log.png'),
        'fanart': os.path.join(config.ADDONPATH, 'resources', 'wltv-background.png')
    })
    xbmcplugin.addDirectoryItem(handle=handle, url=plugin.url_for(uploadLog), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle=handle, succeeded=True)

####
# Open UnitedMusic
###
@plugin.route('/unitedmusic')
@plugin.route('/unitedmusic/showstations/<name>/<code>')
def unitedmusic(name='', code=''):
    from lib import unitedmusic
    unitedmusic

####
# Open Internationals TV section
###
@plugin.route('/worldtv')
@plugin.route('/worldtv/showcountries/<continentcode>')
@plugin.route('/worldtv/switchlist/<name>/<code>')
def worldtv(continentcode='', name='', code=''):
    from lib import worldtv
    worldtv

####
# Open SkyLineWebCams
###
@plugin.route('/skylinewebcams')
@plugin.route('/skylinewebcams/showcountries/<continentcode>')
@plugin.route('/skylinewebcams/showregion/<continentcode>/<countrycode>')
@plugin.route('/skylinewebcams/showcities/<continentcode>/<countrycode>/<regioncode>')
@plugin.route('/skylinewebcams/showwebcams/<continentcode>/<countrycode>/<regioncode>/<citycode>')
def skylinewebcams(continentcode='', countrycode='', regioncode='', citycode=''):
    from lib import skylinewebcams
    skylinewebcams

####
# Start playing importing broadcaster module
####
@plugin.route('/play/<broadcaster>/<channel>')
def play(broadcaster, channel, user_agent=None):
    channel_str = channel #urllib.unquote_plus(channel)

    # import broadcaster and start playing
    c = __import__('broadcaster.' + broadcaster, None, None, ['broadcaster.' + broadcaster])
    res = c.play(channel_str)

    # NOTE: user_agent WON'T be used in this way!
    # it causes error in case of broadcaster!
    makeListItemToPlay(res)

@plugin.route('/play/<broadcaster>/<channel>/<list_name>/<group_id>/<chl_id>')
def playFromTvChannels(broadcaster, channel, list_name, group_id, chl_id):
    user_agent = None
    user_agent_index = chl_id.find('|User')
    if user_agent_index > -1:
        logger.info('{} has user agent! Removing'.format(chl_id))
        user_agent = chl_id[user_agent_index + 1:] # get the UA removing `|`
        chl_id = chl_id[0: user_agent_index]
        logger.info("UserAgent is: '{}'".format(user_agent))

    logger.info('Requested channel for play: ', broadcaster, channel, list_name, group_id, chl_id)

    force_direct_link = config.getSetting('forceDirectLink')

    hasBroadcaster = broadcaster != 'none' and broadcaster != 'none/none'

    logger.info('requested link hasBroadcaster: {}  -  forceDirectLink: {}'.format(hasBroadcaster, force_direct_link))

    if hasBroadcaster and not force_direct_link:
        # forward request to `play()`
        play(broadcaster, channel, user_agent)
    else:
        logger.info('No broadcaster requested or forceDirectLink, proceed with tvchannels')
        # no broadcaster has been requested: proceed forwarding request to tvchannels.
        # Use `list_name` , `group_id` and `chl_id`
        url = '{}/{}/live?channel={}&group={}'.format(utils.API_DOMAIN, list_name, chl_id, group_id)
        logger.info('The url is: ', url)
        makeListItemToPlay(url, user_agent)

@plugin.route('/webcam/<broadcaster>/<country>/<region>/<city>/<part>')
def playWebcam(broadcaster, country, region, city, part):
    link_webcam = country + '/' + region + '/' + city + '/' + part
    play(broadcaster, link_webcam)

####
# Start installing additional/required addons
####
@plugin.route('/install')
def installDeps():
    install()

####
# Switch between iptv lists.
# This method compute the 'tvchannels-url' and put it into PVR Simple Client settings
####
@plugin.route('/switch')
def switch():
    from lib import switcher
    switcher

####
# Open the XML windows in order to compose a personal IPTV list (using 'tvchannels-merge' function)
###
@plugin.route('/maker')
def maker():
    from lib import listmaker
    listmaker

####
# Open addon's settings
####
@plugin.route('/settings')
def setting():
    config.openSettings()

####
# Open Input Helper addon's settings
####
@plugin.route('/openinputhelper')
def openinputhelper():
    input_helper = Addon('script.module.inputstreamhelper')
    input_helper.openSettings()

####
# Cleanup cache files
####
@plugin.route('/cachecleanup')
def cachecleanup():
    utils.cachecleanup()

####
# Force check update
####
@plugin.route('/forcecheckupdate')
def forcecheckupdate():
    utils.forcecheckupdate()

####
# Send log file
####
@plugin.route('/uploadlog')
def uploadLog():
    addon_log_uploader = None
    try:
        addon_log_uploader = Addon('script.kodi.loguploader')
    except:
        logger.info('loguploader seems to be not installed or disabled')

    if not addon_log_uploader:
        xbmc.executebuiltin('InstallAddon(script.kodi.loguploader)', wait=True)
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "script.kodi.loguploader", "enabled": true }}')
        try:
            addon_log_uploader = Addon('script.kodi.loguploader')
        except:
            logger.info('Logfile Uploader cannot be found')

    if not addon_log_uploader:
        logger.info('Cannot send log because Logfile Uploader cannot be found')
        return False

    xbmc.executebuiltin('RunScript(script.kodi.loguploader)')
    return True

####
# Build a fake-listitem in order to set all details to make kodi simply playing
###
def makeListItemToPlay(res, user_agent=None):
    if res:
        # res = string
        # or
        # res = {'url': required,
        #        'manifest': required only for inputstrama, values mpd/hls),
        #        'key': optional, required for drm streams,
        #        'type': optional, default 'com.widevine.alpha'}

        url = None
        Manifest = None
        Key = None
        Type = None
        ManifestParameter = None

        if type(res) == dict:
            logger.info('stream is a DICT')
            url = res.get('url','')
            Manifest = res.get('manifest','')
            Key = res.get('key','')
            Type = res.get('Type','com.widevine.alpha')
            ManifestParameter = res.get('update_parameter', '')
        else:
            logger.info('stream is a STRING')
            url = res
            Manifest = 'mpd' if '.mpd' in url else ''

        xlistitem = None

        if url:
            # make item
            if user_agent:
                logger.info("UA will be appending: {}".format(user_agent))
                url = url + "|{}".format(user_agent)
            xlistitem = xbmcgui.ListItem(path=url)
            logger.info('Playing: ', url)


        if not xlistitem:
            logger.error('NO URL found for channel')
            xbmcgui.Dialog().notification(config.getString(30000), config.getString(30123), xbmcgui.NOTIFICATION_WARNING)
            return

        if Manifest:
            install_inputstream() # Check if inputstream is installed otherwise install it

            # add parameters for inputstream
            xlistitem.setProperty('inputstream' if PY3 else 'inputstreamaddon', 'inputstream.adaptive')
            xlistitem.setProperty('inputstream.adaptive.manifest_type', Manifest)
            xlistitem.setMimeType('application/dash+xml' if Manifest == 'mpd' else 'application/x-mpegURL')

            if ManifestParameter:
                xlistitem.setProperty('inputstream.adaptive.manifest_update_parameter', ManifestParameter)

        if Key:
            # add parameters for drm
            install_widevine()
            xlistitem.setProperty("inputstream.adaptive.license_key", Key)
            xlistitem.setProperty("inputstream.adaptive.license_type", Type)

        force_stop_for_switch = config.getSetting('forceStopForSwitch')

        # Stop Video Before Playing (For underperforming devices)
        if force_stop_for_switch:
            logger.info('force stop as per user settings')
            xbmc.Player().stop()

        # play item
        xbmcplugin.setResolvedUrl(plugin.handle, True, xlistitem)

# start router
utils.checkForUpdates()
plugin.run()
