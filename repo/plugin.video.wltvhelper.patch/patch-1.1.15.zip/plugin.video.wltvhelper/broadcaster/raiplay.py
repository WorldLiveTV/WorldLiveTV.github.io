# -*- coding: utf-8 -*-

import requests
from lib import config, logger

def play(search):
    res = {}
    url = ''
    requrl = 'https://www.raiplay.it/dirette.json'
    json = requests.get(requrl).json()['contents']
    for key in json:
        channel = key['channel']
        if search == channel:
            url = key['video']['content_url']
            break

    if url:
        urlKey=''
        url = url + "&output=62&forceUserAgent=hbbtv"
        json = requests.get(url).json()
        url = json["video"][0]
        logger.info("json: ", json)
        if('drmLicenseUrlValues' in json['licence_server_map']):
            urlKey = json['licence_server_map']['drmLicenseUrlValues'][0]['licenceUrl'] 
            #+ '|Accept=*/*&Content-Type=|R{{SSM}}|'
        logger.info("url: ", url)
        logger.info("urlKey: ", urlKey)
        res['url'] = url
        if(urlKey != ''):
            res['key'] = urlKey
            res['type'] = 'com.microsoft.playready'
            res['licence_key'] = urlKey
            res['licence_type'] = 'com.microsoft.playready'

        res['manifest'] = 'mpd'
        
        
        
        #res['update_parameter'] = 'full'
        #res['url'] = requests.get(url).url if "relinkerServlet" in url else url

        #if not ".mp4" in url:
        #    res['manifest'] = 'hls'

    return res



#from urllib3.exceptions import InsecureRequestWarning
#import xbmcgui
#
#
#requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
#
#host =  'https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true'
#loginUrl = 'https://api-ott-prod-fe.mediaset.net/PROD/play/idm/anonymous/login/v2.0'
#clientid = 'f66e2a01-c619-4e53-8e7c-4761449dd8ee'
#loginData = {"client_id": clientid, "platform": "pc", "appName": "web//mediasetplay-web/5.1.493-plus-da8885b"}
#lic_url = 'https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid={pid}&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}|Accept=*/*&Content-Type=|R{{SSM}}|'
#
#def play1(search):
#   mpd = config.getSetting('mpd')
#   mpd = False # temporaneamente disattivato per bug di IA
#   if search == '20': mpd = True
#
#   tkRes = requests.post(loginUrl, json=loginData, verify=False)
#   Token = tkRes.json()['response']['beToken']
#   res = {}
#   url = ''
#   pid = ''
#
#   strmFormat = 'dash+xml' if mpd else 'x-mpegURL'
#
#   # get Json
#   items = requests.get(host).json()['entries']
#
#   # search
#   for item in items:
#       if search.startswith("$"):
#           _search = "$" + item['callSign']
#       else:
#           _search = item['title']
#
#       if item.get('tuningInstruction') and _search == search:
#
#           for key in item['tuningInstruction']['urn:theplatform:tv:location:any']:
#               if key['format'] == 'application/{}'.format(strmFormat):
#                   try:
#                       url = key['publicUrls'][0]
#                       if mpd and 'widevine' in key['assetTypes']:
#                           pid = key['releasePids'][0]
#                           break
#                       elif not mpd:
#                           break
#                   except:
#                       logger.debug('No PublicUrls for', search, 'with format', strmFormat)
#
#       if url:
#           # set manifest for IA
#           if mpd:
#               res['manifest'] = 'mpd'
#               if pid: res['key'] = lic_url.format(pid=pid, token=Token)
#               #res['update_parameter'] = 'full'
#           else:
#               res['manifest'] = 'hls'
#
#           # get real url
#           #r = requests.get(url)
#           #if(r.status_code==403):
#           #    xbmcgui.Dialog().ok("Not Allowed", "Channel view is not allowed")
#           #else:
#           #    res['url'] = r.url if "theplatform" in url else url
#           
#           res['url'] = requests.get(url).url if "theplatform" in url else url
#           break
#       else:
#           logger.debug('No url found for', search)
#
#   return res
#