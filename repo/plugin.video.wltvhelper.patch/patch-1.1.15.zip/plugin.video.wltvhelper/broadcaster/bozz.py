# -*- coding: utf-8 -*-

##EXTINF:-1 group-title="Campania",TSB Napoli
#https://tna5.bozztv.com/TSB3/index.m3u8

import requests
from lib import scrapers, config, logger

ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
baseUrl = 'https://ssh101.com/securelive/index.php?id='
#baseUrl = 'https://tna5.bozztv.com/TSB3/index.m3u8'

session = requests.Session()
session.headers.update({'Content-Type': 'text/html', 
                        'User-Agent': ua,
                        'Referer': 'https://ssh101.com/'})

def play(search):
    res = {}
    #key = session.get('https://ssh101.com/aes/aeskey.php?keyslive&TSB3/10846.key').text
    #key2 = requests.get('https://ssh101.com/aes/aeskey.php?keyslive&TSB3/10846.key').text
    #logger.info('key:',key)
    #logger.info('key2:',key2)
    data = session.get(baseUrl+search).text
    uri = scrapers.find_single_match(data, r'<source src="([^"]+)"')
    logger.info('uri ==> :',uri)
    k='PHPSESSID=21b936c5885046c65e6947e82b244249'
    ref = 'https://ssh101.com/detail.php?id=TSB3'

    res['manifest'] = 'hls'
    #res['update_parameter'] = 'full'
    #res['license_type']='com.widevine.alpha'
    sh = 'Accept=*/*&Content-Type=text/html&Cookie={}&User-Agent={}&Referer={}'.format(k,ua,ref)
    logger.info('sh ==> :',sh)
    res['stream_headers'] = sh
    #res['METHOD'] = 'AES-128'    
    
    res['url'] = uri

    return res
