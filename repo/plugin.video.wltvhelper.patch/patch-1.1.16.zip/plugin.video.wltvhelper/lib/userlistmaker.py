# -*- coding: utf-8 -*-
import xbmc, xbmcgui, json
from lib import config, logger, utils

# remoteLists = utils.apiRequester('/all/groups.json')
setting = config.getSetting(utils.PARAM_USER_LIST_NAME)

MAKER = 100
LIST = 200
GROUPS = 300

BACK = 400
OPTIONS = 201
MU = 101
MD = 102
DELETE = 103
EXIT = 10
BACKSPACE = 92


def compiledialog(params={}):
    return CompileDialog("CompileDialog.xml", config.ADDON_PATH, "Default").start(params=params)


class CompileDialog(xbmcgui.WindowXMLDialog):
    def start(self, params):
        self.name = params.get("Name", "")
        self.list = params.get("List", "")
        self.epg  = params.get("Epg", "")
        self.valid = False
        self.doModal()
        return (
            self.valid,
            self.getControl(1).getText(),
            self.getControl(21).getText(),
            self.getControl(31).getText(),
        )

    def onInit(self):
        self.getControl(1).setText(self.name)
        self.getControl(21).setText(self.list)
        self.getControl(31).setText(self.epg)
        self.setFocusId(1)

    def onClick(self, control):
        if control == 22:
            self.getControl(21).setText(xbmcgui.Dialog().browse(1, config.getString(30002), "", ".m3u|.m3u8", True, False))
        if control == 32:
            self.getControl(31).setText(xbmcgui.Dialog().browse(1, config.getString(30135), "", ".gz|.gzip|.xz|.xml", True, False))
        if control == 41:
            self.valid = True
            self.close()
        elif control == 42:
            self.close()


class UserListMaker(xbmcgui.WindowXMLDialog):
    def start(self, windowType, param):
        self.windowType = windowType  # integer of MAKER, LIST, GROUPS
        self.param = param
        self.setting = json.loads(setting) if setting else []
        self.Choose = {}
        self.Groups = []
        self.doModal()

    def onInit(self):
        self.list = []
        self.List = self.getControl(self.windowType)
        for key in self.setting:
            self.list.append(xbmcgui.ListItem(key["Name"]))  # Personal Lists
        self.list.append(xbmcgui.ListItem(""))  # Add Button

        self.loadList(0)

    def onClick(self, control):
        logger.debug("CONTROL", control)
        focus = self.getFocusId()
        if control == MAKER:
            pos = self.List.getSelectedPosition()
            selection = self.List.getListItem(pos)
            if not selection.getLabel():
                valid, name, list, epg = compiledialog()
                if valid:
                    if not name:
                        name = "Lista {}".format(len(self.setting) + 1)
                    item = xbmcgui.ListItem(name)
                    self.list.insert(-1, item)
                    self.setting.append({"Name": name, "List": list, "Epg": epg})
            else:
                valid, name, list, epg = compiledialog(
                    {
                        "Name": self.setting[pos].get("Name", ""),
                        "List": self.setting[pos].get("List", ""),
                        "Epg" : self.setting[pos].get("Epg", ""),
                    }
                )
                if valid:
                    if not name:
                        name = "Lista {}".format(len(self.setting) + 1)
                    item = xbmcgui.ListItem(name)
                    self.list[pos] = item
                    self.setting[pos] = {
                        "Name": self.setting[pos].get("Name", ""),
                        "List": self.setting[pos].get("List", ""),
                        "Epg" : self.setting[pos].get("Epg", ""),
                    }

            self.save()
            self.loadList(pos)

        elif control in [MU]:
            p1 = self.List.getSelectedPosition()
            p2 = p1 - 1
            if p2 > -1:
                self.list[p1], self.list[p2] = self.list[p2], self.list[p1]
                self.setting[p1], self.setting[p2] = self.setting[p2], self.setting[p1]
                self.save()
                self.loadList(p2, MU)

        elif control in [MD]:
            p1 = self.List.getSelectedPosition()
            p2 = p1 + 1
            if p2 < len(self.list) - 1:
                self.list[p1], self.list[p2] = self.list[p2], self.list[p1]
                self.setting[p1], self.setting[p2] = self.setting[p2], self.setting[p1]
                self.save()
                self.loadList(p2, MD)

        elif control in [DELETE]:
            pos = self.List.getSelectedPosition()
            self.list.pop(pos)
            self.setting.pop(pos)
            self.save()
            self.loadList(pos)

        elif control in [BACK]:
            self.close()

    def onAction(self, action):
        action = action.getId()
        if action in [EXIT, BACKSPACE]:
            self.close()

    def loadList(self, pos, button=None):
        self.List.reset()
        self.List.addItems(self.list)
        self.setFocusId(self.windowType)
        self.List.selectItem(pos)
        if button:
            self.setFocusId(button)

    def save(self):
        config.setSetting(utils.PARAM_USER_LIST_NAME, json.dumps(self.setting))


def launch(windowType=MAKER, param=None):
    return UserListMaker("UserListMaker.xml", config.ADDON_PATH, "Default").start(windowType=windowType, param=param)


launch()
