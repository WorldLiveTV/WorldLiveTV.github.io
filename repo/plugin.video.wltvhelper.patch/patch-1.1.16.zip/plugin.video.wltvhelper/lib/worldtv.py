# Module: WorldLiveTV
# Author: CrAcK75
# Created on: 06/05/2021
#
#
import os
import sys
import xbmcgui
import xbmcplugin
import requests
import routing
import json
from lib import logger, config, utils

_name = 'WorldLiveTV'
fileName = 'listIntChannels.bin'
plugin = routing.Plugin()

@plugin.route('/worldtv')
def Start():
    ShowContinentsList()

def ShowContinentsList():
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, 'International TVs')

    imagedir = 'world'
    lstItem = GetLists()
    if (not lstItem): return

    for item in lstItem['worlditems']:
        name = item['name']
        code = item['code']
        png = '{}.png'.format(code)

        li = xbmcgui.ListItem(name)

        li.setArt({
            'thumb':  os.path.join(config.ADDON_PATH, 'resources', imagedir, png),
            'poster': os.path.join(config.ADDON_PATH, 'resources', imagedir, png),
            'fanart': os.path.join(config.ADDON_PATH, 'resources', imagedir, png),
            })

        url = plugin.url_for(ShowCountries, code)
        xbmcplugin.addDirectoryItem(handle, url, li, True)

    xbmcplugin.endOfDirectory(handle)

@plugin.route('/worldtv/showcountries/<continentcode>')
def ShowCountries(continentcode):
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, continentcode)

    lstItem = GetLists()
    lstItem = GetItems(continentcode, lstItem)
    for item in lstItem['worlditems']:
        code = item['code']
        name = item['name']
        url = item['url']
        png = '{}.png'.format(code)
        if (code == 'it'): continue

        li = xbmcgui.ListItem(name)
        li.setArt({
            'icon': os.path.join(config.ADDON_PATH, 'resources','flags', png),
            'thumb': os.path.join(config.ADDON_PATH, 'resources','flags', png),
           #'poster': os.path.join(config.ADDONPATH, 'resources','flags', png),
            'fanart': os.path.join(config.ADDON_PATH, 'resources', 'background.png')
            })

        url = plugin.url_for(SwitchList, name, url)
        xbmcplugin.addDirectoryItem(handle, url, li, True)

    xbmcplugin.addSortMethod(handle , xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle , True)

def GetCountries(continentcode):
    return [x for x in ContinentsList if x['code'] == continentcode][0]['worlditems']

@plugin.route('/worldtv/switchlist/<name>/<code>')
def SwitchList(name, code):
    handle = plugin.handle
    url = utils.decodeFromBase64(code).decode()

    if handle == -1:
        utils.setList(name, url, '')
    else:
        import logging
        from lib.m3uParser import m3uParser

        m3u = m3uParser.m3uParser(logger)
        m3u.exclusion = ["51.52.156.22:8888"]
        m3u.loadM3u(url, utils.getPersonalPathFile("~temp.dat"))
        CreateListItems(name, m3u.files)

def CreateListItems(name, listitems):
    handle = plugin.handle
    xbmcplugin.setPluginCategory(handle, name)
    xbmcplugin.setContent(handle, 'videos')

    imagedir = ''
    for item in listitems:
        title = item['title']
        tvgname = item['tvg-name']
        tvgid = item['tvg-id']     
        tvglogo = item['tvg-logo']   
        tvggroup = item['tvg-group']  
        url = item['link']       
        
        li = xbmcgui.ListItem(title)
        li.setInfo('video', {'title': title, 'genre': '', 'mediatype': 'video'})
        li.setArt({
            'icon': tvglogo,
            'thumb': tvglogo,
            'poster': tvglogo,
            'fanart': tvglogo,
            })

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle, url, li, False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)

def GetItems(code, lstItem):
    lstItem = [x for x in lstItem['worlditems'] if x['code'] == code][0]
    return lstItem

def GetLists():
    strJson = ''

    try :
        compressed = utils.readLocalOrDownload(fileName)
        strJson = utils.decompress(compressed)
        strJson = json.loads(strJson)
    except Exception as e:
        strJson = ''
        logger.info('GetLists error:', e)
    
    if (strJson == ''):
        xbmcgui.Dialog().notification(config.getString(30000), 'Service Not available')

    return strJson

plugin.run()
