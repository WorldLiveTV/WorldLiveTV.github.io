# -*- coding: utf-8 -*-

import requests
from lib import config, utils, logger

host = "https://www.dreamturk.com.tr/actions/content/media/566ab958980ea810b4658d96"


def play(search):
    res = {}
    url = ""

    json = requests.get(host).json()
    logger.info(json)
    url = json["Media"]["Link"]["ServiceUrl"] + json["Media"]["Link"]["SecurePath"]
    if url:
        res["url"] = url
        res["manifest"] = "hls"
        res["header"] = "user-agent={}".format(utils.USER_AGENT)

    return res
