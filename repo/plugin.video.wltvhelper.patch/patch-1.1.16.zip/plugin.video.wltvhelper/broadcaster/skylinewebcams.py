# -*- coding: utf-8 -*-
import requests
from lib import utils, scrapers

HOST = "www.skylinewebcams.com"
BASE_URL = "https://www.skylinewebcams.com/it/webcam/"
BASE_URL_STREAMS = "https://hd-auth.skylinewebcams.com/"

headers = {
    "host": HOST,
    "user-agent": utils.USER_AGENT,
    "accept": "text/html,application/xhtml+xml,application/xml",
    "accept-language": "en,en-US;q=0.9,it;q=0.8",
    "origin": HOST,
    "referer": HOST,
}


def play(link_part):
    url = BASE_URL + link_part + ".html"
    data = requests.get(url, headers=headers).text

    m3u8 = scrapers.find_single_match(data, r"source:\'(.*m3u8.*?)\'")
    stream = BASE_URL_STREAMS + m3u8.replace("livee.", "live.")

    if not m3u8:  # try to find YT channel
        m3u8 = scrapers.find_single_match(data, r"videoId:\'(.*?)\'")
        stream = "plugin://plugin.video.youtube/play/?video_id={}".format(m3u8)

    return stream
