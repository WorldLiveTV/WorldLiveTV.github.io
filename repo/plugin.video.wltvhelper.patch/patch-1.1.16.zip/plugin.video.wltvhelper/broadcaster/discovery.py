# -*- coding: utf-8 -*-

def play(search):
    return {}
