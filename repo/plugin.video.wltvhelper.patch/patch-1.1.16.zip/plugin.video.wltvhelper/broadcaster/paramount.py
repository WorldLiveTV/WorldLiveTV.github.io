# -*- coding: utf-8 -*-
import requests
from lib import scrapers, config, logger

host = 'https://www.paramountnetwork.it'
def play(search):
    res = {}
    url = 'https://www.paramountnetwork.it/diretta-tv/1iwm9n/vh1'
    #data = requests.get(host).text
    #matches = scrapers.find_multiple_matches(data, r'(/diretta-tv/[^"]+)"[^>]+>([^ ]+)')
    #for url, title in matches:
    #    if title == search:
    #        url = host + url
    #        break
    if url:
        data = requests.get(url).text
        mgid = scrapers.find_single_match(data, r'uri":"([^"]+)"')
        url = 'https://media.mtvnservices.com/pmt/e1/access/index.html?uri=' + mgid + '&configtype=edge&ref=' + url
        data = requests.get(url).text
        ID = scrapers.find_single_match(data, r'"id":"([^"]+)"')
        url = scrapers.find_single_match(data, r'brightcove_mediagenRootURL":"([^"]+)"')
        url = requests.get(url.replace('&device={device}','').format(uri = ID)).json()['package']['video']['item'][0]['rendition'][0]['src']
        res['url'] = url
        res['manifest'] = 'hls'
    return res