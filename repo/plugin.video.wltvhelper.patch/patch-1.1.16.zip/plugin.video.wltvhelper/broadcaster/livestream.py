# -*- coding: utf-8 -*-

import requests
from lib import config, logger

api = "https://player-api.new.livestream.com"

mpd = config.getSetting("mpd")
# if not utils.PY3():
mpd = False  # temporaneamente disattivato per bug di IA


def play(search):
    accountId = search.split("$")[0]
    eventId = search.split("$")[1]
    res = {}
    url = ""

    url = requests.get("{}/accounts/{}/events/{}/stream_info".format(api, accountId, eventId)).json()["secure_m3u8_url"]

    if url:
        res["url"] = url
        res["manifest"] = "hls"

    return res

