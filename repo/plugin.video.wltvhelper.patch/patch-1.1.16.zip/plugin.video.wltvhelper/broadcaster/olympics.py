# -*- coding: utf-8 -*-

import requests

from lib import utils
from datetime import datetime, timezone

host = "https://olympics.com"

headers = {"User-Agent": utils.USER_AGENT, "Referer": host}


def play(search):
    ts = int(datetime.now(tz=timezone.utc).timestamp() * 1000)

    urlBase = ""
    url = ""
    res = {}
    jsonChannels = requests.get(host + "/it/api/v1/d3vp/epgchannels/linear/live-channels").json()

    for ch in jsonChannels:
        if ch["slug"] == search:
            urlBase = ch["src"]

    if urlBase:
        tokenUrl = "{}/tokenGenerator?url={}&domain=https://ott-dai-oc.akamaized.net&_ts={}".format(host, urlBase, ts)
        url = requests.get(tokenUrl).json()

    if url:
        res["url"] = "{}|user-agent={}".format(url, utils.USER_AGENT)

    return res
