# -*- coding: utf-8 -*-

import requests, json
from lib import scrapers, config, utils, logger


def play(search):
    res = {}
    channels = {"SMRTV": 0, "SMRTVS": 1}
    url = ""

    if search in channels:
        requrl = "https://catchup.acdsolutions.it/jstag/videoplayerLiveFluid/TV?ch={}".format(channels[search])
        data = requests.get(requrl).text
        matchedJson = scrapers.find_single_match(data, r"'playerElement',([^)]+)")

        if matchedJson:
            _json = json.loads(matchedJson)
            url = _json["sources"][0]["src"]
            res["url"] = url
            res["manifest"] = "hls"

    return res
