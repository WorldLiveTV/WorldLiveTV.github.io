# -*- coding: utf-8 -*-

import requests, json
from datetime import datetime
from lib import scrapers, config, logger

host = "https://www.rainews.it"

# Select mpd or hls
mpd = config.getSetting("mpd")
manifest = "mpd" if mpd else "hls"
streamTypeLive = "mediaUri" if mpd else "m3u8"


def play(search):
    res = {}
    url = ""
    live = False

    data = requests.get("{}/tgr/{}/notiziari".format(host, search)).text
    strWashiContext = scrapers.find_single_match(data, r"WashiContext\s?=\s?(.*?);")

    if strWashiContext:
        strJson = json.loads(strWashiContext)
        strJson = strJson["itemToPlay"]
        live = strJson["data_type"] == "diretta"
        matchedUrl = strJson["content_url"]
    else:
        weekday = [1, 2, 3, 4, 5, 6, 0]
        today = datetime.now()
        date = today.date()
        dayNumber = weekday[today.weekday()]
        hour = today.hour * 60 + today.minute

        schedule = requests.get( host + "/dl/rai24/assets/json/palinsesto-tgr.json" ).json()

        for key, value in schedule.items():
            for v in value:
                start = int(v["from"].split(":")[0]) * 60 + int(v["from"].split(":")[1])
                end = int(v["to"].split(":")[0]) * 60 + int(v["to"].split(":")[1])
                if start <= hour < end and ( "days" in v and dayNumber in v["days"] or "day" in v and v["day"] == date ):
                    live = True
                    break
                if live:
                    break

    if strWashiContext:
        if live:
            url = requests.get(matchedUrl + "&output=47").json().get("video", [""])[0]
        else:
            url = requests.get(matchedUrl).url
    else:
        if live:
            data = requests.get("{}/tgr/{}/notiziari/index.html?/tgr/live.html".format(host, search)).text
            matchedUrl = scrapers.find_single_match(data, streamTypeLive + r'\s*:\s*"([^"]+)')
            if matchedUrl:
                url = (requests.get(matchedUrl + "&output=47").json().get("video", [""])[0])
                res["manifest"] = manifest

            else:
                live = False

        if not live:
            data = requests.get("{}/tgr/{}/notiziari/index.html?/tgr/rainews.html".format(host, search)).text
            url = scrapers.find_single_match(data, r'data-mediaurl="(.*?)"')
            #if url == "":
            #    url = scrapers.find_single_match(data, r'mediaUrl":"(.*?)"')
            url = requests.get(url).url

    res["url"] = url
    return res