# -*- coding: utf-8 -*-

import requests
import xmltodict
from lib import scrapers, config, utils, logger

host = "https://diretta.tv2000.it/"
drmApiUrl = "api/drm/status"
liveChannelUrl = "?channel=tv2000_live"
m3u8XmlUrl = "https://mediatv2000-meride-tv.akamaized.net/proxy/bulkproxynew/embedproxy_bulk.php/{}/tv2000/desktop/NO_LABEL/f4m/default/aHR0cHM6Ly9kaXJldHRhLnR2MjAwMC5pdC8q"

#host = "https://mediatv2000-meride-tv.akamaized.net/proxy/bulkproxynew/embedproxy_bulk.php/U9Z2sXrihW/tv2000/desktop/NO_LABEL/f4m/default/aHR0cHM6Ly9kaXJldHRhLnR2MjAwMC5pdC8q"

#      var nonRestrictedEmbedID = "U9Z2sXrihW";
#      var playreadyEmbedID = "Why02Y6L6h";
#      var widevineEmbedID = "Why02Y6L6h";
#      var fairplayEmbedID = "y1uyIc87ZQ";
#      var fallbackEmbedID = "cvrQnmgPBx";
#      var customerID = "tv2000";


def play(search):
    res = {}
    url = ""
    nonRestrictedEmbedID = ""
    widevineLicenseUrl = "https://widevine-dash.ezdrm.com/proxy?pX=A90BE1"

    # https://diretta.tv2000.it/api/drm/status
    isDrmJson = requests.get("{}{}".format(host, drmApiUrl)).json()
    isDrm = isDrmJson["active"] == "true"

    if isDrm:
        res["manifest"] = "mpd"
        pass
    else:
        data = requests.get("{}{}".format(host, liveChannelUrl)).text
        nonRestrictedEmbedID = scrapers.find_single_match(data, r'var\snonRestrictedEmbedID\s=\s"(.*?)"')
        strXml = requests.get(m3u8XmlUrl.format(nonRestrictedEmbedID)).text
        xml = xmltodict.parse(strXml)
        url = xml["embed"]["video"]["default"]


    logger.info(url)

    if url:
        #res["header"] = "user-agent={}".format(utils.USER_AGENT)
        res["url"] = url

    return res
