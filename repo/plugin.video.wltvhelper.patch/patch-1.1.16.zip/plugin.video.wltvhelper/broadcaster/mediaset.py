# -*- coding: utf-8 -*-
from urllib3.exceptions import InsecureRequestWarning
import xbmcgui
import uuid, requests
from lib import config, utils, logger

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

host =  'https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true'
loginUrl = 'https://api-ott-prod-fe.mediaset.net/PROD/play/idm/anonymous/login/v2.0'
lic_url = 'https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid={pid}&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}|Accept=*/*&Content-Type=|R{{SSM}}|'
clientid = str(uuid.uuid1()) #'f66e2a01-c619-4e53-8e7c-4761449dd8ee'
loginData = {"client_id": clientid, "platform": "pc", "appName": "web//mediasetplay-web/5.1.497-plus-101613c"}

def play(search):
    mpd = config.getSetting('mpd')
    #mpd = False # temporaneamente disattivato per bug di IA
    #if search == '20': mpd = True

    tkRes = requests.post(loginUrl, json=loginData, verify=False)
    Token = tkRes.json()['response']['beToken']
    res = {}
    url = ''
    pid = ''

    strmFormat = 'dash+xml' if mpd else 'x-mpegURL'

    # get Json
    items = requests.get(host).json()['entries']

    # search
    for item in items:
        if search.startswith("$"):
            _search = "$" + item['callSign']
        else:
            _search = item['title']

        if item.get('tuningInstruction') and _search == search:

            for key in item['tuningInstruction']['urn:theplatform:tv:location:any']:
                if key['format'] == 'application/{}'.format(strmFormat):
                    try:
                        url = key['publicUrls'][0]
                        if mpd and 'widevine' in key['assetTypes']:
                            pid = key['releasePids'][0]
                            break
                        elif not mpd:
                            break
                    except:
                        logger.debug('No PublicUrls for', search, 'with format', strmFormat)

        if url:
            # set manifest for IA
            if mpd:
                res['manifest'] = 'mpd'
                if pid: res['key'] = lic_url.format(pid=pid, token=Token)
                res['update_parameter'] = 'full'
            else:
                res['manifest'] = 'hls'

            url = requests.get(url).url if "theplatform" in url else url
            url = url + '|user-agent={}'.format(utils.USER_AGENT)
            res['url'] = url
            break
        else:
            logger.debug('No url found for', search)

    return res
