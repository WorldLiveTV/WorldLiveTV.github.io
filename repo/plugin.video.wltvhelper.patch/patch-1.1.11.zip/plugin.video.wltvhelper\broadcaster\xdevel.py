# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config, logger

api = 'https://play.xdevel.com'

mpd = config.getSetting('mpd')
#if not utils.PY3():
mpd = False #temporaneamente disattivato per bug di IA

def play(search):
    res = {}
    url = ''

    data = requests.get('{}/{}'.format(api, search)).text
    matches = scrapers.find_multiple_matches(data, r"source\":\"([^\"]+)[^*]+PLAYER_WAS\s?=\s?'([^']+)") #source\":\"([^\"]+)|PLAYER_WAS\s?=\s?'([^']+)")
    
    for urltemp, key in matches:
        url = '{}?wmsAuthSign={}'.format(urltemp, key)
        break

    return url

    #if url:
    #    res['url'] = url
    #    res['manifest'] = 'hls'

    #return res

