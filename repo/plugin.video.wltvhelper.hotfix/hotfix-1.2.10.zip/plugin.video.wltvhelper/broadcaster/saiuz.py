# -*- coding: utf-8 -*-

import requests, uuid
from lib import scrapers, logger
from lib.broadcaster_result import BroadcasterResult
from urllib.parse import urlencode

#http://media.latuatv.eu:8096/emby/Users/authenticatebyname?X-Emby-Client=Emby%20Web&X-Emby-Device-Name=Chrome%20Windows&X-Emby-Device-Id=4b23e01d-b847-42f7-b136-db1dc8bc6186&X-Emby-Client-Version=4.7.14.0&X-Emby-Language=it

def play(search):
    res = BroadcasterResult()
    url = ""
    
    HOST = "http://media.latuatv.eu:8096"

    clientId = str(uuid.uuid1())
    
    querystringParameters = {
        "X-Emby-Client":"Emby%20Web",
        "X-Emby-Device-Name":"Chrome%20Windows",
        "X-Emby-Device-Id":clientId,
        "X-Emby-Client-Version":"4.8.0.0",
        "X-Emby-Language":"it",
    }
    login = {}

    data = {"Username":"ospite"}
    querystring = urlencode(querystringParameters)
    dataUrl = f"{HOST}/emby/Users/authenticatebyname?{querystring}"
    jsonData = requests.post(dataUrl, data = data).json()

    tk = jsonData.get("AccessToken", "")
    userId = jsonData.get("SessionInfo", {}).get("UserId", "")
    
    querystringParameters["X-Emby-Token"] = tk
    querystringParameters["UserId"] = userId
    
    # querystringParametersLC = querystringParameters
    # querystringParametersLC["IsAiring"] = "true"
    # querystringParametersLC["ImageTypeLimit"] = 1
    # querystringParametersLC["EnableImageTypes"] = "Primary%2CBackdrop%2CThumb"
    # querystringParametersLC["Fields"] = "BasicSyncInfo%2CCanDelete%2CContainer%2CProgramPrimaryImageAspectRatio"
    # querystringParametersLC["EnableUserData"] = "false"
    # querystringParametersLC["Limit"] = 100
    # querystringParametersLC["SortBy"] = "DefaultChannelOrder"
    # querystringParametersLC["SortOrder"] = "Ascending"
    
    # querystring = urlencode(querystringParametersLC)
    # dataUrl = f"{HOST}/emby/LiveTv/Channels?{querystring}"
    # jsonData = requests.get(dataUrl).json()

    #chId = jsonData......get("Id", "")
    
    querystringParametersItem = querystringParameters
    querystringParametersItem["StartTimeTicks"] = 0
    querystringParametersItem["IsPlayback"] = "true"
    querystringParametersItem["AutoOpenLiveStream"] = "true"
    querystringParametersItem["MaxStreamingBitrate"] = 5985000
    querystringParametersItem["reqformat"] = "json"
    
    querystring = urlencode(querystringParametersItem)
    dataUrl = f"{HOST}/emby/Items/{search}/PlaybackInfo?{querystring}"
    jsonData = requests.get(dataUrl).json()

    ms = jsonData.get("MediaSources", [])
    if ms:
        url = ms[0].get("Path", "")

    if url:
        res.Url = url

    return res

def play_old(search):
    res = BroadcasterResult()
    url = ""
    
    LIVE_CHANNEL_URL = "/{}.html"

    options = {
        "la-webtv": "http://www.flytv.uk/p"
    }

    HOST = "https://www.radiosaiuz.it"
    if search in options.keys():
        HOST = options[search]

    page_url = f"{HOST}{LIVE_CHANNEL_URL.format(search)}"
    data = requests.get(page_url).text

    url = scrapers.findSingleMatch(data, r"\"sourceURL\":\"([^\"]+)")
    if not url:
        url = scrapers.findSingleMatch(data, r"source\ssrc=\"([^\"]+)\"\s+type=\"application")

    if url:
        res.Url = url

    return res
