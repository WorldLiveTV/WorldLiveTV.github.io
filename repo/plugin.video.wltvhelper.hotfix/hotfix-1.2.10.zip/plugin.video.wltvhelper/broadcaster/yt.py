# -*- coding: utf-8 -*-
# youtube channel & video broadcaster

#example: 
    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO",Abao a Tokyo1
    #   plugin://plugin.video.wltvhelper/play/yt/c/UC84whx2xxsiA1gXHXXqKGOA/videoname

    #   plugin://plugin.video.wltvhelper/play/yt/c/@TeleuropaNetwork/Live TEN Tv

    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO",VIDEO YT
    #   plugin://plugin.video.wltvhelper/play/yt/v/TbhcfUPYKEU/-

import json
import requests
from urllib.parse import unquote
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

def play(chtype:str,chId:str,chName:str):
    chName = unquote(chName)
    if chtype == "c":
        return playChannel(chId,chName)
    elif chtype == "v":
        return playVideo(chId)
    else:
        return playVideo(chId)


def playChannel(chId:str,chName:str):
    HOST = "https://www.youtube.com"

    if chId.startswith('@'):
        videoInfoUrl = f"/{chId}"
    else:
        videoInfoUrl = f"/channel/{chId}"

    videoId = ""

    headers = utils.getBrowserHeaders();
    headers["Cookie"] ="YSC=uhMbKwwwD3g; CONSENT=YES+cb.20300101-18-p0.it+FX+133; GPS=1; VISITOR_INFO1_LIVE=NnmAzzluXtu; PREF=tz=Europe.Rome"
  
    data = requests.get(f"{HOST}{videoInfoUrl}", headers=headers).text 
    regex = r"ytInitialData\s?=\s?(.*?);<"
    jsonData = scrapers.findSingleMatch(data, regex)
    
    if not jsonData: #try with channelname
        videoInfoUrl = f"/c/{chId}"
        data = requests.get(f"{HOST}{videoInfoUrl}", headers=headers).text 
        regex = r"ytInitialData\s?=\s?(.*?);<"
        jsonData = scrapers.findSingleMatch(data, regex)

    data = None

    jsonData = json.loads(jsonData)
    tabs = jsonData["contents"]["twoColumnBrowseResultsRenderer"]["tabs"]
    
    jsonData = None

    for tab in tabs:
        if tab["tabRenderer"]["title"] == "Home":
            videoId = GetVideoId(chName, tab["tabRenderer"]["content"]["sectionListRenderer"]["contents"])
        
        if videoId: break
            
    tab = None
    tabs = None

    return playVideo(videoId)


def GetVideoId(chName, contents):
    items = []

    for content in contents:
        for subContent in content["itemSectionRenderer"]["contents"]:
            for subContentValue in subContent.values():
                try:
                    items = subContentValue.get("items", [])
                    if not items:
                        ct = subContentValue.get("content", {})
                        k = next(iter(ct))
                        if k: items = ct.get(k, {}).get("items", [])
                    
                    for item in items:
                        videoRenderer = item.get("videoRenderer", {})
                        for thumb in videoRenderer.get("thumbnailOverlays", []):
                            sk = next(iter(thumb))
                            if thumb[sk].get("style", "") == "LIVE":
                                title = ""
                                dictTitle = videoRenderer.get("title", {})

                                if dictTitle.get("runs", []):
                                    title = dictTitle.get("runs", [])[0].get("text", "")
                                if not title:
                                    title = dictTitle.get("simpleText", "")

                                if chName.lower() in title.lower():
                                    return videoRenderer.get("videoId", "")
                except :
                    pass

    return ""


def playVideo(videoId):
    res = BroadcasterResult()
    url = ""

    if videoId:
        url = f"plugin://plugin.video.youtube/play/?video_id={videoId}"

    if url:
        res.Url = url

    return res
