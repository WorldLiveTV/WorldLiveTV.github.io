# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://sportitalia.it/"

CHANNELS = {
    "sihd": "si_hd",
    "calcio": "si_calcio",
    "primaveratv": "primaveratv",
    "laziostyle": "lazio_style"
}

def play(search):
    res = BroadcasterResult()

    headers = utils.getBrowserHeaders(host=HOST)
    chId = CHANNELS[search]
    
    data = requests.get(HOST, headers=headers).text

    pattern = r"<script\s+[^>]*defer[^>]*src=[\"']([^\"']+)[\"'][^>]*>"
    lst_scr = scrapers.findMultipleMatches(data, pattern)

    urlPage = ""
    for s in lst_scr:
        if len(s) > 500 and "data:text/javascript;base64," in s:
            script_data = utils.fromBase64(s.replace("data:text/javascript;base64,", ""))
            #pattern = fr'<a\s+[^>]*?href="([^"]+)"[^>]*>(?:(?!</a>).)*?<img\s+[^>]*?title="{chId}"[^>]*?>(?:(?!</a>).)*?</a>'
            pattern = fr'<a\s+[^>]*?href="([^"]+)"[^>]*>(?:(?!<a).)*?{chId}.*?</a>'
            urlPage = scrapers.findSingleMatch(script_data, pattern)
            if urlPage:
                break

    if urlPage:
        data = requests.get(urlPage, headers=headers).text
        pattern = r'file:\s*"([^"]+)"'
        url = scrapers.findSingleMatch(data, pattern)
        if not url:
            pattern = r'STREAM_URL\s=\s*"([^"]+)"'
            url = scrapers.findSingleMatch(data, pattern)
    
    if url:
        res.Url = url
        res.StreamHeaders = headers

    return res
