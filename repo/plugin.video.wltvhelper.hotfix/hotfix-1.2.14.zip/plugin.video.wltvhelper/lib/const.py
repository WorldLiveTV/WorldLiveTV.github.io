# -*- coding: utf-8 -*-

CUSTOM_LIST = "personal_list"
USER_LIST = "user_list"

SELECTED_LIST = "selected"
LAST_SELECTED_ONLINE_LIST = "last_selected_online_list"

ITEM_SELECTED = "selected"
ITEM_UNSELECTED = "unselected"
ITEM_PARTIALSELECTED = "partial"

BROWSER_VERSION = "137.0.0.0"
USER_AGENT = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{BROWSER_VERSION} Safari/537.36"
USER_AGENT_MOBILE = f"Mozilla/5.0 (Linux; Android 10; Pixel 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{BROWSER_VERSION} Mobile Safari/537.36"
