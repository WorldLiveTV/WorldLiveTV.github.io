# -*- coding: utf-8 -*-

import requests, uuid, json
from lib import config, utils, logger, wltvcache
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.discoveryplus.com"
deviceId = uuid.uuid4().hex
dplusVer = "2.67.0"
cacheKey = "discoverychannels"

def play(search):
    res = BroadcasterResult()
    chId = ""
    
    headers = utils.getBrowserHeaders(host=HOST)

    headers["Accept"] = "*/*"
    headers["x-disco-client"] = f"WEB:UNKNOWN:dplus_us:{dplusVer}"
    headers["x-disco-params"] = "bid=dplus,hn=www.discoveryplus.com,hth=it"

    discovery = wltvcache.get_or_set_string(cacheKey)
    if not discovery:
        discovery = GetChannels(headers)
        wltvcache.get_or_set_string(cacheKey, json.dumps(discovery), 10*60)
    else:
        discovery = json.loads(discovery)

    cookies = discovery["cookies"]
    baseApiUrl = discovery["baseApiUrl"]
    channels = discovery["channels"]
    discovery = None

    for key in channels:
        if (key.get("attributes", {}).get("hasLiveStream", "") == True
            and "Free" in key.get("attributes", {}).get("packages", [])
            and search == key["attributes"]["channelCode"]):
            chId = key["id"]
            break

    channels = None

    if chId:
        postJsonData = f'{{ "channelId": "{chId}", "deviceInfo": {{ "adBlocker": false, "drmSupported": true }}, "wisteriaProperties": {{ "siteId": "dplus_it", "platform": "desktop" }} }}'
        #headers.pop("x-device-info")
        headers["x-disco-params"] = "realm=dplay,siteLookupKey=dplus_it,bid=dplus,hn=www.discoveryplus.com,hth=it"
        
        jsonData = requests.post(f"{baseApiUrl}/playback/v3/channelPlaybackInfo", headers=headers, cookies=cookies, data=postJsonData).json()
        data = jsonData.get("data", {}).get("attributes", {}).get("streaming", {})[0]
        jsonData = None

        url = data["url"]

        if url:
            headers = utils.getBrowserHeaders(host=HOST)
            res.Url = url
            res.UserAgent = True
            res.StreamHeaders = headers
            
            if data["protection"]["drmEnabled"] == True:
                drmToken = data["protection"]["drmToken"]
                licenseUrl = data["protection"]["schemes"]["widevine"]["licenseUrl"]
                #res.LicenseKey = f"{licenseUrl}|preauthorization={drmToken}|R{{SSM}}|"

                logger.error(headers)
                licenseConfig = { 
                    'license_server_url': licenseUrl,
                    'headers': utils.dict2querystring(headers),
                    'post_data': 'R{SSM}',
                    'response_data': 'R'
                }
                res.LicenseKey = '|'.join(licenseConfig.values())
    return res


def GetChannels(headers):
    infoUrl = "https://global-prod.disco-api.com/bootstrapInfo"
   
    jsonData = requests.get(infoUrl, headers=headers).json()
    baseApiUrl = jsonData.get("data", {}).get("attributes", {}).get("baseApiUrl", "")

    #get token
    headers["x-device-info"]  = f"dplus_us/{dplusVer} (desktop/desktop; Windows/NT 10.0; {deviceId})"
    headers["x-disco-params"] = "realm=dplay,bid=dplus,hn=www.discoveryplus.com,hth=it,features=ar"

    token = requests.get(f"{baseApiUrl}/token?deviceId={deviceId}&realm=dplay&shortlived=true", headers=headers).json()["data"]["attributes"]["token"]
    cookies = { "st": token }

    channels = requests.get(f"{baseApiUrl}/cms/routes/home?include=default&decorators=playbackAllowed", headers=headers, cookies=cookies).json()["included"]
    channels = list(filter(lambda x: x.get("type", "") == "channel", channels))

    for chs in channels:
        chs.pop("relationships", None)
        chs.get("attributes", {}).pop("contentDescriptors", None)
        chs.get("attributes", {}).pop("contentRatings", None)
        chs.get("attributes", {}).pop("customAttributes", None)
        chs.get("attributes", {}).pop("longDescription", None)
        #chs.get("attributes", {}).pop("packages", None)
    
    discovery = {
       "baseApiUrl": baseApiUrl,
       "cookies": cookies,
       "channels": channels
    }

    return discovery