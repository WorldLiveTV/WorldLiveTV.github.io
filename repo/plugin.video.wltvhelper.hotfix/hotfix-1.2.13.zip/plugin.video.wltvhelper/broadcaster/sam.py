# -*- coding: utf-8 -*-
import requests

from lib import utils, scrapers, logger
from lib.broadcaster_result import BroadcasterResult

fileName = "ListSamsungTv.bin"
StreamBaseUrl = "https://jmp2.uk/sam-"

def play(search):
    res = BroadcasterResult()
    url = f"{StreamBaseUrl}{search}.m3u8"

    user_agent="HbbTV/1.2.1 (+DRM;Samsung;SmartTV2016;T-JZMDEUC-1243.2;;) WebKit"
    channel_info = {}

    headers = utils.getBrowserHeaders()
    jsonData = utils.GetJsonList(fileName, False)

    if jsonData:
        user_agent = jsonData["headers"].get("user-agent", "")
        channel_info = jsonData["regions"]["it"]["channels"].get(search, {})

    if user_agent:
        headers["User-Agent"] = user_agent

    if channel_info:
        licenseKey = channel_info.get("headers", {}).get("Authorization", "")
        licenseUrl = channel_info.get("license_url", "")
        licenseConfig = { 
            'license_server_url': licenseUrl,
            'headers': utils.dict2querystring(headers),
            'post_data': 'R{SSM}',
            'response_data': 'R'
        }
        res.LicenseKey = '|'.join(licenseConfig.values())

        #res.StreamHeaders = headers
        #res.LicenseKey = f"{licenseUrl}|{licenseKey}|R{{SSM}}|"
        #res.LicenseKey = licenseUrl

    res.Url = url
    res.Headers = headers
    res.UseInputStreamAdaptive = True

    return res

