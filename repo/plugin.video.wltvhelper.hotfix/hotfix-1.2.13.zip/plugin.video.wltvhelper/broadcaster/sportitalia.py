# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.sportitalia.it/"

STREAMUP_CHANNELS = {
    "sihd": "si_hd",
    "calcio": "si_calcio",
    "primaveratv": "primaveratv"
}


def play(search):
    res = BroadcasterResult()

    chId = STREAMUP_CHANNELS[search]

    data = requests.get(HOST, headers=utils.getBrowserHeaders()).text
    pattern = fr'<a\s+[^>]*?href="([^"]+)"[^>]*>(?:(?!</a>).)*?<img\s+[^>]*?title="{chId}"[^>]*?>(?:(?!</a>).)*?</a>'
    urlPage = scrapers.findSingleMatch(data, pattern)

    if urlPage:
        data = requests.get(urlPage, headers=utils.getBrowserHeaders()).text
        pattern = r'<video[^>]*?\s+src\s*=\s*"([^"]*?)(?:\r\n|\r|\n)?(?=")"'
        url = scrapers.findSingleMatch(data, pattern)
    
    if url:
        res.Url = url
        res.UseInputStreamAdaptive = False

    return res
