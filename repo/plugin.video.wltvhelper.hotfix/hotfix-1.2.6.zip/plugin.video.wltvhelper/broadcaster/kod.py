# -*- coding: utf-8 -*-

from typing import List

from lib.broadcaster_result import BroadcasterResult
from lib.playablemediaitem import PlayableMediaItem


def play(search):
    res = BroadcasterResult()

    sSplit = search.split("$")
    itemType = sSplit[0].lower()
    kodParam = sSplit[1]

    url = f"plugin://plugin.video.kod?{kodParam}";
    
    if itemType == "s":
        res.PlayableMediaItems = getItems(url)
    else:
        res.Url = url

    return res

def getItems(link) -> List[PlayableMediaItem]:
    itemlist = list()
    itemlist.append(PlayableMediaItem(0, 0, "Serie (KoD)", 0, 0, "", "", "", "", link, False, True))
      
    return itemlist