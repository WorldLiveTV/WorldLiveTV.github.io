# -*- coding: utf-8 -*-

import requests
from lib import scrapers
from lib.broadcaster_result import BroadcasterResult


BASE_URL = "https://streamup.eu"

# https://streamup.eu/si/?can=sihd
# https://streamup.eu/si/?can=sisolocalcio
# https://streamup.eu/si/?can=silive24

STREAMUP_CHANNELS = {
    "sihd": "sihd",
    "calcio": "sisolocalcio",
    "live24": "silive24"
}


def play(search):
    res = BroadcasterResult()

    chId = STREAMUP_CHANNELS[search]

    ch_url_path = "/si/?can={}"
    response = requests.get(BASE_URL + ch_url_path.format(chId))

    url = scrapers.findSingleMatch(response.text, r"file: '(https?:\/\/.*\.m3u8)'")
    res.Url = url
    res.UseInputStreamAdaptive = False

    return res
