# -*- coding: utf-8 -*-

from urllib3.exceptions import InsecureRequestWarning
import requests
from lib import scrapers, utils
from lib.broadcaster_result import BroadcasterResult
from time import time

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

HOST = "https://www.la7.it"
LICENSE_URL = "https://la7.prod.conax.cloud/widevine/license"


def play(search):
    res = BroadcasterResult()

    if search == "La7":
        siteUrl = HOST + "/dirette-tv"
    elif search == "La7d":
        siteUrl = HOST + "/live-la7d"
        
    headers = utils.getBrowserHeaders(host=HOST)

    data = requests.get(siteUrl, headers = headers).text

    preAuthTokenUrl = scrapers.findSingleMatch(data, r'preTokenUrl = "(.+?)"')
    url = scrapers.findSingleMatch(data, r"""["]?dash["]?\s*:\s*["']([^"']+)["']""")

    headers["Accept"] = "*/*"
    
    if url:
        tokenHeader = headers.copy()
        tokenHeader["dnt"] = "1"
        tokenHeader["te"] = "trailers"
        
        preAuthToken = requests.get(preAuthTokenUrl, headers = tokenHeader, verify = False).json()["preAuthToken"]
        
        licenseHeaders = headers.copy()
        licenseHeaders["content-type"] = "application/octet-stream",
        licenseHeaders["preAuthorization"] = preAuthToken
        
        licenseConfig = { 
            'license_server_url': f'{LICENSE_URL}?d={str(int(time()))}',
            'headers': utils.dict2querystring(licenseHeaders),
            'post_data': 'R{SSM}',
            'response_data': 'R'
        }

        res.Url = url
        res.LicenseKey = '|'.join(licenseConfig.values())
        res.ManifestUpdateParameter = "full"

    return res
