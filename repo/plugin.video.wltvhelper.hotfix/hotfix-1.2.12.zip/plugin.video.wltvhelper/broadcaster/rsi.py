# -*- coding: utf-8 -*-

import requests
from lib import config, logger, utils
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.rsi.ch"
BASEURL = "https://il.srgssr.ch/integrationlayer/2.0/mediaComposition/byUrn/%s.json?onlyChapters=false&vector=portalplay"

mpd = config.getSetting("mpd")


def play(search):
    res = BroadcasterResult()

    url = ""
    protocol = "DASH" if mpd else "HLS"
    drmType = "WIDEVINE" if mpd else "FAIRPLAY"
    licenseUrl = ""

    jsonData = requests.get("https://www.rsi.ch/play/v3/api/rsi/production/tv-livestreams").json()["data"]

    headers = utils.getBrowserHeaders(host=HOST)
    
    for item in jsonData:
        if search == item["title"]:
            livestreamUrn = item["livestreamUrn"]
            urlStreams = BASEURL % livestreamUrn
            chapterList = requests.get(urlStreams, headers=headers).json()["chapterList"]

            _found = next( iter( filter( lambda key: (key["protocol"] == protocol), chapterList[0]["resourceList"] ) ) )

            if _found:
                url = _found["url"]

                drm = next( iter( filter( lambda key: (key["type"] == drmType), _found["drmList"] ) ) )
                if drm:
                    licenseUrl = drm["licenseUrl"]

    if url:
        headers["Accept"] = "*/*"
        headers["Content-Type"] = "application/octet-stream"
        
        licenseConfig = { 
            'license_server_url': licenseUrl,
            'headers': utils.dict2querystring(headers),
            'post_data': 'R{SSM}',
            'response_data': 'R'
        }

        res.StreamHeaders = headers
        res.Url = url
        res.LicenseKey = '|'.join(licenseConfig.values())
        res.ManifestUpdateParameter = "full"

    return res
