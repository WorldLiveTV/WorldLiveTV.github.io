# -*- coding: utf-8 -*-
# youtube channel & video broadcaster

#example: 
    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO", Abao a Tokyo1
    #   plugin://plugin.video.wltvhelper/play/yt/c/01/UC84whx2xxsiA1gXHXXqKGOA
        
    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO", Abao a Tokyo2
    #   plugin://plugin.video.wltvhelper/play/yt/c/02/UC84whx2xxsiA1gXHXXqKGOA
        
    #   #EXTINF:-1 tvg-name="VIDEO" tvg-logo="" group-title="VIDEO",VIDEO YT
    #   plugin://plugin.video.wltvhelper/play/yt/v/0/TbhcfUPYKEU

import json
import requests
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult


def play(chtype:str,chnumber:str,chId:str):
    try:
        chnumber = int(chnumber)
    except:
        chnumber = 0

    if chnumber >  0: chnumber = chnumber - 1
    if chnumber <= 0: chnumber = 0

    if chtype == "c":
        return playChannel(chnumber, chId)
    elif chtype == "v":
        return playVideo(chId)
    else:
        return playVideo(chId)


def playChannel(idx:int, chId:str):
    HOST = "https://www.youtube.com"
    videoInfoUrl = f"/channel/{chId}"

    home  = {}
    lives = []

    headers = {
        "user-agent": utils.USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.5",
        "Cookie": "YSC=uhMbKwwwD3g; CONSENT=YES+cb.20300101-18-p0.it+FX+133; GPS=1; VISITOR_INFO1_LIVE=NnmAzzluXtu; PREF=tz=Europe.Rome",
    }

    data = requests.get(f"{HOST}{videoInfoUrl}", headers=headers).text 
    regex = r"ytInitialData\s?=\s?(.*?);<"
    jsonData = scrapers.findSingleMatch(data, regex)
    
    if not jsonData: #try with channelname
        videoInfoUrl = f"/c/{chId}"
        data = requests.get(f"{HOST}{videoInfoUrl}", headers=headers).text 
        regex = r"ytInitialData\s?=\s?(.*?);<"
        jsonData = scrapers.findSingleMatch(data, regex)

    jsonData = json.loads(jsonData)

    tabs = jsonData["contents"]["twoColumnBrowseResultsRenderer"]["tabs"]
    
    for tab in tabs:
        home = tab["tabRenderer"]
        if home["title"] == "Home":
            break

    if home:
        chItems = home["content"]["sectionListRenderer"]["contents"][0]["itemSectionRenderer"]["contents"][0].get("channelFeaturedContentRenderer", "")

        if chItems:
            liveItems = chItems["items"]
       
            for liveItem in liveItems:
                live = {
                    "id": liveItem["videoRenderer"]["videoId"],
                    "title": liveItem["videoRenderer"]["title"]["runs"][0]["text"]
                }
                lives.append(live)
    
    videoId = ""
    if lives:
        videoId = lives[idx]["id"]

    return playVideo(videoId)


def playVideo(videoId):
    res = BroadcasterResult()
    url = ""

    if videoId:
        url = f"plugin://plugin.video.youtube/play/?video_id={videoId}"

    if url:
        res.Url = url

    return res
