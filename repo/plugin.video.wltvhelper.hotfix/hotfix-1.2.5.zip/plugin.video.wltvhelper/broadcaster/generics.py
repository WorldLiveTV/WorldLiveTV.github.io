# -*- coding: utf-8 -*-

import requests
from lib import scrapers, config, logger
from lib.broadcaster_result import BroadcasterResult
from time import time

# plugin://plugin.video.wltvhelper/play/regionals/search

mpd = config.getSetting("mpd")
res = BroadcasterResult()
url = ""

def play(search):
    search = search.lower()

    options = { 
        "cilentano" : GetCilentano,
        "laq" : GetLaqTV,
        "nolink" : GetNoLink,
    }

    if search not in options.keys():
        search = "nolink"

    return options[search]()

def GetNoLink():
    return res

def GetCilentano():
    HOST = "https://cilentano.tv"
    API  = "https://player-backend.restream.io/public/videos/"
    data = requests.get(f"{HOST}").text
    token = scrapers.findSingleMatch(data, r'token=([^"]+)')
    #_url  = scrapers.findSingleMatch(data, r'iframe\sid=\"r-embed-player-iframe\"\ssrc=\"([^"]+)')
    jsonData = requests.get(f"{API}{token}").json()
    url = jsonData["videoUrlHls"]

    if mpd:
        url = jsonData["videoUrlDash"]
        res.ManifestType = "mpd"

    if url:
        res.Url = url

    return res

def GetLaqTV():
    HOST = "https://www.aqbox.tv/streaming.php"
    data = requests.get(f"{HOST}").text
    alias = scrapers.findSingleMatch(data, r"mtm_webcam',\s'([^']+)")
    now = str(int(time()))

    #jsonUrl = f"https://player.ipcamlive.com/player/registerviewer.php?_={now}&alias={alias}&type=HTML5"
    #jsonData = requests.get(jsonUrl).json()
    #id = jsonData["data"]["viewerid"]

    jsonUrl = f"https://player.ipcamlive.com/player/getcamerastreamstate.php?_={now}&token=&alias={alias}&targetdomain=www.aqbox.tv&getstreaminfo=1"
    jsonData = requests.get(jsonUrl).json()
    
    url0 = jsonData["details"]["address"]
    url1 = jsonData["details"]["streamid"]
    url2 = jsonData["streaminfo"]["live"]["levels"][0]["url"]

    url = f"{url0}streams/{url1}/{url2}".replace("http", "https")
    
    if url:
        res.Url = url

    return res
