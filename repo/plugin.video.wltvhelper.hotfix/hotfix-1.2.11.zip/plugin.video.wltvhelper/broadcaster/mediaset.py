# -*- coding: utf-8 -*-

from urllib3.exceptions import InsecureRequestWarning
import uuid, requests
from urllib.parse import urlencode
from urllib.parse import unquote
from lib import xmltodict, config, utils, scrapers, logger
from lib.broadcaster_result import BroadcasterResult

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

mpd = config.getSetting("mpd")

HOST = "https://mediasetinfinity.mediaset.it"

LOGIN_URL  = "https://api-ott-prod-fe.mediaset.net/PROD/play/idm/anonymous/login/v2.0"
ACCEDO_URL = "https://api.one.accedo.tv/session?appKey=6023de431de1c4001877be3b&uuid={uuid}&gid=default"

ALLSTATION_URL = "https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations-v2?sort=shortTitle|asc&form=cjson&httpError=true"
LICENSE_URL = "https://widevine.entitlement.theplatform.eu/wv/web/ModularDrm/getRawWidevineLicense?releasePid={pid}&account=http://access.auth.theplatform.com/data/Account/2702976343&schema=1.0&token={token}|Accept=*/*&Content-Type=|R{{SSM}}|"
STREAM_URL  = "https://api-ott-prod-fe.mediaset.net/PROD/play/playback/check/v2.0?sid={sid}"
ALL_JSON = "https://static3.mediasetplay.mediaset.it/apigw/nownext/nownext.json"

appName = ""
token = ""
sid   = ""
streamDataRes = {"dash":{"url":"","pid":"","isWidevine":False },"mpeg":{"url":"","pid":"","isWidevine":False }}


def play(search):
    res = BroadcasterResult()
    global token, sid
    clientId = str(uuid.uuid1())

    session = requests.Session()
    headers = utils.getBrowserHeaders()
    headers["Origin"]  = HOST
    headers["Referer"] = HOST
    #headers["Content-Type"] = "application/json"
    session.headers = headers

    data = session.get(HOST).text
    appName = scrapers.findSingleMatch(data, r'"app-name" content="([^"]+)')

    loginData = {
        "client_id": f"rtispa_mplayweb_{clientId}",
        "platform": "pc",
        "appName": appName
    }
    
    session.headers.update({ "Content-Type": "application/json" })

    tkRes = session.post(LOGIN_URL, json=loginData, verify=False)
    token = tkRes.json()["response"]["beToken"]
    sid   = tkRes.json()["response"]["sid"]
    
    session.headers.update({ "authorization": f"Bearer {token}" })
    #sessionKey = session.get(ACCEDO_URL.format(uuid=clientId), verify=False).json()['sessionKey']
    #session.headers.update({'x-session': sessionKey})

    url = ""
    pid = ""
    callSign = ""
    
    # search
    if search.startswith("$"): 
        callSign = search[1:]
    else:
        items = session.get(ALLSTATION_URL).json()["entries"]
        for item in items:
            if search.startswith("$"):
                _search = "$" + item["callSign"]
            else:
                _search = item["title"]

            if item.get("tuningInstruction", "") and _search == search:
                callSign = item["callSign"]
                break
        items = None

    streamDataRes = getWebBrowserStreamData(session, headers, callSign, appName)
    #streamDataRes = getManualStreamData(session, headers, search)

    url = streamDataRes["mpeg"]["url"]

    if not url: 
        forceMpd = True
        url = streamDataRes["dash"]["url"]
        widevine = streamDataRes["dash"]["isWidevine"]
        pid = streamDataRes["dash"]["pid"]

    if "theplatform" in url:
        url = requests.get(url, headers=headers).url

    if url:
        if forceMpd:
            res.ManifestType = "mpd"
            res.ManifestUpdateParameter = "full"
            if widevine and pid:
                res.LicenseKey = LICENSE_URL.format(pid=pid, token=token)
        
        #url = f"{url}|user-agent={utils.USER_AGENT}" #kodi 19 compatibility
        res.StreamHeaders = f"user-agent={utils.USER_AGENT}"
        res.Url = url
    else:
        logger.error("No url found for: ", search)
    
    return res


def getWebBrowserStreamData(session, headers, callSign, appName):
    global token, streamDataRes
    
    jsonStreamRequestData = {
        "channelCode":f"{callSign}",
        "streamType":"LIVE",
        "delivery":"Streaming",
        "createDevice":"true",
        "overrideAppName": appName
    }
    
    headers["Authorization"] = f"Bearer {token}"
    jsonStream = session.post(STREAM_URL.format(sid=sid), json=jsonStreamRequestData, headers=headers).json()
    logger.debug("appName:", appName)
    logger.debug("jsonStream:", jsonStream)
    parameters = jsonStream["response"]["mediaSelector"]
    parameters["auth"] = token
    
    streamUrl = parameters.pop("url")
    #parameters["format"]  = "SMIL"
    #parameters["formats"] = "MPEG-DASH,MPEG4,M3U"

    streamUrl  = f"{streamUrl}?{unquote(urlencode(parameters))}"
    headers = utils.getBrowserHeaders()
    headers["Accept"] = "application/json, text/plain, */*"
    smilXml = requests.get(streamUrl, headers=headers).content.decode()
    logger.debug("smil:", smilXml)
    xml = xmltodict.parse(smilXml)
    ref = xml["smil"]["body"]["seq"]["switch"]["ref"]
    par = ref["param"]
    url = ref["@src"] 
    
    isEncrypted = False if not "@security" in ref else ref["@security"] == "commonEncryption"
    pid = scrapers.findSingleMatch(par["@value"], r"\|pid=([^|]+)")

    isDash = ".mpd" in url
    
    k = "dash" if isDash else "mpeg"
    streamDataRes[k]["isWidevine"] = isEncrypted
    streamDataRes[k]["pid"] = pid
    streamDataRes[k]["url"] = url
    
    return streamDataRes


def getManualStreamData(session, headers, search):
    global token, streamDataRes

    items = session.get(ALLSTATION_URL, headers=headers).json()["entries"]

    streamDataRes = {"dash":{"url":"","pid":"","isWidevine":False },"mpeg":{"url":"","pid":"","isWidevine":False }}
    
    # search
    for item in items:
        title = item["title"]
        if search.startswith("$"):
            _search = "$" + item["callSign"]
        else:
            _search = item["title"]

        tu = item.get("tuningInstruction")
        if tu and _search == search:

            for key in tu.get("urn:theplatform:tv:location:any"):
                isDash = False
                isMpeg = False

                strmFormat = "dash+xml"
                if key["format"] == "application/{}".format(strmFormat):
                    isDash = True
                else:
                    strmFormat = "x-mpegURL"
                    if key["format"] == "application/{}".format(strmFormat):
                        isMpeg = True

                if isDash or isMpeg:
                    try:
                        if "geoIT" in key["assetTypes"]: # or "geoNo" in key["assetTypes"] or "geoNoLim" in key["assetTypes"]:
                            k = "dash" if isDash else "mpeg"
                            if not streamDataRes[k]["url"]:
                                streamDataRes[k]["isWidevine"] = "widevine" in key["assetTypes"]
                                streamDataRes[k]["pid"] = key["releasePids"][0]
                                streamDataRes[k]["url"] = key["publicUrls"][0]
                    except:
                        logger.error(f"No PublicUrls for '{title}' with format {strmFormat}")

                if streamDataRes["dash"]["url"] and streamDataRes["mpeg"]["url"]:
                    break

    items = item = key = None
    
    return streamDataRes
