import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import routing
import urllib
import requests

from lib.install import install, install_inputstream, install_widevine
from lib import logger, config, utils
from xbmcaddon import Addon

PY3 = True if sys.version_info[0] >= 3 else False

plugin = routing.Plugin()

####
# Starting point: the first page appearing to User
####
@plugin.route('/')
def start():
    handle = plugin.handle
    
        msg = "Questa versione di WLTV e' ormai obsoleta, si prega di disinstallare Kodi 18 ed installare Kodi 19 per usare la nuova versione dell'ADDON"

    xbmcgui.Dialog().ok("WLTV 1.1.16", msg)
    
    xbmcplugin.endOfDirectory(handle=handle, succeeded=True)

plugin.run()
