# -*- coding: utf-8 -*-
import sys, os,xbmc, re, base64, urllib2, datetime, xbmcgui
if sys.getdefaultencoding() != "ISO-8859-1":
   reload(sys)
   sys.setdefaultencoding( "ISO-8859-1" )
from threading import Thread
from core import httptools
from core import logger
from core import scrapertools
import common
from xml.dom import minidom

now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
#cartella principale
linkschecker_dir = xbmc.translatePath(os.path.join(xbmc.translatePath("special://temp"),"linkschecker"))
#win : C:\Users\<User>\AppData\Roaming\Kodi\cache\linkschecker

path_check_all_links = xbmc.translatePath(os.path.join(linkschecker_dir,"results"))
#file report con tutti i links
check_all_links_film = xbmc.translatePath(os.path.join(path_check_all_links,now+"_check_all_links_film.csv"))
check_all_links_serietv = xbmc.translatePath(os.path.join(path_check_all_links,now+"_check_all_links_serietv.csv"))
#file con riassunto statistico
stats = xbmc.translatePath(os.path.join(path_check_all_links,now+"_stats.csv"))
#cartella film
dir_film = xbmc.translatePath(os.path.join(linkschecker_dir,"xml","Film"))
#cartella serie TV
dir_serietv = xbmc.translatePath(os.path.join(linkschecker_dir,"xml","SerieTV"))

def check_links_thread():
    option = [ ]
    option.append(" Check Film ")
    option.append(" Check TV series ")
    index = xbmcgui.Dialog().select("Check KLTV XML link", list=option)
    
    if index == 0:
        t1 = Thread(target=check_links_film, args=[])
        t1.setDaemon(True)
        t1.start()
        return
    elif index == 1:
        t2 = Thread(target=check_links_serietv, args=[])
        t2.setDaemon(True)
        t2.start()
        return
    else:
        return
        
def check_links_film():
    global dir_film
    file_check_all_links = open(check_all_links_film,'w',1)
    file_stats = open(stats,'w',1)
    files = sorted(os.listdir(dir_film))
    total_count_links=0
    total_count_links_ok=0
    
    file_check_all_links.write('Filename;Status;Http Code;Link;TMDB;YouTube;Desc_length\n')
    file_stats.write('Filename;Links;OK;To Check\n')
    
    for file in files:
        movie_count_links=0
        movie_count_links_ok=0
        filepath = os.path.join(dir_film, file)
        desc_length=0
        tmdb_link=''
        youtube_link=''
        trailer='KO'
        with open(filepath) as fp:  
            line = fp.readline()
            file_check_all_links.write('\n')
            while line:
                #xbmc.log(line)
                line = fp.readline()
                link=re.findall(r'<link>(.*?)</link>', line)
                if len(link)>0 and 'http' in link[0] and 'plugin' not in link[0]:
                    total_count_links=total_count_links+1
                    movie_count_links=movie_count_links+1
                    if '/[' in link[0]:
                        link[0]=link[0][0:link[0].find('/[')]
                    elif '/<' in link[0]:
                        link[0]=link[0][0:link[0].find('/<')]                  
                description=re.findall(r'<description>(.*?)</description>', line)
                if len(description)>0:
                    desc_length=len(description[0])
                extended_info_id=re.findall(r'extendedinfo&&id=(.*?)</link>', line)
                if len(extended_info_id)>0:
                    tmdb_link='https://www.themoviedb.org/movie/'+extended_info_id[0]
                youtube_link_id=re.findall(r'video_id=(.*?)</link>', line)
                if len(youtube_link_id)>0:
                    youtube_link='https://www.youtube.com/watch?v='+youtube_link_id[0]                     
                if len(link)>0 and 'http' in link[0]:
                    status_code, check=check_link(link[0])
                    if(check=='OK'):
                        total_count_links_ok=total_count_links_ok+1
                        movie_count_links_ok=movie_count_links_ok+1
                    file_check_all_links.write(file+';'+check + ';'+str(status_code)+';'+link[0]+ ';'+str(tmdb_link) + ';'+str(youtube_link)+ ';'+str(desc_length) +'\n')
                    file_check_all_links.flush()
        file_stats.write(file+ ';'+str(movie_count_links) + ';'+str(movie_count_links_ok)+ ';'+str(movie_count_links-movie_count_links_ok)+'\n')
        file_stats.flush()
    file_check_all_links.close()
    file_stats.close()
    return

def check_links_serietv():
    print('check_links_serietv')
    file_check_all_links_serietv = open(check_all_links_serietv,'w',1)
    file_check_all_links_serietv.write('Filename;Season;Episode;Status;Http Code;Link\n')
    
    files = sorted(os.listdir(dir_serietv))
    for file in files:
        path_file = os.path.join(dir_serietv,file)
        if path_file.endswith('.xml'):
            try:
                try:
                    f = open(path_file,'r')
                except:
                    f = open(path_file.decode("utf-8"),"r")

                data = f.read().replace("\n\n", "")
                f.close()
                
                data = data.replace("&","&amp;").replace("&amp;amp;","&amp;")
                xmldoc = minidom.parseString(data)
                #replace_char_in_file(path_file,'&','')
                #xmldoc = minidom.parse(path_file)
                items = xmldoc.getElementsByTagName('item')
                file_check_all_links_serietv.write('\n')
            except:
                file_check_all_links_serietv.write('Error\n')

            for item in items:
                try:
                    year=item.getElementsByTagName("year")[0]
                    tvshow_title_season=item.getElementsByTagName("name")[0].firstChild.data.encode('utf-8')
                except:
                   pass
                try:
                    episode=item.getElementsByTagName("name")[0].firstChild.data.encode('utf-8')
                    for link in item.getElementsByTagName("link"):
                        if link is not None and link.firstChild is not None and 'http' in link.firstChild.data:
                            link_to_check=link.firstChild.data
                            if '/[' in link_to_check:
                                link_to_check=link_to_check[0:link_to_check.find('/[')]
                            elif '/<' in link_to_check:
                                link_to_check=link_to_check[0:link[0].find('/<')]
                            status_code, check=check_link(link_to_check)
                            file_check_all_links_serietv.write(file+';'+tvshow_title_season + ';'+ episode + ';'+check+';'+str(status_code)+';'+link_to_check+ '\n')
                            file_check_all_links_serietv.flush()
                except:
                    pass

def check_link(url):
    real_url=''
    if '//openload' in url or '//oload' in url or '//streamango.com' in url or '//verystream' in url or '//streamcherry' in url or '//woof.tube' in url or '//speedvideo' in url:
        return '-1', 'Server Offline'
    try:
        real_url=common.urlresolve(url,True)
    except Exception as e:
        #xbmc.log(str(e))
        return str(e), 'To Check'
    
    status_code, check = get_check(real_url)
    return status_code, check
    
def get_check(url):
    check=''
    status_code=-1
    import requests
    try:
        if url is not None and 'http' in url:
            url_info=requests.head(url)
        else:
            check='To Check'

    except requests.ConnectionError as e:
        xbmc.log(str(e))
        check='To Check'
    
    if check=='':
        status_code=url_info.status_code
    if status_code>=200 and status_code<=399:
        check='OK'
    else:
        check='To Check'       
    return status_code, check

def replace_char_in_file(path_file, string_to_replace, string_new):
    x = open(path_file)
    s=x.read().replace(string_to_replace, string_new) 
    x.close()
    x=open(path_file,"w")
    x.write(s)
    x.close()
