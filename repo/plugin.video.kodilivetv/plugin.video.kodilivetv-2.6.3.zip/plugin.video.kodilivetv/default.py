# -*- coding: utf-8 -*-

import urllib2, urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, re, stat, xbmcvfs, base64
if sys.getdefaultencoding() != "ISO-8859-1":
   reload(sys)
   sys.setdefaultencoding( "ISO-8859-1" )

# Definizione variabili
AddonID = 'plugin.video.kodilivetv'
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')
addonDir = Addon.getAddonInfo('path')
addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ), AddonID)
pwdir = os.path.join(addon_data_dir, "password")
cdir = os.path.join(xbmc.translatePath("special://temp"),"files")

# Indirizzi per update
LOCAL_VERSION_FILE = os.path.join(os.path.join(addonDir), 'version.xml' )
REMOTE_VERSION_FILE = "https://kodilive.github.io/repo/version.xml"
LOCAL_VERSION_FILE2 = os.path.join(os.path.join(addonDir), 'list.xml' )
REMOTE_VERSION_FILE2 = "https://kodilive.github.io/update/list.xml"

libDir = os.path.join(addonDir, 'resources', 'lib')
f4mProxy = os.path.join(addonDir, 'f4mProxy')
chanDir = os.path.join(addonDir, 'resources', 'channels')

#IP Service
ips = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('service_IP')
ips2 = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('service_IP2')

# Playlist
playlistsFile = os.path.join(addonDir, "playLists.txt")
Italian = os.path.join(addonDir, "italian.txt")
French = os.path.join(addonDir, "french.txt")
German = os.path.join(addonDir, "german.txt")
English = os.path.join(addonDir, "english.txt")

# cartelle per linkschecker
linkschecker_dir = xbmc.translatePath(os.path.join(xbmc.translatePath("special://temp"),"linkschecker",""))
dir_film = xbmc.translatePath(os.path.join(linkschecker_dir,"xml","Film",""))
dir_serietv = xbmc.translatePath(os.path.join(linkschecker_dir,"xml","SerieTV",""))
path_check_all_links = xbmc.translatePath(os.path.join(linkschecker_dir,"results",""))

# Estensioni
EXTL = [ '.m3u', '.m3u8', '.txt']
EXTV = [ '.mkv','.mp4','.avi','.ogv','.flv','.f4v','.wmv','.mpg','.mpeg','.3gp','.3g2','.webm','.ogg', '.part']
EXTA = [ '.mp3','.flac','.aac','.wav','.raw','.m4a','.wma','.f4a' ]

# User-agent Android
UAA = "Android / Chrome 40: Mozilla/5.0 (Linux; Android 5.1.1; Nexus 4 Build/LMY48T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.89 Mobile Safari/537.36"

# Icone
iconlist = "http://findicons.com/files/icons/1331/matrix_rebooted/128/text_clipping_file.png"
audio = "http://findicons.com/files/icons/1331/matrix_rebooted/128/music.png"
icondir = "http://findicons.com/files/icons/1331/matrix_rebooted/128/generic_folder_alt.png"
video = "http://findicons.com/files/icons/1331/matrix_rebooted/128/movies_2.png"
find = "https://kodilive.github.io/icon/folder_search.png"
TVICO = os.path.join(addonDir, "resources", "images", "tv.png")
favoritesFile = os.path.join(addon_data_dir, 'favorites.txt')

# Liste PM
playlistsFile2 = os.path.join(addon_data_dir, "playLists.txt")
playlistsFile4 = os.path.join(addon_data_dir, "FolderLists.txt")
playlistsFile3 = os.path.join(addon_data_dir, "playLists.bkp")
playlistsFile5 = os.path.join(addon_data_dir, "FolderLists.bkp")

SDownloader = "false"

# Importo funzioni da common.py
sys.path.insert(0, libDir)
import common

# cartella download
DF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
if not DF=='':  
    DFolder = DF
else:
    DFolder = os.path.join(addon_data_dir, 'download', '')

# Cartella libreria Film
LF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('library_path')
if not LF=='':  
    LFolder = LF
else:
    LFolder = ''

# Cartella libreria Serie TV
LS = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('library_s_path')
if not LS=='':  
    LSFolder = LS
else:
    LSFolder = ''

# Crezione cartelle
if not os.path.exists(addon_data_dir):
    xbmcvfs.mkdirs(addon_data_dir)
if not os.path.exists(pwdir):
    xbmcvfs.mkdirs(pwdir)	
if not os.path.exists(cdir):
    xbmcvfs.mkdirs(cdir)

try:
    if not xbmcvfs.exists(DFolder):
        xbmcvfs.mkdirs(DFolder)
except:
    pass

try:
    if not xbmcvfs.exists(LFolder) and not LFolder == "":
        xbmcvfs.mkdirs(LFolder)
except:
    pass

try:
    if not xbmcvfs.exists(LSFolder) and not LSFolder == "":
        xbmcvfs.mkdirs(LSFolder)
except:
    pass

if not xbmcvfs.exists(linkschecker_dir):
    xbmcvfs.mkdirs(linkschecker_dir)
if not xbmcvfs.exists(dir_film):
    xbmcvfs.mkdirs(dir_film)
if not xbmcvfs.exists(dir_serietv):
    xbmcvfs.mkdirs(dir_serietv)
if not xbmcvfs.exists(path_check_all_links):
    xbmcvfs.mkdirs(path_check_all_links)

# Inizializzazione file favoriti
if not (os.path.isfile(favoritesFile)):
    f = open(favoritesFile, 'w') 
    f.write('[]') 
    f.close()

# Funzioni gestione file
def zip_PM_data():
    import zipfile
    dialog = xbmcgui.Dialog()
    path = dialog.browse( int(3), localizedString(10124).encode('utf-8'), "myprograms", "", True )

    if not path == "":
        ZipFile = zipfile.ZipFile(os.path.join(path,"backup_pm.zip"), "w" )
        ZipFile.write(playlistsFile2, os.path.basename(playlistsFile2), compress_type=zipfile.ZIP_DEFLATED)
        ZipFile.write(playlistsFile4, os.path.basename(playlistsFile4), compress_type=zipfile.ZIP_DEFLATED)
        dirpath = os.path.join(addon_data_dir, 'password','')
        basedir = os.path.dirname(dirpath) + '/'
        for root, dirs, files in os.walk(dirpath):
            dirname = root.replace(basedir, '')
            for f in files:
                ZipFile.write(root + '/' + f,  'password/' + f)
        ZipFile.close()   
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("KLTV: " + "  "+ path + "backup_pm.zip",localizedString(10126).encode('utf-8'), 6500, icon))

def unzip_PM_data():
    ZipFile = xbmcgui.Dialog().browse(int(1), localizedString(10122).encode('utf-8'), 'myprograms','.zip')
    if not ZipFile:
        return
    else:
        xbmc.executebuiltin("XBMC.Extract("+ os.path.join(xbmc.translatePath(ZipFile)) +","+ addon_data_dir +")")
        xbmc.sleep(400)
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("KLTV: ",localizedString(10125).encode('utf-8'), 6500, icon))
        xbmc.sleep(850)
        xbmc.executebuiltin("XBMC.Container.Refresh()")

percent = 0

def DownloaderClass(url,dest):
    
    dp = xbmcgui.DialogProgress()
    dp.create("Kodi Live TV ZIP DOWNLOADER","Downloading File",url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except: 
        percent = 100
        dp.update(percent)
        time.sleep(20)
        dp.close()
    if dp.iscanceled(): 
        dp.close()

def emptydir(top):
    
    if(top == '/' or top == "\\"): 
        return
    else:
        for root, dirs, files in os.walk(top, topdown=False):
            for name in files:
                if not bool('default.py' in name) and not bool('ziptools.py' in name):
                    os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name)) 
 
def clean_cache():

    for i in os.listdir(cdir):    
        rf = format(i)
        if not bool('.' in i):
            file = os.path.join( cdir , i )
            if os.path.isfile(file):
                os.remove(file)

    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ","m3u cache has been deleted!", 4500, icon))

def is_mp4(url):
    if url.find("index.php?key=")>0 or url.find("://gounlimited.")>0 or url.find("://woof.tube")>0 or url.find("://oload.")>0 or url.find("cloudvideo.tv")>0 or url.find("://racaty.com")>0 or url.find("://streamcloud.eu")>0 or url.find("google.com")>-1 or url.find("//verystream.com")>-1 or url.find("//cloud.allsync.com")>-1 or url.find("://videos.ctfassets.net")>-1 or url.find("nofile.io")>0 or url.find("hqporner.com")>0 or url.find("mediafire.com")>0 or url.find("vidoza.net")>0 or url.find("/yadi.sk/")>0 or url.find("streamcherry.com")>0 or url.find("streamtime.ml")>0 or url.find("my.pcloud.com")>0 or url.find("//ok.ru/video/")>0 or url.find("//www.ok.ru/video/")>0 or url.find("openload.")>0 or url.find("//pc.cd/")>0 or url.find("pornhd.com")>0 or url.find("vivo.sx")>0 or url.find("akvideo.")>0 or url.find("stream.moe")>0 or url.find("rapidvideo.")>0 or url.find("speedvideo.")>0 or url.find("fastvideo.")>0 or url.find("thevideo.me")>0 or url.find("wstream.")>0 or url.find("nowvideo.")>0 or url.find("streamango.")>0 or url.find("megadrive.")>0 or url.find("//jwp.io")>0 or url.find("content.jwplatform.com")>0 or url.find("megahd.")>0 or url.find("vidto.me")>0:
        return True
    else:
        return False
##############################
# Inizia creazione pagine
    
def Categories():
    #AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), "search1" , 65, find, isFolder=True)
    AddDir("[B]{0}[/B]".format(localizedString(10106).encode('utf-8')), "update" ,46 ,os.path.join(addonDir, "resources", "images", "update.png"), isFolder=True)
    AddDir("[B][ {0} ][/B]".format(localizedString(10003).encode('utf-8')), "favorites" ,30 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"))
    AddDir("[B]{0}[/B]".format(localizedString(10048).encode('utf-8')), "Channels" ,96 , os.path.join(addonDir, "resources", "images", "channels.png"))    
    
    if xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('PM_index')=="true":
        PM_index(r=False)
    else:
        AddDir("[B]{0}[/B]".format(localizedString(10047).encode('utf-8')), "Manager" ,39 , os.path.join(addonDir, "resources", "images", "playlist.png"))
    #if 'win32' or 'linux' or 'darwin' in sys.platform:
    #    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format((localizedString(10098)).encode('utf-8')) + " - Press [COLOR violet][ ALT ][/COLOR] + [COLOR violet][ F4 ][/COLOR] [COLOR orange]to close[/COLOR] browser window", "Offer" ,49 , os.path.join(addonDir, "resources", "images", "paypal.png"), isFolder=False)
    #AddDir("[COLOR violet][B]{0}[/B][/COLOR]".format("Check Links"), "Channels" ,99999 , os.path.join(addonDir, "resources", "images", "channels.png"))
    
def Channels():    
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), "search3" , 65, find, isFolder=True)
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10020).encode('utf-8')), "italian" ,35 , "https://kodilive.github.io/flag/it.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10021).encode('utf-8')), "french" ,36 , "https://kodilive.github.io/flag/fr.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10022).encode('utf-8')), "german" ,37 , "https://kodilive.github.io/flag/de.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10023).encode('utf-8')), "english" ,38 , "https://kodilive.github.io/flag/uk.png")
    #AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10028).encode('utf-8')), "mu.txt" ,2 , "https://kodilive.github.io/flag/mu.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10049).encode('utf-8')), "others" ,97 , os.path.join(addonDir, "resources", "images", "channels.png"))

def Others():    
    list = common.ReadList(playlistsFile)
    for item in list:
        mode = 2
        image = item.get('image', '')
        icon = image.encode("utf-8")
        name = localizedString(item["name"])
        cname = "[COLOR gold][B]{0}[/B][/COLOR]".format(name)
                            
        AddDir(cname ,item["url"], mode , icon)
    
    if xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('XXX_section')=="true":
        AddDir("[COLOR red][B]Video XXX[/B][/COLOR]" ,"?l=pornazzi", 2 , "https://kodilive.github.io/icon/XXX.png")
    
def importList():
    
    method = GetSourceLocation(localizedString(10120).encode('utf-8'), [localizedString(10122).encode('utf-8'), localizedString(10123).encode('utf-8')])
        
    if method == -1:
        return
    elif method == 0:
        listUrl = common.GetKeyboardText(localizedString(10005).encode('utf-8')).strip()
    else:
        listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.txt')
        if not listUrl:
            return
    if len(listUrl) < 1:
        return
 
    if common.check_url(listUrl):
        lista = common.OpenURL(listUrl)
    else:
        lista = common.ReadFile(listUrl)
 
    if os.path.isfile( playlistsFile3 ) : os.remove( playlistsFile3 )
    shutil.copyfile( playlistsFile2, playlistsFile3 )
    xbmc.sleep ( 500 )
    os.remove( playlistsFile2 )
    xbmc.sleep ( 500 )
    common.write_file( playlistsFile2, lista )
    xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ",localizedString(10124).encode('utf-8'), 3600, icon))    
  
def AddNewList():
	
    method1 = GetSourceLocation(localizedString(10001).encode('utf-8'), [localizedString(10040).encode('utf-8'), localizedString(10220).encode('utf-8'), localizedString(10042).encode('utf-8'), localizedString(10266).encode('utf-8')])
	
    if method1 == -1:
            return	
    elif method1 == 0:
        AddNewDir()
    elif method1 == 1:
        AddNewDir("xml")    
    elif method1 == 3:
        AddNewDir("pyt")
    else:
        listName = common.GetKeyboardText(localizedString(10004).encode('utf-8')).strip()
        if len(listName) < 1:
            return

        method = GetSourceLocation(localizedString(10002).encode('utf-8'), [localizedString(10016).encode('utf-8'), localizedString(10017).encode('utf-8')])	

        if method == -1:
            return
        elif method == 0:
            listUrl = common.GetKeyboardText(localizedString(10005).encode('utf-8')).strip()
        else:
            listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.m3u8|.m3u')
            if not listUrl:
                return
            
        if len(listUrl) < 1:
            return
        
        exists = ""
        list = common.ReadList(playlistsFile2)
        for item in list:
            if item["url"] == listUrl:
                exists = "yes"
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ",localizedString(10264).encode('utf-8'), 3600, icon))
                break       
        
        if exists == "":
            list.append({"name": listName, "url": listUrl})
            if common.SaveList(playlistsFile2, list):
                    xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
                    
def AddNewDir(loc = "l"):
    if loc == "xml":
        method = GetSourceLocation(localizedString(10221).encode('utf-8'), [localizedString(10222).encode('utf-8'), localizedString(10223).encode('utf-8')])
        
        if method == -1:
            return
        elif method == 0:
            listUrl = common.GetKeyboardText(localizedString(10224).encode('utf-8')).strip()
        else:
            listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10225).encode('utf-8'), 'myprograms','.xml')
    elif loc == "pyt":
        listName = common.GetKeyboardText(localizedString(10265).encode('utf-8')).strip()
        listUrl = common.GetKeyboardText(localizedString(10226).encode('utf-8')).strip()
    else:
        if loc == "l":
            method2 = GetSourceLocation(localizedString(10040).encode('utf-8'), [localizedString(10260).encode('utf-8'), localizedString(10043).encode('utf-8'), localizedString(10261).encode('utf-8')] )
         
            if method2 == -1:
                return           
            elif method2 == 0:
                listName = common.GetKeyboardText(localizedString(10263).encode('utf-8')).strip()
                listUrl = xbmcgui.Dialog().browse(int(0), localizedString(10041).encode('utf-8'), 'myprograms')       
            elif method2 == 1:
                listName = common.GetKeyboardText(localizedString(10263).encode('utf-8')).strip()
                listUrl = xbmcgui.Dialog().browse(int(0), localizedString(10041).encode('utf-8'), 'files')
            else:
                listName = common.GetKeyboardText(localizedString(10263).encode('utf-8')).strip()
                listUrl = common.GetKeyboardText(localizedString(10262).encode('utf-8')).strip() 

    if not listUrl or len(listUrl) < 1:
            return

    list = common.ReadList(playlistsFile4)
    Url = ""
    pUrl = ""
    
    if listUrl.endswith(".xml") or loc == "xml":
        if common.check_url(listUrl):
            response = common.OpenURL(listUrl)
        else:
            response = common.ReadFile(listUrl)
            
        Url = common.find_single_match(response,"<url>([^<]+)</url>").strip()
        pUrl = common.find_single_match(response,"<web>([^<]+)</web>").strip()
        xUrl = common.find_single_match(response,"<xweb>([^<]+)</xweb>").strip()
        
        if not Url == "":
            loc = "repo"
            listUrl = Url
            listName = common.find_single_match(response,"<name>([^<]+)</name>").strip()
        elif not pUrl == "":
            loc = "page"
            listUrl = pUrl
            listName = common.find_single_match(response,"<name>([^<]+)</name>").strip()
        elif not xUrl == "":
            loc = "xml"
            listUrl = xUrl
            listName = common.find_single_match(response,"<name>([^<]+)</name>").strip()
        else:
            listName = common.GetKeyboardText(localizedString(10263).encode('utf-8')).strip()
    else:
        if not listName:
            listName = listName.split("/")[-2]
    
    exists = ""
    
    if len(listUrl)>0 and len(listName)>0:
        for item in list:
            if item["url"] == listUrl:
                exists = "yes"
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ",localizedString(10264).encode('utf-8'), 3600, icon))
                break
        
        if exists == "":
            if loc == "xml":
                list.append({"name": listName, "url": listUrl, "exclude":"yes", "type":"xml"})
            elif loc == "page":
                list.append({"name": listName, "url": listUrl, "exclude":"yes", "type":"page"})
            elif loc == "pyt":
                list.append({"name": listName, "url": listUrl, "exclude":"yes", "type":"pyt"})
            else:
                list.append({"name": listName, "exclude":"yes", "url": listUrl})
                
            if common.SaveList(playlistsFile4, list):
                    xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
	
def RemoveFromLists(url):
    
    list = common.ReadList(playlistsFile2)
    for item in list:
        if item["url"] == url:
            list.remove(item)
            if common.SaveList(playlistsFile2, list):
                xbmc.executebuiltin("XBMC.Container.Refresh()")
            break

def RemoveDirFromLists(url,name):
    
    return_value = xbmcgui.Dialog().yesno(localizedString(10045).encode('utf-8'), localizedString(10206).encode('utf-8') + " " + name + "?")
    if not return_value == 0:
                
        list = common.ReadList(playlistsFile4)
        for item in list:
            if item["url"] == url:
                list.remove(item)
                if common.SaveList(playlistsFile4, list):
                    xbmc.executebuiltin("XBMC.Container.Refresh()")
                break


def m3uCategory(url,Logo=True):
    
    try:
        urldec = base64.decodestring(url)
        if common.check_url(urldec):
            url = urldec
    except:
        pass
    
    cdir = os.path.join(xbmc.translatePath("special://temp"),"files")
    
    if not common.check_url(url):
        list = common.m3u2list(os.path.join(chanDir, url)) 
    else :
        list = common.cachelist(url,cdir)
    
    playheaders = ""
    
    try:
        surl,playheaders=url.split('|')
    except:
        playheaders = ""
    
    xml = "<data>\r\t<type name=\"channels\">\r"
    
    for channel in list:
        name = channel["display_name"].replace("’","'")

        if channel.get("tvg_logo", ""): 
            logo = channel.get("tvg_logo", "")
            iconname = "https://kodilive.github.io/logo/" + logo
        else :
            iconname = TVICO
        
        if Logo == False:
            if channel.get("tvg_logo", "") and common.check_url(channel.get("tvg_logo", "")):
                iconname = channel.get("tvg_logo", "")
            else:
                iconname = TVICO
        
        channel["url"] = channel["url"].strip()
        if not playheaders == "":
            channel["url"] = channel["url"] + "|" + playheaders
        
        ext = "." + channel["url"].split(".")[-1]
        EXT = EXTV + EXTA
        
        xml = xml + "\t\t<item>\r"
        xml = xml + "\t\t\t<name>" + name.replace("\n", "").strip() + "</name>\r"
        xml = xml + "\t\t\t<color>violet</color>\r"
        xml = xml + "\t\t\t<year></year>\r"
        xml = xml + "\t\t\t<link>" + channel["url"] + "</link>\r"
        if channel.get("tvg_logo", "") and common.check_url(channel.get("tvg_logo", "")):
            xml = xml + "\t\t\t<icon>" + iconname + "</icon>\r"
            xml = xml + "\t\t\t<fanart>" + iconname + "</fanart>\r"
        else:
            xml = xml + "\t\t\t<icon></icon>\r"
            xml = xml + "\t\t\t<fanart></fanart>\r"            
        xml = xml + "\t\t\t<description></description>\r" 
        xml = xml + "\t\t</item>\r"
        
        if bool(ext in EXT) or is_mp4(channel["url"]):
            AddDir(name ,channel["url"],3, iconname, isFolder=False)
        else:
            FastDir(name,channel["url"],3,iconname,fanart="",description="",res=False,isFolder=False)
    
    xml = xml + "\t</type>\r</data>"
    common.mywrite(xml,'mylist_')
    
def xmlfDir(name,url,mode,icon="",fanart="",description="",genre="",year="",director="",rating="",cast="",writer="",country="",credit="",origurl="",trailer="",extended=""):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+ str(mode) + "&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(icon)+"&description="+urllib.quote_plus(description)
    liz = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
    ok = True
    
    if fanart == "":
        liz.setArt({'fanart': Addon.getAddonInfo('fanart')})
    else:
        liz.setArt({'fanart':fanart})
        
    liz.setArt({'thumb': icon}) 
    liz.setArt({'poster': icon}) 
    
    items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&name={2}&iconimage={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(icon)))]

    liz.setProperty( "Video", "false")
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Trailer": trailer, "Genre": genre, "Year" : year, "Director" : director, "Writer" : writer, "Cast" : cast.split(","), "Country" : country, "Rating": rating, "Credit": credit}) 

    if mode == 463:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        if not LFolder == "":
            items.append(('{0}'.format(localizedString(10166).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&iconimage={2}&name={3}&mode=300)'.format(sys.argv[0], urllib.quote_plus(url+"&t=furl"), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
    elif mode == 464 or url.find("?c=SerieTV&")>-1:
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        if not LSFolder == "":
            items.append(('{0}'.format(localizedString(10166).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&iconimage={2}&name={3}&mode=303)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
    else:
        xbmcplugin.setContent(int(sys.argv[1]), 'video')
    
    #xbmc.log("***Mode = " + str(mode) + " o : " + origurl, xbmc.LOGNOTICE) 
    liz.addContextMenuItems(items, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok        

def FastDir(name,url,mode,icon="",fanart="",description="",res=False,isFolder=True,linkType=None):

    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+ str(mode) + "&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(icon)+"&description="+urllib.quote_plus(description)
    liz = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
    ok = True
    
    if fanart == "":
        liz.setArt({'fanart': Addon.getAddonInfo('fanart')})
    else:
        liz.setArt({'fanart':fanart})
    
    liz.setArt({'thumb': icon}) 
    liz.setArt({'poster': icon})  
    
    items = [ ]
        
    if not isFolder and not mode==73:
        liz.setProperty('IsPlayable', 'true')
        liz.setProperty( "Video", "true")
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description })           
        items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&name={2}&iconimage={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(icon)))]
    
    if not res and not mode==73:
        
        try:
            urldec = base64.decodestring(url)
            if common.check_url(urldec):
                url = urldec
        except:
            pass
        
        #if url.find(".m3u8")>0:
        #    items.append(('Play with HLS-Player','XBMC.RunPlugin({0}?url={1}&iconimage={2}&name={3}&mode=5)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
    
        #if xbmcvfs.exists(ydldir):
        #    items.append(('Youtube-dl Control','XBMC.RunPlugin({0}?url={1}&name={2}&mode=80)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))

        items.append(('Refresh', 'Container.Refresh'))
    
    if linkType:
        u="XBMC.RunPlugin(%s&linkType=%s)" % (u, linkType)
        
    liz.addContextMenuItems(items, replaceItems=True)   
    #xbmc.log("Channel -->" + u, xbmc.LOGNOTICE)   
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
    return ok
    
def PlayUrl(name,url,iconimage=None):
    
    url = url.replace("\n","").replace("\r","")
    #name = name.encode('utf-8')
    urldec = ""
    
    try:
        urldec = base64.decodestring(url)
        if common.check_url(urldec):
            url = urldec
    except:
        pass    
    
    urluhd = 0
    
    if url.find("urhd.tv")>0:
        try:
            url = common.urhd(url)
            urluhd = 1
        except:
            pass
    
    
    if url.find(":enc")>0:
        url = rsich(url)
    
    if url.find("FirstOne:")>-1:
        url = FirstOne(url)    
        
       
    if url.find("plugin://plugin.googledrive/")>-1 or url.find("https://drive.google.com/")>-1:
        
        if url.find("open")>-1:
    
            pattern = r"https?:\/\/drive\.google\.com\/open\?id=(\S+)"
            replacement = r"https://drive.google.com/file/d/\$1/view"
            url = re.sub(pattern, replacement, url).replace("?usp=drive_open","")
        
        try:
            url = url.split("&amp;")[0]
            drive_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ), "plugin.googledrive")
            File = os.path.join(drive_data_dir,"accounts.cfg")
            if os.path.isfile(File):
                data = common.ReadFile(File)
                pattern = '"id" *: *"([^",]+)'
                did = re.search(pattern,data).group(1)        
            else:
                drive_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ), "plugin.googledrive","")
                if not xbmcvfs.exists(drive_data_dir):
                    xbmcvfs.mkdirs(drive_data_dir)
                xbmc.sleep(1000)
                test = os.path.join(addonDir, 'resources', 'accounts.cfg')
                shutil.copyfile(test,File)
                xbmc.sleep(1000)
                did = "12245222684353452302"
                
            if url.find("https://drive.google.com/")>-1:
                url = url.replace("https://drive.google.com/file/d/","plugin://plugin.googledrive/?item_id=").replace("/view","")
            
            url = url + "&amp;driveid=" + did + "&amp;item_driveid=1&amp;action=play"
        except:
            url = ""
        
    listitem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
    #listitem.setProperty( "Video", "true")
    #listitem.setInfo(type="Video", infoLabels={ "Title": name })
    #listitem.setProperty('IsPlayable','true')
    listitem.setPath(url)
    #if not url.find("plugin://plugin.video")>-1 or url.find("plugin://plugin.video.dailymotion")>-1 or url.find("plugin://plugin.video.youtube")>-1:
    #    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    #else:
    #    xbmc.Player().play(url,listitem)
        
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)    
    #xbmc.log("###########Played url = " + url, xbmc.LOGNOTICE) 

def findm3u(url, string="",live=False):
    
    if url == "ipbox":
        getIpBoxList(string=string,live=live)
        
    elif "urhd.tv" in url:
        
        ch_list = common.urhd_list()
        for idx, ch in enumerate(ch_list, 1):
            
            if ch["alive"]:
                active = ""
            else:
                active = " - [B][COLOR red][INACTIVE][/COLOR][/B]"
        
            display_name = ch["display_name"]
            url = "http://urhd.tv/" + ch["display_name"].lower()
            
            if string == "":    
                AddDir("[COLOR orangered]" + display_name + "[/COLOR]" + active, url, 3 , TVICO, "", isFolder=False)
            else:
                sname = common.BBTagRemove(display_name).replace("_"," ").lower()
                if sname.find(string)>-1:
                    listName = "  " + "[CR][I][COLOR cyan][LIGHT]* {0}[/COLOR]".format(localizedString(10004).encode('utf-8')) + " -->  [COLOR yellow]{0}[/COLOR][/I][/LIGHT]".format("urhd.tv")
                    cname = "[COLOR orange][B]{0}[/B][/COLOR]".format(display_name) + active + listName
                    AddDir(cname , url, 3 , TVICO, "", isFolder=False)
    else:
        
        from bs4 import BeautifulSoup
        from urlparse import urlparse
        import html5lib
        
        try:
            urldec = base64.decodestring(url)
            if common.check_url(urldec):
                url = urldec
        except:
            pass
        
        data = common.cachepage(url,7200,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
        soup = BeautifulSoup(data,'html5lib')
        flink = 0
        
        if string == "":
            AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), url, 81, find, isFolder=True)
        nu = 0
        for link in soup.find_all('a', href=True):
            if '.m3u' in link['href']:
                nu = nu + 1
                flink = 1
                nurl = urlparse(link['href'])
                listnamext = nurl.path.split("/")
                if url.find("SAM.html")>0:
                    ListName = "[B][COLOR green]S[/COLOR][COLOR withe]a[/COLOR][COLOR red]M[/COLOR] [COLOR orange]  " + str(nu) + " [/COLOR][/B]"
                else:
                    listname = listnamext[-1].split(".m3u")
                    ListName = listname[0]
                    
                listurl = link['href']
                if string == "":
                    AddDir("[COLOR green]" + ListName + "[/COLOR]", listurl, 51, "http://findicons.com/files/icons/1331/matrix_rebooted/128/text_clipping_file.png", isFolder=True)
                else:
                    sch_m3u(listurl,string,ListName,live=live)
        
        if flink == 0:
            patron = '>(http:\/\/(.*?)\/.*?get.php.*?)<'
            matches = re.compile(patron, re.DOTALL).findall(data)

            for scrapedurl in matches:
                
                listurl = scrapedurl[0].replace("&amp;","&")
                listname = scrapedurl[0].split("/")[-2]
                #xbmc.log("Finded url = " + listurl, xbmc.LOGNOTICE) 
                
                if string == "":
                    AddDir("[COLOR green]" + listname + "[/COLOR]", listurl, 51, "http://findicons.com/files/icons/1331/matrix_rebooted/128/text_clipping_file.png", isFolder=True)
                else:
                    sch_m3u(listurl,string,listname,live=live)

            patron = 'url=(http:\/\/(.*?)\/.*?.ts.*?)<'
            matches = re.compile(patron, re.DOTALL).findall(data)
            for scrapedurl in matches:
                
                lname = scrapedurl[0].split("&amp;streamtype=TSDOWNLOADER&amp;name=")
                listurl = lname[0]
                listname = lname[1]
                #xbmc.log("Finded url = " + listurl, xbmc.LOGNOTICE)                 
                if string == "":
                    AddDir("[COLOR orangered]" + lname[1] + "[/COLOR]", lname[0], 3 , TVICO, "", isFolder=False)
                else:
                    sname = common.BBTagRemove(lname[1]).replace("_"," ").lower()
                    if sname.find(string)>-1:
                        listName = "  " + "[CR][I][COLOR cyan][LIGHT]Youtube-Playlist[/COLOR] -->  [COLOR yellow]{0}[/COLOR][/I][/LIGHT]".format("IPTV list")
                        titolo = "[COLOR orangered]" + lname[1] + "[/COLOR]" + listName
                        AddDir(titolo,lname[0], 3 , TVICO, "", isFolder=False)

def xmlClean(data):
    data = data.replace("&","&amp;").replace("&amp;amp;","&amp;").replace("title>","name>").replace("question>","name>")
    data = data.replace("name=\"playlist\"","name=\"ylist\"").replace("’","'").replace("–","-")
    data = data.replace("name='playlist'","name='ylist'")
    return data

def OpenXML(url, string="",live=False):
    
    from xml.dom import minidom
    
    try:
        urldec = base64.decodestring(url)
        if common.check_url(urldec):
            url = urldec
    except:
        pass

    enckey=False
    urlrec = url
    
    if common.check_url(url):
        
        if '$$ref=' in url:
            enckey=url.split('$$ref=')[1].split('$$')[0]
            rp='$$ref=%s$$'%enckey
            url=url.replace(rp,"")
        
        data = common.OpenURL(url,string=string)
    else:
        try:
            f = open(url,'r')
        except:
            f = open(url.decode("utf-8"),"r")

        data = f.read().replace("\n\n", "")
        f.close()
    
    datafile =  os.path.join(pwdir , base64.standard_b64encode(urlrec))
    if os.path.isfile(datafile):
        f = open(datafile,'r')
        dataf = f.read().replace("\n\n", "")
        f.close() 
        enckm = common.find_single_match(dataf,"<enckey>([^<]+)</enckey>").strip()
        if not enckm == "": 
            enckey = enckm
        
    if enckey:
        if enckey == "x" and string == "":
            
            stringa = common.GetKeyboardText("Enter a decryption key", "")
            if len(stringa) < 1:
                return
            enckey = stringa        
        
            content = "<enckey>" + enckey + "</enckey>"
            if not enckey == "":
                common.write_file(datafile, content)
        
        if not enckey == "x":
            import pyaes
            enckey=enckey.encode("ascii")
            print enckey
            missingbytes=16-len(enckey)
            enckey=enckey+(chr(0)*(missingbytes))
            #print repr(enckey)
            data=base64.b64decode(data)
            decryptor = pyaes.new(enckey , pyaes.MODE_ECB, IV=None)
            data=decryptor.decrypt(data).split('\0')[0]

    try:
        data64 = base64.decodestring(data)
        if data64.find("<data>")>-1:
            data = data64
    except:
        pass    

    
    if data.startswith("|*|"):

        code = data.split("|*|")
        for ex in code:
            if not ex == "":
                #xbmc.log("### xml data : " + ex, xbmc.LOGNOTICE)
                if ex.find(",3,")>-1:
                    exec("AddDir(" + ex + ")", globals(), locals())
                else:
                    exec("xmlfDir(" + ex + ")", globals(), locals())

        return

    data = xmlClean(data)
    
    if "<SetViewMode>" in data:
        try:
            viewmode=re.findall('<SetViewMode>(.*?)<',data)[0]
            xbmc.executebuiltin("Container.SetViewMode(%s)"%viewmode)
        except: 
            pass  
    
    try: 
        xmldoc = minidom.parseString(data)
    
        Data = xmldoc.getElementsByTagName('data')
        r = 0
        nt = ""
        ads = 0
        
        if  string == "":
            for d in Data:
                Type = d.getElementsByTagName("type")
                for node in Type:
                    nt = node.getAttribute('name')
                    if nt == "ylist":
                        r = 1
                        break                    
                    if nt == "list":
                        r = 1
                        break
                    if nt == "folder":
                        r = 1
                        break
                    if nt == "title":
                        r = 0
                        break
                    if nt == "captcha":
                        r = 0
                        break
            if r==1:
                AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), urlrec, 66, find, isFolder=True)
                
        option = [ ]
        q = [ ]
        copt = 0        
            
        for d in Data:
            Type = d.getElementsByTagName("type")
            ext = ""

            for node in Type:
                
                prent = nt
                
                nt = node.getAttribute('name')
                if nt == "channels":
                    mode = 3
                    icon = TVICO
                    isFolder=False                                
                elif nt == "film":
                    mode = 3
                    icon = TVICO
                    isFolder=False
                elif nt == "serie":
                    mode = 3
                    icon = TVICO
                    isFolder=False                
                elif nt == "list":
                    mode = 51
                    icon = iconlist
                    isFolder=True
                elif nt == "ylist":
                    mode = 93
                    icon = icondir
                    isFolder=True
                elif nt == "folder":    
                    icon = icondir
                elif nt == "title":
                    mode = 400
                    icon = ""
                elif nt == "captcha":
                    mode = 400
                    icon = ""
                    isFolder=False
                
                itemlist = node.getElementsByTagName("item")
                
                Link = "" 
                L2 = ""
                
                Year = "" 
                Genre = ""
                Description = ""
                Director = ""
                Writer = ""
                Cast = ""
                Country = ""
                Color = ""
                fanart = ""
                Rating = ""
                
                for s in itemlist:
                    
                    if not url.find("f=")>-1 and url.find(".xml")>0 and url.find("php?c=")>0:
                        Year = "" 
                        Genre = ""
                        Description = ""
                        Director = ""
                        Writer = ""
                        Cast = ""
                        Country = ""
                        Color = ""
                        fanart = "" 
                        Rating = "" 
                    
                    try:
                        Name = s.getElementsByTagName("name")[0].firstChild.data.decode("ascii")
                    except:
                        try:
                            Name = s.getElementsByTagName("name")[0].firstChild.data.decode('utf-8')
                        except:
                            try:
                                Name = s.getElementsByTagName("name")[0].firstChild.data
                            except:
                                Name = "[COLOR red]-- Error in tag name --[/COLOR]"
                    try:
                        Year = s.getElementsByTagName("year")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass                    
                    try:
                        Director = s.getElementsByTagName("director")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass
                    try:
                        Writer = s.getElementsByTagName("writer")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass 
                    try:
                        Cast = s.getElementsByTagName("cast")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass 
                    try:
                        Country = s.getElementsByTagName("country")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass 
                    try:
                        Genre = s.getElementsByTagName("genre")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass
                    try:
                        Rating = str(s.getElementsByTagName("rating")[0].childNodes[0].nodeValue).encode("UTF-8")
                    except:
                        pass
                    try:
                        Credit = str(float(s.getElementsByTagName("credit")[0].childNodes[0].nodeValue)).encode("UTF-8")
                    except:
                        Credit = ""
                    try:
                        Description = s.getElementsByTagName("description")[0].childNodes[0].nodeValue.encode("UTF-8")
                    except:
                        pass
                    try:
                        Vid = s.getElementsByTagName("vid")[0].childNodes[0].nodeValue
                    except:
                        Vid = ""
                        pass
                    try:
                        Path = s.getElementsByTagName("path")[0].childNodes[0].nodeValue
                    except:
                        Path = ""
                        pass
                    
                    try:
                        sid = s.getElementsByTagName("sid")[0].childNodes[0].nodeValue
                    except:
                        sid = ""
                    
                    try:
                        Link = s.getElementsByTagName("link")[0].childNodes[0].nodeValue.strip()
                    except:
                        Link = ""
                    
                    onetofive = range(1,6)
                    
                    for count in onetofive:
                        
                        try:
                            L2 = s.getElementsByTagName("link")[count].childNodes[0].nodeValue.strip()
                            if not L2=="":
                                Link = Link + " " + L2
                        except:
                            L2 == ""
                            pass
                    
                    try:
                        Color = s.getElementsByTagName("color")[0].childNodes[0].nodeValue
                    except:
                        pass
                    try:
                        icon = s.getElementsByTagName("icon")[0].childNodes[0].nodeValue
                    except:
                        pass
                    try:
                        fanart = s.getElementsByTagName("fanart")[0].childNodes[0].nodeValue
                    except:
                        pass
                    try:
                        Schearch = s.getElementsByTagName("schearch")[0].childNodes[0].nodeValue
                    except:
                        Schearch = "on"
                
                    #xbmc.log("### Rating film : " + Rating, xbmc.LOGNOTICE)
                    
                    if nt == "captcha":
                        
                        for count in range(0,7):
                            
                            try:
                                option.append(s.getElementsByTagName("option")[count].childNodes[0].nodeValue.strip())
                                q.append(str(count))
                            except:
                                pass 
                    
                    if nt == "folder":
                        
                        if not Path == "":
                            if Path == "$download" and string == "":
                                Link = DFolder
                            else:
                                Link = Path
                            mode = 64
                            isFolder=True
                        else:
                            mode = 63
                            isFolder=True 

                    elif nt == "ylist":
                        mode = 93
                        Link = Vid
                        if Color == "":
                            Color = "pink"
                        if icon == "":
                            icon = icondir
                        isFolder=True                        
                    elif nt == "title":
                        isFolder=False
                        mode = 400
                        Link = ""
                    elif nt == "captcha":
                        mode = 401
                        
                    if icon == "video":
                        icon = video
                    if icon == "audio":
                        icon = audio
                    if icon == "folder":
                        icon = icondir
                    if icon == "list":    
                        icon = iconlist
                    
                    if not Color == "" and not Name == "Inv1sib1l3":
                        cname = "[COLOR " + Color + "][B]" + Name + "[/B][/COLOR]"
                    else:
                        cname = Name
                        
                    if nt == "list" and Link.startswith('page://'):
                        Link = Link.replace("page://","")
                        mode = 79                                               
                    
                    if not nt == "captcha":
                    
                        if string == "":    
                            #xbmc.log("### xml name : " + cname, xbmc.LOGNOTICE)
                            if not Name == "Inv1sib1l3":
                                if mode == 63:
                                    xmlfDir(cname,Link,mode,icon=icon,fanart=fanart,description=Description,genre=Genre,year=Year,director=Director,rating=Rating,cast=Cast,writer=Writer,country=Country,credit=Credit,origurl=url+"||"+nt)
                                else:
                                    AddDir(cname,Link,mode,icon,description=Description,isFolder=isFolder,background=fanart,genre=Genre,year=Year,director=Director,writer=Writer,cast=Cast,country=Country,rating=Rating,credit=Credit,origurl=url+"||"+nt)
                                    #xbmc.log("### xml address : " + urlrec, xbmc.LOGNOTICE)
                        elif not Schearch == "off":
                            sname = common.BBTagRemove(Name).replace("_"," ").replace("%20"," ").replace("%27","'").lower()
                            if mode == 3 and sname.find(string)>-1 and not Link == "":
                                EXT = EXTV + EXTA
                                #xbmc.log("** Find in Name :" + Name, xbmc.LOGNOTICE)
                                
                                sname = url
                                if url.find("index.php")>-1:
                                    if Name.find("Trailer & Info:")>-1:
                                        Name = "[COLOR pink]" + Name + "[/COLOR]"
                                    else:
                                        Name = "[COLOR violet]" + Name + "[/COLOR]"
                                    
                                    sname = sname.split("&sid=")[0].replace("%27","'")    
                                    sname = sname.split("&f=")[1].replace("+"," ")
                                    listName = "  " + "[CR][I][COLOR cyan][LIGHT]* File [/COLOR]" + " -->  " + sname + "[/I][/LIGHT]"
                                    cname = "[COLOR orange][B]" + Name + "[/B][/COLOR]" + listName
                                        
                                if is_mp4(Link):
                                    AddDir(cname,Link,mode,icon,description=Description,isFolder=isFolder,background=fanart,genre=Genre,year=Year,director=Director,writer=Writer,cast=Cast,country=Country,rating=Rating,credit=Credit,origurl=url+"||"+nt)
                                elif not bool(ext in EXT) or not live:
                                    if not bool(ext in EXT):
                                        FastDir(cname,Link,mode,icon,fanart=fanart,description=Description,res=True,isFolder=False)
                                    else:
                                        AddDir(cname,Link,mode,icon,description=Description,isFolder=isFolder,background=fanart,genre=Genre,year=Year,director=Director,writer=Writer,cast=Cast,country=Country,rating=Rating,credit=Credit,origurl=url+"||"+nt)
                            
                            if not mode == 3 and not Link == "":
                                if sname.find(string)>-1:
                            
                                    sname = url
                                    Fnam = "Folder"
                                    if sname.find("index.php")>-1:
                                        sname = sname.split("c=")[1].split("&sid=")[0]
                                        if sname.find("f=")>-1:
                                            sname = sname.split("&f=")[1].replace("+"," ")
                                            Fnam = "File"
                                                
                                    listName = "  " + "[CR][I][COLOR cyan][LIGHT]* " + Fnam + " [/COLOR]" + " -->  [COLOR yellow]" + sname + "[/COLOR][/I][/LIGHT]"
                                    cname = "[COLOR lightgreen][B]" + Name + "[/B][/COLOR]" + listName
                                    
                                    AddDir(cname,Link,mode,icon,description=Description,isFolder=isFolder,background=fanart,genre=Genre,year=Year,director=Director,writer=Writer,cast=Cast,country=Country,rating=Rating,credit=Credit)
                            
                            if mode == 51 or mode == 79:
                                sch_m3u(Link,string,sname,live=live)
                            if mode == 64:
                                PMFolder(Link,string,live=live)
                            if mode == 63:
                                OpenXML(Link,string,live=live)
                            if mode == 93:
                                Yplayl(Link,string,live=live)
                            
                            
                #if prent == "title" and string == "" and ads == 0:
                #    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), urlrec, 66, find, isFolder=True)
                #    ads = 1
                if nt == "captcha" and string == "" and not sid =="":
                    index = xbmcgui.Dialog().select(Name, list=option)
                
                    if index > -1:
                        url = url.strip()
                        url = url.split("index.php?reponse=")[0]
                        OpenXML(url + "index.php?reponse=" + q[index]+"&sid=" + sid,string,live=live)
                    else:
                        sys.exit()
                        
    except:
        xbmc.log("** XML ERROR!! : " + url.split("/")[-1], xbmc.LOGNOTICE)

def PMFolder( folder , string="",live=False):
    
    try:
        urldec = base64.decodestring(folder)
        if common.check_url(urldec):
            folder = urldec
    except:
        pass

    urlx = folder
    pw = ""
    
    if urlx.find("@")>-1:
        US = ""
        URL1 = urlx.split("@")[0]
    
        if urlx.startswith("http:"):
            proto = "http://"
        elif urlx.startswith("smb:"):
            proto = "smb://"
        elif urlx.startswith("ftp:"):
            proto = "ftp://"
        else:
            proto = "https://" 
    
        URL1 = urlx.replace("http://","").replace("https://","").replace("ftp://","").replace("smb://","")
        us = URL1.split(":")[0]
        pw = URL1.split(":")[1]
        pw = pw.split("@")[0]
        
        datafile =  os.path.join( pwdir , base64.standard_b64encode(folder))
        pwm = ""
        usm = ""
        t = 0
        
        if os.path.isfile(datafile):
            f = open(datafile,'r')
            data = f.read().replace("\n\n", "")
            f.close() 
            pwm = common.find_single_match(data,"<password>([^<]+)</password>").strip()
            if not pwm == "": 
                pw = pwm
            usm = common.find_single_match(data,"<username>([^<]+)</username>").strip()
            if not usm == "": 
                us = usm
            folder = proto + us + ":" + pw + "@" + urlx.split("@")[1]
            
        if pw =="x" and string == "":
            if not us == "x":
                US = us
            stringa = common.GetKeyboardText("Enter username", US)
            if len(stringa) < 1:
                return
            us = stringa
            if not pw == "x":
                p = pw
            else:
                p = ""
                
            stringa = common.GetKeyboardText("Enter password", p)
            if len(stringa) < 1:
                return
            pw = stringa
            folder = proto + us + ":" + pw + "@" + urlx.split("@")[1]
            if os.path.isfile(datafile):
                os.remove(datafile)
                xbmc.sleep(1200)
            
        if not os.path.isfile(datafile) and string == "":
            content = "<username>" + us + "</username><password>" + pw + "</password>"
            common.write_file(datafile, content)
    
    DF =  folder
    dirs, files = xbmcvfs.listdir(DF)
    EXT = [".m3u8"] + EXTV + EXTA 
    
    files.sort()
    if  string == "" and not DF == LFolder and not DF.find(LSFolder)>-1:
        AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), folder, 65, find, isFolder=True)
   
    if DF == LFolder and not LFolder == "":
        AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10166).encode('utf-8')), "addlib" , 302 ,os.path.join(addonDir, "resources", "images", "New-file.png"), isFolder=False)
   
    #if DF == DFolder and string == "":        
    #    src = os.path.join(xbmc.translatePath("special://userdata/addon_data" ), 'script.module.youtube.dl', 'tmp')
    #    AddDir("[COLOR red][B]{0}[/B][/COLOR]".format("Tmp"), src , 54, icondir, isFolder=True)
    
    for i in dirs:
        rf = i
        cname = "[COLOR lightgreen][B]" + rf + "[/B][/COLOR]"
        
        if common.check_url(DF):
            url = DF  + rf + "/"
        else:
            url = os.path.join(DF, rf)

        url = url.replace("\r","").replace("\n","").strip()
        cname = cname.replace("%20"," ").replace("\r","").replace("\n","").strip().decode("utf-8")
        if string == "":
            AddDir(cname, url, 54, icondir, isFolder=True)
        else:
            PMFolder( url , string, live=live)
            
    for i in files:
        rf = i
        ext = "." + rf.split(".")[-1]
        
        if ext == ".xml" or ext == ".m3u" or ext == ".txt":
            
            Name = rf.replace("%20"," ").replace("\r","").replace("\n","").replace(ext,"").strip().decode("utf-8")
            Name = "[COLOR lightgreen][B]" + Name + "[/B][/COLOR]"
            
            if common.check_url(DF):
                url = DF + rf
            else:
                url = os.path.join(DF, rf)
            if string == "":
                if ext == ".m3u" or ext == ".txt":
                    AddDir(Name, url, 51, icondir, isFolder=True)
                else:    
                    AddDir(Name, url, 63, icondir, isFolder=True) 
            else:
                if ext == ".m3u" or ext == ".txt":
                    sname = common.BBTagRemove(Name).replace("_"," ").replace("%20"," ").lower().decode("utf-8")
                    sch_m3u(url,string,sname,live=live)
                else:
                    OpenXML(url,string,live=live)

    for i in files:    
        rf = i
        ext = "." + rf.split(".")[-1]
        
        if bool(ext in EXT) or ext == ".strm":
            
            Name = rf.replace("%20"," ").replace("\r","").replace("\n","").strip().decode("utf-8")

            if common.check_url(DF):
                url = DF + rf
            else:
                url = os.path.join(DF, rf)
		
            url = url.replace("\r","").replace("\n","").strip()

            if url.endswith(".m3u8"):
                if string == "":
                    cname = "[COLOR green][B]" + Name + "[/B][/COLOR]"
                    AddDir(cname, url, 51, iconlist, isFolder=True)
                else:
                    sname = common.BBTagRemove(Name).replace("_"," ").replace("%20"," ").lower()
                    sch_m3u(url,string,sname,live=live)
            else:
                perc = -1
                p = ""
                EP = ""
                    
                if xbmcvfs.exists(url + ".resume"):
                    EP = ".resume"
                elif xbmcvfs.exists(url + ".stopped"):
                    EP = ".stopped"
                elif xbmcvfs.exists(url + ".ginfo"):
                    EP = ".ginfo"
                else:
                    perc = -1
                if not  EP == "":
                    PERC = common.ReadFile(url + EP).replace("\r","").split("\n")
                    perc = int(PERC[0])
                        
                if not perc <=0:
                    size = 0
                    size = xbmcvfs.Stat(url).st_size()
                        
                    if size > 0:
                        perc = round((100.0*size)/int(perc), 2)

                        col = "green"
                            
                        if perc <80:
                            col = "yellow"
                        if perc <55:
                            col = "orange"
                        if perc <35:
                            col = "orangered"
                        if perc <15:
                            col = "red"
                        
                        if perc <100:
                            p = " - [B][COLOR cyan][ [COLOR " + col + "]" + str(perc) + "% [/COLOR]][/B][/COLOR]"
                        else:
                            p = ""
                            xbmcvfs.delete(url + EP)

                elif not EP == "":
                    p = " - [B][COLOR cyan][ [COLOR yellow] Download in progress [/COLOR]][/B][/COLOR]"

        
                if bool(ext in EXTV):
                    icon = video
                else:
                    icon = audio
                
                if string == "":    
                    cname = "[COLOR CCCCFFFF][B]" + Name + "[/B][/COLOR]" + p
                    if ext == ".strm":
                        AddDir(cname , url, 301 , icon, "", isFolder=False)
                    else:
                        AddDir(cname , url, 50 , icon, "", isFolder=False)
                else:
                    EXT1 = EXTV + EXTA 
                    if bool(ext in EXT1) and not live:
                        sname = common.BBTagRemove(Name).replace("_"," ").lower()
                        if sname.find(string)>-1:
                            cname = "[COLOR CCCCFFFF][B]" + Name + "[/B][/COLOR]" + p
                            AddDir(cname , url, 50 , icon, "", isFolder=False)
                        

def AddDir(name,url,mode,iconimage,description="",isFolder=True,background="",genre="",year="",director="",writer="",cast="",country="",rating="",credit="",origurl="",trailer="",extended=""):
    
    url = url.replace('\n','')
    url = url.replace('\r','')
    url = url.strip()
    try:
        urlz = url.split("|")[1]
    except:
        urlz = ""
    
    name = name.strip()
        
    EXTM = EXTV + EXTA

    zyz="?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    u=sys.argv[0]+zyz    
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

    liz.setArt({'fanart': Addon.getAddonInfo('fanart')})
    liz.setArt({'thumb': iconimage})
    liz.setArt({'poster': iconimage})
    
    ext = ""
	
    if not background == "":
            liz.setProperty('fanart_image', background)
            
    if mode == 4 or mode == 21 or mode == 51 or mode == 54 or mode == 50 or mode == 60 or mode == 63 or mode == 64 or mode == 70 or mode == 79 or mode == 93 or mode == 82 or mode == 98 or mode == 630 or mode == 301 or mode == 302:
        items = [ ]
        
        if mode == 21 or mode == 63 or mode == 64 or mode == 70 or mode == 79 or mode == 93 or mode == 98 or mode == 630:
            urlE = url
            try:
                urldec = base64.decodestring(url)
                if common.check_url(urldec):
                    url = urldec
            except:
                pass            
            
            if not mode == 64 and not mode == 63 and not mode == 630 and not mode == 93:
                items = [('{0}'.format(localizedString(10008).encode('utf-8')) + name, 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=55)'.format(sys.argv[0], urllib.quote_plus(urlE), urllib.quote_plus(name)))]
                items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=61)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
                if not url == "ipbox":
                    items.append(('{0}'.format(localizedString(10019).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=95)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            
            if url.find("@")>0:
                datafile = os.path.join( pwdir , base64.standard_b64encode(url) )
                if os.path.isfile(datafile):
                    items.append((localizedString(10207).encode('utf-8'), 'XBMC.RunPlugin({0}?url={1}&mode=56)'.format(sys.argv[0], urllib.quote_plus(url))))

            if mode == 63 or mode == 70:
                if url.find("$$ref=x$$")>0:
                    datafile = os.path.join( pwdir , base64.standard_b64encode(url) )
                    if os.path.isfile(datafile):
                        items.append((localizedString(10215).encode('utf-8'), 'XBMC.RunPlugin({0}?url={1}&mode=56)'.format(sys.argv[0], urllib.quote_plus(url))))
            if mode == 63:
                items.append(('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&iconimage={2}&name={3}&mode=31)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
            if mode == 630:
                names = name.decode("utf8")
                items.append(('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&iconimage={2}&name={3}&mode=33)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(names))))

            if mode == 63 or mode == 21 or mode == 70 or mode == 79 or mode == 93:
                listDir = common.ReadList(playlistsFile4)
                for fold in listDir:
                    if not url == urlE:
                        t1 = fold["url"]
                        t2 = urlE
                    else:
                        t1 = fold["url"].lower()
                        t2 = url.lower()
                        
                    if t1 == t2 and not xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('PM_index')=="true":
                        e = ""
                        try:
                            e = fold["exclude"]
                        except:
                            pass
                        
                        if e == "yes":
                            items.append((localizedString(10252).encode('utf-8'), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=68)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
                        else:
                            items.append((localizedString(10251).encode('utf-8'), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=67)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
                
                TempName = base64.standard_b64encode(url)
                tmp = os.path.join(cdir, TempName)
            
                if os.path.isfile(tmp):            
                    items.append(('{0}'.format(localizedString(10105).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=94)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
                
        if mode == 4:
            
            if url.find("get.php?username=")>0 or name.lower().find("fast open")>-1 or name.lower().find("slow open")>-1 or name.lower().find("tv_channels")>-1 or name.lower().find("[iptv]")>-1:
                items.append(('Check List : [COLOR yellow]' + common.BBTagRemove(name) + '[/COLOR]', 'XBMC.RunPlugin({0}?url={1}&mode=90&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
                    
            items.append(('{0}'.format(localizedString(10008).encode('utf-8')) + name, 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url))))
            
            items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=23)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            items.append(('{0}'.format(localizedString(10019).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=24)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            
            TempName = base64.standard_b64encode(url)
            tmp = os.path.join(cdir, TempName)
            
            if os.path.isfile(tmp):
                items.append(('{0}'.format(localizedString(10105).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=94)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            
        if mode ==51 or mode == 50 or mode == 301:
            name = common.BBTagRemove(name)
            
            try:
                urldec = base64.decodestring(url)
                if common.check_url(urldec):
                    url = urldec
            except:
                pass
            
            liz.addContextMenuItems([], replaceItems=True)   
            
            if not common.check_url(url) or url.find("smb://")>-1:
                
                if LSFolder == "" or not url.find(LSFolder)>-1:    
                    items = [('{0}'.format(localizedString(10205).encode('utf-8')) + ' : ' + name, 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=52)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name)))]
            
            if url.find("get.php?username=")>0 or name.lower().find("fast open")>-1 or name.lower().find("slow open")>-1 or name.lower().find("tv_channels")>-1 or name.lower().find("[iptv]")>-1:
                items.append(('Check List : [COLOR yellow]' + name + '[/COLOR]', 'XBMC.RunPlugin({0}?url={1}&mode=90&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
            
            TempName = base64.standard_b64encode(url)
            tmp = os.path.join(cdir, TempName)
            
            if os.path.isfile(tmp):            
                items.append(('{0}'.format(localizedString(10105).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=94)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
        
        if mode == 50:
            ext = url.split('.')[-1]
            namefile = urllib.unquote(os.path.basename(url)).replace("." + ext,"")
            if url.find("pornhd.com")>0:
                namefile = urllib.unquote(os.path.basename(url)).split('.')[-2]
            
            if xbmcvfs.exists( url + ".stopped"):
                urlx = common.ReadFile(url + ".stopped").replace("\r","").split("\n")
                items.append((localizedString(10213).encode('utf-8') + ' : ' + namefile, 'XBMC.RunPlugin({0}?url={1}&mode=7&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(namefile))))
            elif xbmcvfs.exists( url + ".resume"):
                urlx = common.ReadFile(url + ".resume").replace("\r","").split("\n")
                items.append((localizedString(10212).encode('utf-8') + ' : ' + namefile, 'XBMC.RunPlugin({0}?url={1}&mode=57&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(namefile))))
            
            items.append(('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name))))
            
        if mode ==51 or mode == 50:
            if not common.check_url(url) or url.find("smb://")>-1:
                if not xbmcvfs.exists( url + ".stopped") and not xbmcvfs.exists( url + ".resume"):
                    items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=53)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            
            #items.append(('Youtube-dl Control','XBMC.RunPlugin({0}?url={1}&name={2}&mode=80)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            items.append(('Refresh', 'Container.Refresh'))
        
        if mode == 50:
            if bool(ext in EXTV):
                liz.addContextMenuItems(items)
            else:
                liz.addContextMenuItems(items, replaceItems=True)
        else:
            liz.addContextMenuItems(items)	

            
    if mode == 3 or mode == 32:
        #xbmc.log("* name :"+name, xbmc.LOGNOTICE)
        
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Trailer": trailer, "Genre": genre, "Year" : year, "Director" : director, "Writer" : writer, "Cast" : cast.split(","), "Country" : country, "Rating": rating, "Credit": credit})
        if not url.find("plugin://script.extendedinfo")>-1:
            liz.setProperty("Video", "true")
            liz.setProperty('IsPlayable', 'true')
        if mode == 3:
            items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name)))]
            #items.append(('{0}'.format(localizedString(10166).encode('utf-8')), 'XBMC.RunPlugin(' + sys.argv[0] + '?url=' + urllib.quote_plus(zyz) + '&name=' + urllib.quote_plus(name) + '&mode=300)'))
        else:
            items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(name)))]
            names = name.decode("utf8")
            items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin(' + sys.argv[0] + '?url=' + urllib.quote_plus(url) + '&name=' + urllib.quote_plus(names) + '&mode=69)'))
        
        ext = '.' + url.split('.')[-1]
        ref = 1
        
        if bool(ext in EXTM) or is_mp4(url):
            
            if is_mp4(url):
                ext = '.mp4'
                xbmcplugin.setContent(int(sys.argv[1]), 'video')            
            
            #xbmc.log("* origurl :" + origurl, xbmc.LOGNOTICE)
            
            if common.check_url(url):
                name = name.replace(","," ")
                name = name.replace("  "," ")
                pname = common.BBTagRemove(name).replace(":","-").replace(".","-").replace("/","-")
                
                try:
                    pname = pname.split('[CR]')[-2]
                    ref = 0
                except:
                    pass
                
                pname = pname.strip()


                file = DFolder + pname + ext
                
                if ref == 10:
                    items.append(('Download : ' + pname.decode("utf8"), 'XBMC.RunPlugin('+sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode=6&iconimage='+urllib.quote_plus(iconimage)+'&name='+urllib.quote_plus(pname)+')'))
    
                else:
                    if ref == 0:
                
                        if xbmcvfs.exists(file + ".stopped") and xbmcvfs.exists(file):
                            urlx = common.ReadFile(file + ".stopped").replace("\r","").split("\n")
                            items.append((localizedString(10213).encode('utf-8') + ' : ' + pname, 'XBMC.RunPlugin({0}?url={1}&mode=6&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(pname))))
                            items.append((localizedString(10214).encode('utf-8') +' : ' + pname, 'XBMC.RunPlugin({0}?url={1}&mode=71&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(pname))))
                        elif xbmcvfs.exists(file + ".resume") and xbmcvfs.exists(file):
                            urlx = common.ReadFile(file + ".resume").replace("\r","").split("\n")
                            items.append((localizedString(10212).encode('utf-8') + ' : ' + pname, 'XBMC.RunPlugin({0}?url={1}&mode=72&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(pname))))
                        else:
                            items.append(('Download : ' + pname, 'XBMC.RunPlugin('+sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode=6&iconimage='+urllib.quote_plus(iconimage)+'&name='+urllib.quote_plus(pname)+')'))

               
                    else:
                        if xbmcvfs.exists(file + ".stopped") and xbmcvfs.exists(file):
                            urlx = common.ReadFile(file + ".stopped").replace("\r","").split("\n")
                            items.append((localizedString(10213).encode('utf-8') + ' : ' + pname, 'XBMC.RunPlugin({0}?url={1}&mode=7&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(pname))))
                            items.append((localizedString(10214).encode('utf-8') +' : ' + pname, 'XBMC.RunPlugin({0}?url={1}&mode=58&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(pname))))
                        elif xbmcvfs.exists(file + ".resume") and xbmcvfs.exists(file):
                            urlx = common.ReadFile(file + ".resume").replace("\r","").split("\n")
                            items.append((localizedString(10212).encode('utf-8') + ' : ' + pname, 'XBMC.RunPlugin({0}?url={1}&mode=57&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), urllib.quote_plus(iconimage), urllib.quote_plus(pname))))
                        else:
                            items.append(('Download : ' + pname, 'XBMC.RunPlugin('+sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode=7&iconimage='+urllib.quote_plus(iconimage)+'&name='+urllib.quote_plus(pname)+')'))

                        items.append(('Refresh', 'Container.Refresh'))
        elif ext == ".html" or url.find("plugin.video.youtube")>0 or url.find("plugin.video.dailymotion_com")>0:
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        urldec = ""

        if origurl.find("||film")>-1:
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        elif origurl.find("||serie")>-1:
            xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')  
        
        try:
            urldec = base64.decodestring(url)
            if common.check_url(urldec):
                url = urldec
        except:
            pass

        if url.find("Player=HLS")>0 or is_mp4(url):
            liz.addContextMenuItems(items, replaceItems=True)
        else:
            liz.addContextMenuItems(items)
    if mode == 20:        
        items = [('{0}'.format(localizedString(10120).encode('utf-8')) , 'XBMC.RunPlugin({0}?url={1}&mode=91)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))),  
                        ('{0}'.format(localizedString(10121).encode('utf-8')) , 'XBMC.RunPlugin({0}?url={1}&mode=92)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))) ]

        liz.addContextMenuItems(items , replaceItems=True)
        
    if mode == 30 or mode == 48 or mode == 49 or mode == 46 or mode == 34 or mode == 301 or mode == 302:
        liz.addContextMenuItems( [] , replaceItems=True)
    if mode == 64 or mode == 63 or mode == 93 or mode == 400:
        liz.setProperty( "Video", "false")
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "Year" : year, "Director" : director, "Writer" : writer, "Cast" : cast.split(","), "Country" : country, "Rating": rating, "Credit": credit})        
        
        xbmcplugin.setContent(int(sys.argv[1]), 'video')

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


def PM_index(r=True):
    
    if r:
        AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10250).encode('utf-8')), "search2" , 65, find, isFolder=True)
    
    AddDir("[COLOR cyan][B]{0}[/B][/COLOR]".format(localizedString(10001).encode('utf-8')), "settings" , 20, "http://findicons.com/files/icons/1331/matrix_rebooted/128/new_folder.png", isFolder=True)
    AddDir("[COLOR lightcyan][B]{0}[/B][/COLOR]".format(localizedString(10112).encode('utf-8')), DFolder , 60, "http://findicons.com/files/icons/1331/matrix_rebooted/128/drop_folder.png", isFolder=True)
    
    #if not LFolder == "":
    #    AddDir("[COLOR lightcyan][B]{0}[/B][/COLOR]".format(localizedString(10169).encode('utf-8')), LFolder , 60, "http://findicons.com/files/icons/1331/matrix_rebooted/128/library.png", isFolder=True)
    #if not LSFolder == "":
    #    AddDir("[COLOR lightcyan][B]{0}[/B][/COLOR]".format(localizedString(10172).encode('utf-8')), LSFolder , 60, "http://findicons.com/files/icons/1331/matrix_rebooted/128/library.png", isFolder=True)    
    
    listDir = common.ReadList(playlistsFile4)
    
    for fold in listDir:
        name = "[COLOR lightgreen][B]{0}[/B][/COLOR]".format(fold["name"].encode("utf-8"))
        
        t = ""
        try:
            t = fold["type"]
        except:
            pass
        
        if t == "xml":
            mode = 70
        elif t == "page":
            mode = 79
        elif t == "pyt":
            mode = 98
        else:
            mode = 21
        
        AddDir(name, fold["url"].encode("utf-8"), mode, "http://findicons.com/files/icons/1331/matrix_rebooted/128/generic_folder_alt.png", isFolder=True)       
        
    list = common.ReadList(playlistsFile2)
    for channel in list:
        if channel["url"].find("://")>0:
            color = "FF00c100"
        else:
            color = "green"
            
        name = "[COLOR " + color + "][B]" + channel["name"] + "[/B][/COLOR]"
        AddDir(name, channel["url"].encode("utf-8"), 4, "http://findicons.com/files/icons/1331/matrix_rebooted/128/text_clipping_file.png", isFolder=True)
        
def ChangeName(name, listFile, key, title):
    
    list = common.ReadList(listFile)
    
    if not listFile == favoritesFile:
        name = common.BBTagRemove(name)
    
    string = common.GetKeyboardText(localizedString(title), name)
    
    if len(string) < 1:
            return

    for channel in list:    
        if channel["url"] == url:
            channel["name"] = string
            break
        else:
            try:
                ure = base64.encodestring(url)
            except:
                ure = ""
            
            if channel["url"] == ure:
                channel["name"] = string
                break
                
    if common.SaveList(listFile, list):
            xbmc.executebuiltin("XBMC.Container.Refresh()")
		
def ChangeUrl(url, listFile, key, title):
        
    list = common.ReadList(listFile)
	
    if not common.check_url(url):
        string = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.m3u8|.m3u')
        if not string:
            return
    else:
        string = common.GetKeyboardText(localizedString(title), url)
            
    if len(string) < 1:
            return
    for channel in list:    
        if channel["url"] == url:
            channel["url"] = string
            break
    if common.SaveList(listFile, list):
            xbmc.executebuiltin("XBMC.Container.Refresh()")

def ChangeUrl2(url, listFile, key, title):
        
    list = common.ReadList(listFile)
    
    string = ""

    for channel in list:
        
        try:
            urldec = base64.decodestring(channel["url"])
        except:
            urldec = ""
            pass
        
        if channel["url"] == url or urldec == url:
            try: 
                ty = channel["type"]
            except:
                ty = ""
            
            if not common.check_url(url) and not ty=="pyt":
                
                if ty == "":
                    string = xbmcgui.Dialog().browse(int(3), localizedString(10041).encode('utf-8'), 'myprograms','', True)
                elif ty == "xml":
                    string = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.xml')
                if not string:
                    return
            else:
                string = common.GetKeyboardText(localizedString(title), channel["url"])
                    
            if len(string) < 1:
                    return
            
            channel["url"] = string
            break
    if common.SaveList(listFile, list):
            xbmc.executebuiltin("XBMC.Container.Refresh()")

def GetSourceLocation(title, list):
    
    dialog = xbmcgui.Dialog()
    answer = dialog.select(title, list)
    return answer
	
def AddFavorites(url, iconimage, name):
    
    favList = common.ReadList(favoritesFile)
    for item in favList:
        if item["url"] == url:
            xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
            return
        
    name = name.replace('\r','').replace('\n','').strip()
    url = url.replace('\n','').replace('\n','').strip()
    
    if common.check_url(url): 
        url = base64.encodestring(url)
    
    if not iconimage:
        iconimage = ""
    else:
        iconimage = iconimage.replace('\r','').replace('\n','').strip()
        
    data = {"url": url, "image": iconimage, "name": name }
    favList.append(data)
    common.SaveList(favoritesFile, favList)
    xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))
		
def ListFavorites():
    
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)

    list = common.ReadList(favoritesFile)
    EXTM = EXTV + EXTA
    
    for channel in list:
        name = channel["name"].encode("utf-8")
        iconimage = channel["image"].encode("utf-8")
        try: channel["url"] = base64.decodestring(channel["url"])
        except: pass
    
        if iconimage=="":
            iconimage = TVICO 
        ext = "." + channel["url"].split(".")[-1].strip()
        
        if bool(ext in EXTM) or is_mp4(channel["url"]) or channel["url"].endswith(".ts"):
            AddDir(name, channel["url"], 32, iconimage, isFolder=False)
        else:
            AddDir(name, channel["url"], 630, iconimage, isFolder=True)
        
def ListSub(lng):
    
    list = common.ReadList(lng)
    for item in list:
        mode =  2
        image = item.get('image', '')
        if not "http" in image:
                icon = os.path.join(addonDir, "resources", "images", image.encode("utf-8"))
        else:
                icon = image.encode("utf-8")
                
        try:
            name = int(item["name"])
            name = localizedString(name)
        except:
            name = item["name"]
                
        cname = "[COLOR gold][B]"+ name + "[/B][/COLOR]"
        AddDir(cname ,item["url"], mode , icon)

def ListTB(lg):
    
    ok = show_main(lg)

def RemoveFavorties(url):
    
    list = common.ReadList(favoritesFile) 

    for channel in list:
        
        try: channel["url"] = base64.decodestring(channel["url"])
        except: pass        
        
        if channel["url"].lower() == url.lower():
            list.remove(channel)
            break
	
    common.SaveList(favoritesFile, list)
    xbmc.executebuiltin("XBMC.Container.Refresh()")

def AddNewFavortie():
    
    chName = common.GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
    if len(chName) < 1:
            return
    chUrl = common.GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
    if len(chUrl) < 1:
            return
		
    favList = common.ReadList(favoritesFile)
    
    for item in favList:
            
        try: item["url"] = base64.decodestring(item["url"])
        except: pass
    
        if item["url"].lower() == url.lower():
                xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
                return
			
    data = {"url": base64.encodestring(chUrl), "image": "", "name": chName.decode("utf-8")}
    favList.append(data)
    if common.SaveList(favoritesFile, favList):
            xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))

############################################################################################
#    Modulo ricerca    

def sch_channels_it(string,live=False):
    #0 - search in italian channels
    sch_m3u(os.path.join(chanDir, "it.txt"),string,localizedString(10052).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "vpnit.txt"),string,localizedString(10051).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "w_it.txt"),string,localizedString(10055).encode('utf-8'),live=live)    
    sch_m3u(os.path.join(chanDir, "rsi.txt"),string,localizedString(10053).encode('utf-8'),live=live)
    if live==False:
        sch_m3u(os.path.join(chanDir, "regionali.txt"),string,localizedString(10050).encode('utf-8'),live=live)
        sch_m3u(os.path.join(chanDir, "radioit.txt"),string,localizedString(10070).encode('utf-8'),live=live)

def sch_index(string,live=False):
    sch_channels_it(string,live=live)
    # french
    sch_m3u(os.path.join(chanDir, "fr.txt"),string,localizedString(10058).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "radiofr.txt"),string,localizedString(10071).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "vpnfr.txt"),string,"VPN/IP FR",live=live)
    sch_m3u(os.path.join(chanDir, "rts.txt"),string,"RTS.ch",live=live)
    sch_m3u(os.path.join(chanDir, "w_fr.txt"),string,localizedString(10055).encode('utf-8'),live=live)
    # german
    sch_m3u(os.path.join(chanDir, "de.txt"),string,localizedString(10022).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "radiode.txt"),string,localizedString(10072).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "srf.txt"),string,"SRF.ch",live=live)
    sch_m3u(os.path.join(chanDir, "vpnat.txt"),string,localizedString(10060).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "w_de.txt"),string,localizedString(10055).encode('utf-8'),live=live)
    # english
    sch_m3u(os.path.join(chanDir, "en.txt"),string,localizedString(10057).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "radioen.txt"),string,localizedString(10073).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "bbc_radio.txt"),string,localizedString(10074).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "vpnuk.txt"),string,localizedString(10059).encode('utf-8'),live=live)
    sch_m3u(os.path.join(chanDir, "w_en.txt"),string,localizedString(10055).encode('utf-8'),live=live)
    # music
    sch_m3u(os.path.join(chanDir, "mu.txt"),string,localizedString(10028).encode('utf-8'),live=live)
    
def sch_global_PM(string,live=False):
    
    # 1 - search in download folder 
    PMFolder(DFolder,string,live=live)
    
    # 2 - search in m3ulist-index
    list = common.ReadList(playlistsFile2)
    for channel in list:
        url = channel["url"]
        sname = common.BBTagRemove(channel["name"]).replace("_"," ").replace("%20"," ").lower()
        sch_m3u(url,string,sname,live=live)

    # 3 - search in folder/xml-index
    listDir = common.ReadList(playlistsFile4)
    
    for fold in listDir:
        name = fold["name"]

        try:
            t = fold["type"]
        except:
            t = ""
        try:
            e = fold["exclude"]
        except:
            e = ""
        
        if e == "":
            if t == "xml":
                OpenXML(fold["url"],string,live=live)
            elif t == "pyt":
                Yplayl(fold["url"],string,live=live)
            elif t == "page":
                findm3u(fold["url"],string,live=live)
            else:
                PMFolder(fold["url"],string,live=live)

def sch_global(string,live=False):
    sch_index(string,live=live)
    sch_global_PM(string,live=live)
    
def sch_filmtvit(string,live=True):
    sch_channels_it(string,live=live)
    sch_global_PM(string,live=live)

        
def sch_folder(url,string):
    string = string.lower()
    PMFolder(url,string)

def sch_xml(url,string):
    string = string.lower()
    OpenXML(url,string)

def sch_m3u(url,string,sname,live=False):

    try:
        urldec = base64.decodestring(url)
        if common.check_url(urldec):
            url = urldec
    except:
        pass

    list = common.cachelist(url,cdir)
    EXT = EXTV + EXTA
    for channel in list:
        name = channel["display_name"]
        name = common.BBTagRemove(name) 
        Name = name
        name = name.replace("_"," ").lower().strip()
        url = channel["url"].strip()
        ext = "." + url.split(".")[-1].strip()
        #EXT = EXTV + EXTA
        
        if not bool(ext in EXT) or not live:
        
            if name.find(string)>-1:
                if channel.get("tvg_logo", ""):
                    if common.check_url(channel.get("tvg_logo", "")):
                        iconname = channel.get("tvg_logo", "")
                    else:
                        logo = channel.get("tvg_logo", "")
                        iconname = "https://kodilive.github.io/logo/" + logo
                else :
                    iconname = TVICO

                listName = "  " + "[CR][I][COLOR cyan][LIGHT]* {0}[/COLOR]".format(localizedString(10004).encode('utf-8')) + " -->  [COLOR yellow]{0}[/COLOR][/I][/LIGHT]".format(sname)
                cname = "[COLOR orange][B]{0}[/B][/COLOR]".format(Name) + listName
                if live or not bool(ext in EXT):
                    FastDir(cname,url,3,iconname,res=True,isFolder=False)
                else:
                    AddDir(cname,url,3,iconname,isFolder=False)

def sch_exclude(url, listFile, key):
    
    list = common.ReadList(listFile)

    for channel in list:    
        if channel["url"].lower() == url.lower():
            channel["exclude"] = key
            break
        else:
            try:
                ure = base64.b64encode(url)
            except:
                ure = ""
            
            if channel["url"] == ure:
                channel["exclude"] = key
                break
            
    if common.SaveList(listFile, list):
        xbmc.executebuiltin("XBMC.Container.Refresh()")

##########################
# Specials Channels

def getIpBoxList(string="",live=False):
    ret=[]
    try:
        servers=common.cachepage("http://pastebin.com/raw/GrYKMHrF",3650)
        servers=servers.splitlines()

        import time
        for ln in servers:
            if not ln.startswith("##") and len(ln)>0:
                try:
                    print 'ln',ln
                    servername,surl=ln.split('$')
                    
                    if not servername.startswith("---"):
                        if '[gettext]' in surl:
                            surl,fileheaders,playheaders=surl.split('|')
                            surl = common.cachepage(surl.replace('[gettext]',''),3600)
                            if ' ' in surl or '>' in surl:
                                surl=surl.replace(' ','%20')
                                surl=surl.replace('>','%3E')
                                surl=surl.replace('<','%3C')
                            
                            try:
                                playheaders = playheaders.split("=")[1]
                                surl = surl + "|User-Agent=" + common.OpenURL(playheaders)
                            except:
                                pass
                            
                        if string == "":
                            typ = "- [COLOR yellow][mpeg][/COLOR]"
                            if surl.find("output=hls")>-1:
                                typ = "- [COLOR cyan][hls][/COLOR]"
                                
                            AddDir("[B][COLOR green]" + servername + " List[/COLOR][/B] " + typ, surl, 51, iconlist, isFolder=True)
                        else:
                            sch_m3u(surl,string,servername,live=live)
                        
                except: traceback.print_exc(file=sys.stdout)
    except:
        traceback.print_exc(file=sys.stdout)

##########################
# Youtube Playlist

def yload_more(prew):
    
    if common.find_param('data-uix-load-more-href="([^",]+)',prew):
        url = "https://www.youtube.com" + common.find_param('data-uix-load-more-href="([^",]+)',prew) 
        data = common.cachepage(url,125000,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
        data = data.replace("\\","").replace("u0026#39;","'").replace("u0026amp;","&")
        return data
    else:
        return ""

def Yplayl(url,string="",live=False):
    if url.find("dm://")>-1:
        url = url.replace("dm://","")
        Daiplayl(url,string,live)
    elif url.find('jp://')>-1:
        url = url.replace("jp://","")
        jwplatform(url,string,live)
    else:
        youdir = os.path.join(xbmc.translatePath("special://home/addons/"),'plugin.video.youtube','')
        if not xbmcvfs.exists(youdir):
            if string == "":
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("For this feature you need to install","[B][COLOR violet]Youtube video plugin[/COLOR][/B]", 6800, icon))
        else:
            
            if not string == "":
                listName = "  " + "[CR][I][COLOR cyan][LIGHT]Youtube-Playlist[/COLOR] -->  [COLOR yellow]{0}[/COLOR][/I][/LIGHT]".format(url)

            url1 = "https://www.youtube.com/playlist?list=" + url    
            data = common.cachepage(url1,125000,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
            
            a = 0
            while a < 1:
                
                if yload_more(data):
                    data = data.replace("data-uix-load-more-href=","") + yload_more(data)
                else:
                    a = 1
                    break

            patron = 'data-title="([^"]+)(.*?)data-thumb="([^"]+)(.*?)data-video-ids="([^"]+)'
            matches = re.compile(patron, re.DOTALL).findall(data)
            
            xml = "<data>\r\t<type name=\"channels\">\r"
            
            for scrapedtitle, sep, thumb, sep2, scrapedvid in matches:
                scrapedtitle = common.decodeHtmlentities(scrapedtitle).strip()
                if not thumb.find("no_thumbnail")>-1:
                    xml = xml + "\t\t<item>\r"
                    xml = xml + "\t\t\t<name>" + scrapedtitle + "</name>\r"
                    titolo = "[COLOR violet]" + scrapedtitle + "[/COLOR]"
                    xml = xml + "\t\t\t<icon>violet</icon>\r"
                    url = "plugin://plugin.video.youtube/play/?video_id=" + scrapedvid
                    xbmc.log("*** Item Youtube url: " + url,xbmc.LOGNOTICE)
                    xml = xml + "\t\t\t<link>" + url + "</link>\r"
                    img = "https://i.ytimg.com/vi/" + scrapedvid + "/hqdefault.jpg"
                    xml = xml + "\t\t\t<icon>" + img + "</icon>\r"
                    fanart = "https://i.ytimg.com/vi/" + scrapedvid + "/maxresdefault.jpg"        
                    xml = xml + "\t\t\t<fanart>" + fanart + "</fanart>\r"
                    xml = xml + "\t\t\t<description></description>\r"
                    
                    if string == "":
                        AddDir(titolo,url,3,img,background=fanart,isFolder=False)
                    else:
                        sname = scrapedtitle.replace("_"," ").replace("%20"," ").lower()
                        if sname.find(string)>-1:
                            titolo = "[COLOR orangered]" + scrapedtitle + "[/COLOR]" + listName
                            AddDir(titolo,url,3,img,background=fanart,isFolder=False)
                    xml = xml + "\t\t</item>\r"        
            if string == "":  
                xml = xml + "\t</type>\r</data>"      
                common.mywrite(xml,'myutlist_')           
            
##########################
# Dailymotion Playlist

def Daiplayl(url,string="",live=False):
    
    id = url
    
    if not string == "":
        listName = "  " + "[CR][I][COLOR cyan][LIGHT]Dailymotion-Playlist[/COLOR] -->  [COLOR yellow]{0}[/COLOR][/I][/LIGHT]".format(url)
    
    url = "https://api.dailymotion.com/playlist/" + id + "?fields=description,name,thumbnail_url,videos_total,"    
    data = common.cachepage(url,125000,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})    

    try:
        totv = int(common.find_param('"videos_total":([^,]+)(.*?)}',data))    
    except:
        totv = 100
        #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,"Error: video url no found!".encode('utf-8'), 3900, icon))
        #sys.exit()    
    
    #thumb = common.find_param('"thumbnail_url": ([^,]+)(.*?)}',data)
    pgn = totv/100
    import math
    #xbmc.log("##### Number of item = " + str(totv),xbmc.LOGNOTICE) 
    pgn = int(pgn)+1
    #xbmc.log("##### Number of pages = " + str(pgn),xbmc.LOGNOTICE) 
    cic = range(1,pgn+1)
    for count in cic:
        url = "https://api.dailymotion.com/playlist/" + id + "/videos?fields=id,thumbnail_1080_url,thumbnail_480_url,title,&sort=recent&page=" + str(count) + "&limit=100" 
        
        xbmc.log("##### DM api url = " + url,xbmc.LOGNOTICE) 
        
        data = common.cachepage(url,110000,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
        data = data.decode('unicode_escape').encode('iso-8859-1').replace("\/","/")
        patron = 'id":"([^"]+)(.*?)"thumbnail_1080_url":"([^"]+)(.*?)"thumbnail_480_url":"([^"]+)(.*?)"title":"([^"]+)'
        matches = re.compile(patron, re.DOTALL).findall(data)     
        
        for scrapedvid, sep1, fanart, sep2, img, sep3, scrapedtitle in matches:
            
            scrapedtitle = common.decodeHtmlentities(scrapedtitle).replace("_"," - ").strip()
            titolo = "[COLOR violet]" + scrapedtitle + "[/COLOR]"
            url = "plugin://plugin.video.dailymotion_com/?url=" + scrapedvid +"&mode=playVideo"
            if string == "":
                AddDir(titolo,url,3,img,background=fanart,isFolder=False)            
            else:
                sname = scrapedtitle.replace("_"," ").replace("%20"," ").lower()
                if sname.find(string)>-1:
                    titolo = "[COLOR orangered]" + scrapedtitle + "[/COLOR]" + listName
                    AddDir(titolo,url,3,img,background=fanart,isFolder=False)            
            
#################################

def jwplatform(url,string="",live=False):
    
    id = url

    if not string == "":
        listName = "  " + "[CR][I][COLOR cyan][LIGHT]Playlist[/COLOR] -->  [COLOR yellow]{0}[/COLOR][/I][/LIGHT]".format(url)
    
    url = "http://content.jwplatform.com/v2/playlists/" + id
    data = common.cachepage(url,70000,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'}) 
    patron = 'title":"([^"]+)(.*?)"image":"([^"]+)(.*?)"file":"([^"]+)(.*?)"link":"([^"]+)'
    matches = re.compile(patron, re.DOTALL).findall(data)     
    
    xml = "<data>\r\t<type name=\"channels\">\r"    
    
    for title, sep, img, sep, url, sep, purl in matches:
        
        title = re.sub("@streamtime","", title, flags=re.IGNORECASE)
        title = re.sub("@steamtime","", title, flags=re.IGNORECASE)
        title = re.sub("webrip","", title, flags=re.IGNORECASE)
        title = re.sub("webmux","", title, flags=re.IGNORECASE)
        title = re.sub("webdl","", title, flags=re.IGNORECASE)
        title = re.sub("bdrip","", title, flags=re.IGNORECASE)
        title = re.sub("hdtvmux","", title, flags=re.IGNORECASE)
        title = re.sub("bdmux","", title, flags=re.IGNORECASE)
        title = title.replace(" S0"," - S0")
        title = title.replace(" S1"," - S1")
        title = title.replace(" E0"," - E0")
        title = title.replace(" E1"," - E1")
        title = title.replace(" E2"," - E2")
        title = title.replace("480p","").replace("720p","").replace("1080p","")
        title = title.replace("H264","").strip()
        xml = xml + "\t\t<item>\r"
        xml = xml + "\t\t\t<name>" + title + "</name>\r"        
        title = "[COLOR violet]" + title + "[/COLOR]"
        xml = xml + "\t\t\t<color>violet</color>\r"
        xml = xml + "\t\t\t<link>" + purl + "</link>\r"
        xml = xml + "\t\t\t<icon>" + img + "</icon>\r"
        xml = xml + "\t\t\t<fanart></fanart>\r"
        xml = xml + "\t\t\t<description></description>\r"
        xml = xml + "\t\t</item>\r"
        if string == "":
            AddDir(title,url,3,img,background="",isFolder=False) 

        else:
            sname = title.replace("_"," ").replace("%20"," ").lower()
            if sname.find(string)>-1:
                titolo = "[COLOR orangered]" + title + "[/COLOR]" + listName
                AddDir(titolo,url,3,img,background="",isFolder=False) 
    
    if string == "":
        xml = xml + "\t</type>\r</data>"
        common.mywrite(xml,'myjwlist_')  

##########################
# Luci Rosse  
def sexy_one(url):
    import random
    rnd1 = str(random.randint(100,500))
    rnd2 = str(random.randint(10,99))    
    if url == "index":    
        urlbase = "https://hqporner.com/categories"
        
        data = common.cachepage(urlbase,1296001,headers={'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0 rnd: ' + rnd1 + '.' + rnd2 })
        patron = 'class="3u">(.*?) href="([^"]+)(.*?)<img src="([^"]+)(.*?)class="click-trigger">(.*?)</a>'
        matches = re.compile(patron, re.DOTALL).findall(data)

        FastDir("[COLOR yellow]Most Viewed[/COLOR]","https://hqporner.com/top",77,"https://hqporner.com/images/porn-categories/hegre-art.jpg",fanart="", isFolder=True)
        FastDir("[COLOR yellow]Fucked Hard[/COLOR]","https://hqporner.com/studio/fucked-hard",77,"https://hqporner.com/images/porn-categories/fucked-hard.jpg",fanart="", isFolder=True)
        
        for sp1, cat, sp2, img, sp3, title in matches:
            
            url = "https://hqporner.com" + cat
            titolo = "[COLOR lightgreen] " + title + "[/COLOR]"
            icon = "https://hqporner.com" + img
            
            if url.find("?s=")>-1:
                url = "https://hqporner.com/category/1080p-porn"
                
            FastDir(titolo,url,77,icon,fanart="", isFolder=True)
    else:
        data = common.OpenURL(url,headers={'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0 rnd: ' + rnd1 + '.' + rnd2,'Referer':'https://hqporner.com' })
        urlx = url
        count = 0
        
        #FastDir("[B]<< Back Home[/B]","index",76,"https://d2118lkw40i39g.cloudfront.net/wp-content/uploads/2018/03/home-.jpg",fanart="", isFolder=True)
        
        patron = '//hqporner.com/imgs/([^"]+)(.*?)class="meta-data-title"><a href="([^"]+)(.*?)class="click-trigger">(.*?)</a></h3>'
        matches = re.compile(patron, re.DOTALL).findall(data)
        for img, sp1, page, sp2, title in matches:

            url = "https://hqporner.com" + page
            titolo = "[COLOR lightgreen] " + title + "[/COLOR]"
            icon = "https://hqporner.com/imgs/" + img
            #xbmc.log('**** Sexy One url = ' + url, xbmc.LOGNOTICE)
            count = count + 1
            AddDir(titolo,url,3,icon,background=icon, isFolder=False)
        
        if count == 50:
            if urlx.find("https://hqporner.com/category")>-1:
                p = urlx.replace("https://hqporner.com/category/","")
                c = "category/"
            
            elif urlx.find("https://hqporner.com/top")>-1:
                p = urlx.replace("https://hqporner.com/top/","")
                p = urlx.replace("https://hqporner.com/top","")
                c = "top"
            
            try:
                page = p.split("/")[1]
            except:
                page = ""
                #xbmc.log('**** page URLx = ' + url, xbmc.LOGNOTICE)
                
            if len(page)>0:
                np = str(int(page)+1)
                url = "https://hqporner.com/" + c + p.split("/")[0] + "/" + np
                #xbmc.log('**** page URL = ' + url, xbmc.LOGNOTICE)
            else:
                np = "2"
                url = urlx + "/2"
            
            FastDir("[B]PAGE >> " + np + "[/B]",url,77,"https://www.lazerhorse.org/wp-content/uploads/2013/05/NEXT-PAGE.jpg",fanart="", isFolder=True)

##########################
# Oggi in TV

def tvoggi(url):
    
    urlbase = "http://www.comingsoon.it/filmtv"

    data = common.OpenURL(urlbase + url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
    
    patron = '<div class="col-xs-5 box-immagine">[^<]+<img src="([^"]+)[^<]+<[^<]+<[^<]+<[^<]+<[^<]+<.*?titolo">(.*?)</div>[^<]+<div class="h5 ora-e-canale">[^<]+<span>(.*?)</span><br />(.*?)<[^<]+</div>'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedthumbnail, scrapedtitle, scrapetime, scrapedtv in matches:

        scrapedtitle = common.decodeHtmlentities(scrapedtitle).strip()
        titolo = scrapetime + " : [COLOR gold] " + scrapedtitle + "[/COLOR] - [COLOR orange] " + scrapedtv + "[/COLOR]"
        url = scrapedtv.lower() 
        url = url.replace("la2","la 2").replace("la1","la 1")
        
        FastDir(titolo,url,73,icon=scrapedthumbnail,fanart="http://www.ore12.net/wp-content/uploads/2016/08/cinema.jpg")

       
def SetteGiorniTV(day=""):
    if day == "":
        import datetime
        from datetime import date, timedelta
        start = date.today()
        icon = ""
        
        Link = ["/","/domani/","/dopodomani/","/giorno-3/","/giorno-4/","/giorno-5/","/giorno-6/"]
        Days = ["Oggi","Domani","Dopodomani","Fra 3 giorni","Fra 4 giorni","Fra 5 giorni","Fra 6 giorni"]
        
        AddDir("[COLOR gold][B]" + str(date.today()) + " - Film in TV " + Days[0] + "[/B][/COLOR]", Link[0], 75, icon, isFolder=True)
        for add in range(1, 7):
            future = start + timedelta(days=add)
            AddDir("[COLOR gold][B]" + str(future) + " - Film in TV " + Days[add] + "[/B][/COLOR]", Link[add], 75, icon, isFolder=True)
    else:
        if day == "/":
            AddDir("[COLOR red][B]ORA IN ONDA[/B][/COLOR]", day, 74, "http://a2.mzstatic.com/eu/r30/Purple/v4/3d/63/6b/3d636b8d-0001-dc5c-a0b0-42bdf738b1b4/icon_256.png", isFolder=True) 
        AddDir("[COLOR azure][B]Mattina[/B][/COLOR]", day + "?range=mt", 74, "http://www.creattor.com/files/23/787/morning-pleasure-icons-screenshots-17.png", isFolder=True)
        AddDir("[COLOR azure][B]Pomeriggio[/B][/COLOR]", day + "?range=pm", 74, "http://icons.iconarchive.com/icons/custom-icon-design/weather/256/Sunny-icon.png", isFolder=True)
        AddDir("[COLOR azure][B]Preserale[/B][/COLOR]", day + "?range=pr", 74, "https://s.evbuc.com/https_proxy?url=http%3A%2F%2Ftriumphbar.com%2Fimages%2Fhappyhour_icon.png&sig=ADR2i7_K2FSfbQ6b3dy12Xjgkq9NCEdkKg", isFolder=True)
        AddDir("[COLOR azure][B]Prima serata[/B][/COLOR]", day + "?range=ps", 74, "http://icons.iconarchive.com/icons/icons-land/vista-people/256/Occupations-Pizza-Deliveryman-Male-Light-icon.png", isFolder=True)
        AddDir("[COLOR azure][B]Seconda serata[/B][/COLOR]", day + "?range=ss", 74, "http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png", isFolder=True)
        AddDir("[COLOR azure][B]Notte[/B][/COLOR]", day + "?range=nt", 74, "http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/256/Status-weather-clear-night-icon.png", isFolder=True)
        
################################################################################################
# Ricerca aggiornamenti 

def checkforupdates(url,loc,aut):

    xbmc.log('Start check for updates',xbmc.LOGNOTICE)
    try:
        data = urllib2.urlopen(url).read()
        #xbmc.log('read xml remote data:' + data,xbmc.LOGNOTICE)
    except:
        data = ""
        xbmc.log('fail read xml remote data:' + url, xbmc.LOGNOTICE)
    try:
        f = open(loc,'r')
        data2 = f.read().replace("\n\n", "")
        f.close()
        #xbmc.log('read xml local data:' + data2, xbmc.LOGNOTICE)
    except:
        data2 = ""
        xbmc.log('fail read xml local data', xbmc.LOGNOTICE)

    version_publicada = common.find_single_match(data,"<version>([^<]+)</version>").strip()
    tag_publicada = common.find_single_match(data,"<tag>([^<]+)</tag>").strip()

    version_local = common.find_single_match(data2,"<version>([^<]+)</version>").strip()
    tag_local = common.find_single_match(data,"<tag>([^<]+)</tag>").strip()

    try:
        numero_version_publicada = int(version_publicada)
        xbmc.log('number remote version:' + version_publicada, xbmc.LOGNOTICE)
        numero_version_local = int(version_local)
        xbmc.log('number local version:' + version_local, xbmc.LOGNOTICE)
    except:
        version_publicada = ""
        xbmc.log('number local version:' + version_local, xbmc.LOGNOTICE)
        xbmc.log('Check fail !@*', xbmc.LOGNOTICE)
            
    if version_publicada!="" and version_local!="":
        if (numero_version_publicada > numero_version_local):

            extpath = os.path.join(xbmc.translatePath("special://home/addons/")) 
            dest = addon_data_dir + '/lastupdate.zip'                
            UPDATE_URL = 'https://github.com/vania70/Kodi-Live-TV/raw/master/plugin.video.kodilivetv-' + tag_publicada + '.zip'
            xbmc.log('START DOWNLOAD UPDATE:' + UPDATE_URL, xbmc.LOGNOTICE)
                
            DownloaderClass(UPDATE_URL,dest)  
            
            xbmc.executebuiltin("XBMC.Extract("+dest+","+extpath+")")
                
            line7 = 'New version installed .....'
            line8 = 'Version: ' + tag_publicada 
            xbmcgui.Dialog().ok('Kodi Live TV', line7, line8)
                
            if os.remove( dest ):
                xbmc.log('TEMPORARY ZIP REMOVED', xbmc.LOGNOTICE)
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            xbmc.sleep(1500)

    url = REMOTE_VERSION_FILE2
    loc = LOCAL_VERSION_FILE2
        
    try:
        data = urllib2.urlopen(url).read()
        #xbmc.log('read xml remote data:' + data, xbmc.LOGNOTICE)
    except:
        data = ""
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,"Check for updates fail !", 3600, icon))
        xbmc.log('fail read xml remote data:' + url, xbmc.LOGNOTICE)
    try:
        f = open(loc,'r')
        data2 = f.read().replace("\n\n", "")
        f.close()
        #xbmc.log('read xml local data:' + data2, xbmc.LOGNOTICE)
    except:
        data2 = ""
        xbmc.log('fail read xml local data', xbmc.LOGNOTICE)
            
    version_publicada = common.find_single_match(data,"<version>([^<]+)</version>").strip()
    tag_publicada = common.find_single_match(data,"<tag>([^<]+)</tag>").strip()

    version_local = common.find_single_match(data2,"<version>([^<]+)</version>").strip()
    dinamic_url = common.find_single_match(data,"<url>([^<]+)</url>").strip()
        
    try:
        numero_version_publicada = int(version_publicada)
        xbmc.log('number remote version:' + version_publicada, xbmc.LOGNOTICE)
        numero_version_local = int(version_local)
        xbmc.log('number local version:' + version_local, xbmc.LOGNOTICE)
    except:
        version_publicada = ""
        xbmc.log('number local version:' + version_local, xbmc.LOGNOTICE)
        xbmc.log('Check fail !@*', xbmc.LOGNOTICE)
        u = True
            
    if version_publicada!="" and version_local!="":
        if (numero_version_publicada > numero_version_local):

            extpath = os.path.join(xbmc.translatePath("special://home/addons/")) 
            dest = addon_data_dir + '/temp.zip'  
            
            xbmc.log('START DOWNLOAD PATCH : ' + dinamic_url, xbmc.LOGNOTICE)         
            urllib.urlretrieve(dinamic_url,dest)
            xbmc.sleep ( 150 )
            
            xbmc.executebuiltin("XBMC.Extract("+dest+","+extpath+")")
            
            xbmc.log('EXTRACT PATCH ' + version_publicada, xbmc.LOGNOTICE) 
            
            line7 = 'Plugin data updated .....'
            line8 = 'Description: ' + tag_publicada
            xbmcgui.Dialog().ok('Kodi Live TV', line7, line8)
                    
            if os.remove( dest ): 
                xbmc.log('TEMPORARY ZIP REMOVED', xbmc.LOGNOTICE)
            xbmc.sleep(1200)
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            #u = False
        else:
            xbmc.sleep ( 150 )
            if aut>-1:
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(localizedString(10106).encode('utf-8') + " :",localizedString(10044).encode('utf-8'), 4000, icon))
                xbmc.log('Check updates:No updates are available', xbmc.LOGNOTICE)

# Ricerca automatica aggiornamenti
Tfile = os.path.join(addon_data_dir, 'time.txt')

if Addon.getSetting('autoupdate') == "true":

    if os.path.isfile(Tfile):
        t = time.time() - os.path.getmtime(Tfile)
        if t > 1680:
            try:
                checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,t-43200)
            except:
                pass
            common.write_file(Tfile  , '*')
    else:
        try:
            checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,0)
        except:
            pass
        common.write_file(Tfile  , '*')

###################

def ytdl_extract(url):
    from youtube_dl import YoutubeDL
    ytdl = YoutubeDL()
    info = ytdl.extract_info(url, download=False)
    return info[url]

###################

def mediaplay(id):
    sys.path.insert(0, libDir)
    from mediaset import mediaset
    #from resources.lib.mediaset import mediaset
    url = mediaset().getLiveChannelUrl(id)
    return url

###################

def Play_f4mProxy(url, name, iconimage):
    
    maxbitrate = "0"
    simpledownloader = False
    sys.path.insert(0, f4mProxy)
    from F4mProxy import f4mProxyHelper
    player=f4mProxyHelper()
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
    
    if streamtype == "HLS":
        maxbitrate = 9000000
    player.playF4mLink(url, name, None, True, maxbitrate, simpledownloader, None, streamtype, False, None, None, None, iconimage)    
    
####################

#xbmc.log('SYS *** ' + sys.argv[2], xbmc.LOGNOTICE)

def get_params():
    
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
                params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
                splitparams = {}
                splitparams = pairsofparams[i].split('=')
                if (len(splitparams)) == 2:
                        param[splitparams[0].lower()] = splitparams[1]
    return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
station = None
user_id = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"]).encode('utf-8')
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    user_id = params["userid"]
except:
    pass
try:        
    rec_id = params["recid"]
except:
    pass    
try:        
    station = urllib.unquote_plus(params["station"])
except:
    pass    
    
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:
    streamtype = urllib.unquote_plus(params["streamtype"])
except:
    pass    

if url and url.find("l=chit") >= 0:
    from teleboy import *
    ListTB("it")
    url = None
elif url and url.find("l=chfr") >= 0:
    from teleboy import *
    ListTB("fr")
    url = None
elif url and url.find("l=chde") >= 0:
    from teleboy import *
    ListTB("de")
    url = None
elif url and url.find("l=chen") >= 0:
    from teleboy import *
    ListTB("en")
    url = None
elif url and url.find("l=oggitv") >= 0:
    SetteGiorniTV()
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)
    sys.exit() 
   
elif url and url.find("l=pornazzi") >= 0:
    sexy_one("index")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)
    sys.exit()     

if mode == None or url == None or len(url) < 1:
    Categories()
elif mode == 96:
    Channels()
elif mode == 97:
    Others()    
elif mode == 1:
    xml_settings = os.path.join(addon_data_dir, "settings.xml")
    if os.path.isfile(xml_settings):
        os.remove(xml_settings)
        sys.exit()
elif mode == 2:
    m3uCategory(url)
elif mode == 4 or mode == 51:
    m3uCategory(url,False)
elif mode == 63 or mode == 463 or mode == 464 or mode == 70 or mode == 630:
    if url.find("&squery=")>0:
        
        urls = url.split("&squery=")
        urlb = urls[1].split("&sid=")
        #urls[1] = urls[1].replace("&sid=","")
        #xbmc.log('urls[1] ' + urls[1], xbmc.LOGNOTICE)
        if not urlb[0] == "":
            OpenXML(url)
        else:
            string = common.GetKeyboardText("Inserisci parola da cercare", "")
            if len(string) >0:
                url = url.replace("&squery=","&squery="+urllib.quote_plus(string.replace(" ","_").encode("utf-8")) )
                OpenXML(url)
            else:
                #OpenXML(url.split("?")[0])
                sys.exit()
    else:
        OpenXML(url)
    
elif mode == 3 or mode == 32:
    url = url.strip()
    if url.find("&t=")>0 and url.find(".xml")>0 and url.find("php?c=")>0:   
        url = url.replace("+%5BHD-4K%5D.xml&",".xml&")
        url = common.OpenURL(url).strip()
            
    if url.find("://hqporner.com")>-1:
        url = common.get_mydaddy_video(url)
    
    if url.find("://")>-1 and not url.find("|User-Agent=")>-1:
    
        link = url.split(" ")
        option = [ ]
        iu = [ ]
        trailer=0
        count = 0
        
        if len(link) > 1:
            for i in link:

                count = count + 1
                if i.find("?key=")>-1:
                    base_url = "freevideo.com"
                elif i.find("media.graph")>-1: 
                    base_url = "cloudvideo.net"
                else:
                    base_url = i.split("//")[-1].split("/")[0].split('?')[0].replace("plugin.video.","")
                
                try: 
                    find = re.search('/\[(.+)p\]$',i).group(1)
                    fi = "[" + find.replace("_"," ") +"p]"
                    iu.append(i.replace("/[" + find +"p]",""))
                except: 
                    iu.append(i)
                    fi = ""
                if base_url == "script.extendedinfo":
                    option.append("Guarda la scheda informazioni")
                    trailer=1
                else:
                    if fi:
                        fi = " " + fi + " - "
                    else:
                        fi = " "

                    option.append(str(count) + " : " + fi + " from " + base_url)
            
            if trailer == 1:
                option[0] = "PLAY Trailer"
            
            index = xbmcgui.Dialog().select(common.BBTagRemove(name), list=option)
            if index > -1:
                url = iu[index]
            else:
                sys.exit()
        else:
            try:
                find = re.search('/\[(.+)p\]$',url).group(1)
                url = url.replace("/[" + find +"p]","")
            except:
                pass

    if url.find("script.extendedinfo")>-1 or (url.find("plugin.video.youtube")>-1 and trailer==1):
        
        xbmc.executebuiltin('RunPlugin('+url+')')
    
    else:
        if url.startswith("enc"):
            PlayUrl(name, url, iconimage)
            
        elif url.startswith("mplay:"):
            id = url.replace("mplay:","")
            url = mediaplay(id)
            PlayUrl(name, url, iconimage)
            
        elif url.startswith("dm://"):
            id = url.replace("dm://","")
            url = "plugin://plugin.video.dailymotion_com/?url=" + id +"&mode=playVideo"
            PlayUrl(name, url, iconimage)

        elif url.startswith("yte://"): 
            url = url.replace("yte://","")
            url = ytdl_extract(url)
            PlayUrl(name, url, iconimage)
        else:
            if not url.endswith("Player=HLS") and not url.find("|User-Agent=")>-1:
                url = common.unshortenit(url)
                url = common.urlresolve(url)
            PlayUrl(name, url, iconimage)


elif mode == 6 or mode == 7:
    url = url.strip()
    
    if url.find("://hqporner.com")>-1:
        url = common.get_mydaddy_video(url)
        
    if url.find("://")>-1:
    
        link = url.split(" ")
        a = 1
        option = [ ]
        iu = [ ]
        mfi = [ ]
        dim = ""
        res = ""
        
        if len(link) == 1:
            ext = "." + url.split('.')[-1]
            if not ext in EXTV:
                ext = ".mp4"
            file = DFolder + name + ext
    
            fileS = file + ".stopped"
            fileR = file + ".resume"
            
            if xbmcvfs.exists(fileS):
                res = "yes"
        
        if len(link)> 0 and res == "":
            
            count = 0
            
            for i in link:
                
                count = count + 1
                if i.find("?key=")>-1:
                    base_url = "freevideo.com"
                elif i.find("media.graph")>-1: 
                    base_url = "cloudvideo.net"
                else:
                    base_url = i.split("//")[-1].split("/")[0].split('?')[0].replace("plugin.video.","")
                
                extm = "." + i.split('.')[-1]
                
                if not extm.find("m3u8")>-1 and not i.find("//supervideo.tv")>0:
                    try:
                        find = re.search('/\[(.+)p\]$',i).group(1)
                        fi = "[" + find.replace("_"," ") +"p]"
                        iu.append(i.replace("/[" + find +"p]",""))
                        mfi.append(fi)
                    except: 
                        iu.append(i)
                        fi = ""
                        mfi.append("")
                    
                    if fi:
                        fi = " " + fi + " - "
                    else:
                        fi = " "

                    option.append(str(count) + " : " + fi + " from " + base_url)
                    
            index = xbmcgui.Dialog().select("Download : " + common.BBTagRemove(name), list=option)  
            if index > -1:
                url = iu[index]
                dim = mfi[index]
            else:
                sys.exit()
        else:
            try:
                find = re.search('/\[(.+)p\]$',url).group(1)
                url = url.replace("/[" + find +"p]","")       
                dim = find
            except:
                dim = ""
                pass
    
    if res == "":
        
        ext = "." + url.split('.')[-1]
        if not ext in EXTV:
            ext = ".mp4"
        file = DFolder + name + ext
        
        fileS = file + ".stopped"
        fileR = file + ".resume"
    
    if not xbmcvfs.exists(fileS):
        
        title = localizedString(10203).encode('utf-8')
        string = common.GetKeyboardText(title, name)

        if len(string) >0:
            if url.find("https://drive.google.com/")>-1:
                from google_drive_downloader import GoogleDriveDownloader as gdd
                if url.find("open")>-1:
        
                    pattern = r"https?:\/\/drive\.google\.com\/open\?id=(\S+)"
                    replacement = r"https://drive.google.com/file/d/\$1/view"
                    url = re.sub(pattern, replacement, url)
                    url = url.replace("?usp=drive_open","")    
                
                try:
                    content = common.OpenURL(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
                    # ",[null,0,"7651396214"]
                    pattern = '",\[null,0,"(\d+)"\]'
                    dim = int(re.search(pattern,content).group(1))
                except:
                    if not dim == "":
                        find = find.replace("360p","").replace("480p","").replace("576p","").replace("720p","").replace("1080p","").replace("2160p","")
                        find = find.replace("H2","h2").replace("X2","x2").replace("x265","").replace("x245","").replace("h265","").replace("h264","")
                        find = find.replace("5.1-","").replace("2.1-","").replace("2.0-","").replace("7.1-","").replace("6.0-","")
                        finds = re.findall(r"[-+]?\d*\.\d+|\d+", dim)
                        dim = int(float(finds[0])*1024*1024*1024)
                        if dim<0:
                            dim = dim * -1
                    
                idg = url.split("/")[-2]
                
                gdd.download_file_from_google_drive(file_id=idg, dest_path= DFolder + string + ext, resume=False, dim=dim)
            else:
                common.StartDowloader(url,string,mode,DFolder)
    else:
        if url.find("https://drive.google.com/")>-1:
            from google_drive_downloader import GoogleDriveDownloader as gdd
            idg = url.split("/")[-2]
            
            try:
                xbmcvfs.rename(fileS,fileR)
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(name, localizedString(10211).encode('utf-8'), 5000, icon))
                xbmc.executebuiltin("XBMC.Container.Refresh()")
                gdd.download_file_from_google_drive(file_id=idg, dest_path= DFolder + name + ext, resume=True)
            except:
                pass
        
        else:
            common.StartDowloader(url,name,mode,DFolder)
        
elif mode == 59:   
    common.StartDowloader(url,name,mode,DFolder)                 
elif mode == 57 or mode == 72:   
    common.StopDowloader(url,name,mode,DFolder)
elif mode == 58 or mode == 71:   
    common.DeletePartialDowload(url,name,mode,DFolder)
elif mode == 10:
    # deleted
    sys.exit()
elif mode == 20:
    AddNewList()
    sys.exit()
elif mode == 21 or mode == 54 or mode == 60 or mode == 64:
    PMFolder( url )
elif mode == 22:
    RemoveFromLists(url)
elif mode == 23:
    ChangeName(name,playlistsFile2,"name",10004)
elif mode == 24:
    ChangeUrl(url,playlistsFile2,"url",10005)
elif mode == 61:
    ChangeName(name,playlistsFile4,"name",10004)
elif mode == 95:    
    ChangeUrl2(url,playlistsFile4,"url",10005)
elif mode == 69:
    ChangeName(name,favoritesFile,"name",10004)
elif mode == 25:
    importList()
elif mode == 26:
    if os.path.isfile( playlistsFile3 ) :
        if os.path.isfile( playlistsFile2 ) : os.remove( playlistsFile2 )
        shutil.copyfile( playlistsFile3, playlistsFile2 )
        xbmc.sleep ( 200 )
        os.remove( playlistsFile3 )
        xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,localizedString(10125).encode('utf-8'), 3600, icon)) 
    else:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,localizedString(10126).encode('utf-8'), 3600, icon))
elif mode == 30:
    ListFavorites()
elif mode == 31: 
    AddFavorites(url, iconimage, name)
elif mode == 55:
    RemoveDirFromLists(url,name)
elif mode == 56:
    os.remove( os.path.join(pwdir, base64.standard_b64encode(url))) 
    xbmc.executebuiltin("XBMC.Container.Refresh()")
elif mode == 33:
    RemoveFavorties(url)
elif mode == 34:
    AddNewFavortie()
elif mode == 35:
    ListSub(Italian)
elif mode == 36:
    ListSub(French)
elif mode == 37:
    ListSub(German)
elif mode == 38:
    ListSub(English)
elif mode == 200:
    ListSub(Sexy)
elif mode == 39:
    PM_index()
elif mode == 40:
    common.DelFile(playlistsFile2)
    sys.exit()
elif mode == 41:
    common.DelFile(favoritesFile)
    sys.exit()
elif mode == 42:
    write_xml()
    sys.exit()
elif mode == 43:
    restore_xml()
    sys.exit()   
elif mode == 44:
    remove_xml()
    sys.exit()
elif mode == 45:        
    clean_cache()
    sys.exit()
elif mode == 46:       
    checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,0)
    if Addon.getSetting('autoupdate') == "true":
        common.write_file(Tfile , '*')        
    sys.exit()
elif mode == 47:
    xbmc.executebuiltin("StopPVRManager")
    xbmc.executebuiltin("StartPVRManager") 
    sys.exit()
elif mode == 48:
    common.Open_Netflix()        
elif mode == 49:
    common.Open_Paypal()
elif mode == 50:
    print '--- Playing "{0}". {1}'.format(name, url)
    listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
    listitem.setInfo(type="Video", infoLabels={ "Title": name })
    xbmc.Player().play( url , listitem)
elif mode == 52:
    common.DeleteFile(url,name)
    ext = "." + url.split('.')[-1]
    if ext == ".strm":
        return_value = xbmcgui.Dialog().yesno(localizedString(10167).encode('utf-8'),localizedString(10168).encode('utf-8'))
        if not return_value == 0:
            xbmc.executebuiltin('XBMC.CleanLibrary(video)')
elif mode == 53:
    string = common.GetKeyboardText(localizedString(10203).encode('utf-8'), name)
    if len(string) < 1:
        sys.exit()
    else:
        nurl = url.replace(name,string)
        xbmcvfs.rename(os.path.join(url) ,os.path.join(nurl))
        xbmc.executebuiltin("XBMC.Container.Refresh()")
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(name, localizedString(10202).encode('utf-8'), 5200, icon))
        sys.exit()
elif mode == 62:
    cook = os.path.join(addonDir,'resources','cookie.dat')
    if os.path.isfile(cook):
        os.remove(cook)
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ","Teleboy cookie has been deleted!", 4700, icon))
    sys.exit()
elif mode == 65 or mode == 81:
    title = localizedString(10250).encode('utf-8')
    string = common.GetKeyboardText(title, "")
    if len(string) >0:
        string = string.lower()
        if url == "search1":
            sch_global(string)
        elif url == "search2":
            sch_global_PM(string)
        elif url == "search3":    
            sch_index(string)
        elif mode == 81:
            findm3u(url, string)
        else:
            sch_folder(url,string)
elif mode == 66:
    title = localizedString(10250).encode('utf-8')
    string = common.GetKeyboardText(title, "")
    if len(string) >0:
        sch_xml(url,string)
    else:
        sys.exit()
elif mode == 73:
    sch_filmtvit(url,live=True)
#elif mode == 76:
    #sch_global(name,live=False)
elif mode == 67:
    sch_exclude(url, playlistsFile4, "yes")
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ","Folder " + name + " to global research excluded!", 4000, icon))
    sys.exit()
elif mode == 68:
    sch_exclude(url, playlistsFile4, "")
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ","Folder " + name + " to global research included!", 4000, icon))
    sys.exit()
elif mode == 74:
    tvoggi(url)
elif mode == 75:    
    SetteGiorniTV(url)
elif mode == 77:
    sexy_one(url)
    xbmc.executebuiltin("Container.SetViewMode(500)")

##########################
# Teleboy

elif mode == 27:
    from teleboy import *
    try:
        json = get_videoJson( station)
        if not json:
            exit( 1)

        title = json["data"]["epg"]["current"]["title"]
        url = json["data"]["stream"]["url"]
        if not url: 
            exit( 1)
        img = get_stationLogoURL( station )
        Player = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('player')
        if  Addon.getSetting('player') == "true":
            play_url2( url, title, img )  
        else:
            play_url( url, title, img )
    except:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, "Swiss IP needed. Your bags ready!", 3600, icon))
elif mode == 28:
    from teleboy import *
    show_recordings()
    #make_list()
elif mode == 29:
    from teleboy import *
    url = "stream/record/%s" % rec_id
    json    = fetchApiJson( user_id, url)
    title = json["data"]["record"]["title"]
    url   = json["data"]["stream"]["url"]
    img = REC_ICON
    play_url( url, title, img )
elif mode == 79:
    findm3u(url)
elif mode == 80:
    import control
elif mode == 90:
    TestCheck = ""
    TestCheck = common.find_lpanel(url)

    if not TestCheck == "":
        
        panel =  common.OpenURL(TestCheck,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko'})
        
        s = common.find_param('"status" *: *"([^",]+)',panel)
        if s == "":
            s = "unknown"
        status = "Status : " + s
        
        try:
            exp_date = "Exp. date : " + str(time.ctime(int(common.find_param('"exp_date" *: *"([^",]+)',panel))))
        except:
            exp_date = "Exp. date : unknown"
        try:    
            created_at = "Created at : " + str(time.ctime(int(common.find_param('"created_at" *: *"([^",]+)',panel))))
        except:
            created_at = "Created at : unknown"
            
        active_cons = "Active connections : " + common.find_param('"active_cons" *: *"([^",]+)',panel)
        max_connections = "Max connections : " + common.find_param('"max_connections" *: *"([^",]+)',panel) 
        
        Line = status + "\n" + created_at + "\n" + exp_date + "\n" + max_connections + " - " + active_cons
        
        common.OKmsg(name,Line)
elif mode == 91:
    zip_PM_data()
elif mode == 92:
    unzip_PM_data()
elif mode == 93 or mode == 98:
    Yplayl(url)
elif mode == 94:
    TempName = base64.standard_b64encode(url)
    tmp = os.path.join(cdir, TempName)
    if os.path.isfile(tmp):
        common.DelFile(tmp)
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('[COLOR yellow]' +name + '[/COLOR]', 'Cache file was deleted!', 4000, icon))
        xbmc.executebuiltin("XBMC.Container.Refresh()")

elif mode == 300 or mode == 302:
    
    if url == "addlib":
        
        name = ""
        url = ""
        
        title = localizedString(10170).encode('utf-8')
        string = common.GetKeyboardText(title, "")
        if len(string) >0:
            name = str(string).encode("utf-8")
        if not name == "":
            title = localizedString(10171).encode('utf-8')
            string = common.GetKeyboardText(title, "")
            if len(string) >0:
                url = str(string).encode("utf-8")
    
    if not name == "" and not url == "" and not LFolder == "":
        name = common.BBTagRemove(name).replace(" [HD-4K]","")
        url = url.replace("+%5BHD-4K%5D.xml&",".xml&")
        Lw = os.path.join(LFolder , name.replace("?"," ") + ".strm")
        f = xbmcvfs.File(Lw, 'w')
        #f.write('plugin://plugin.video.kodilivetv/' + url)
        
        url = "?url=" + urllib.quote_plus(url) + "&name=" + urllib.quote_plus(name) + "&mode=3"
        f.write('plugin://plugin.video.kodilivetv/' + url)
        
        f.close()
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(all, true)')
        xbmc.executebuiltin('XBMC.UpdateLibrary(video,' + LFolder + ')')
        xbmc.executebuiltin('XBMC.CleanLibrary(video)')    
    sys.exit()

elif mode == 303:
    if not name == "" and not url == "" and not LSFolder == "":
        name = common.BBTagRemove(name).replace(" [HD-4K]","")
        url = url.replace("+%5BHD-4K%5D.xml&",".xml&")
        LW = os.path.join(LSFolder , name, "")
        if not xbmcvfs.exists(LW):
            xbmcvfs.mkdir(LW)
        
        data = common.OpenURL(url+"&type=xml")
        try:
            data64 = base64.decodestring(data)
            if data64.find("<data>")>-1:
                data = data64
        except:
            pass 

        data = xmlClean(data)
        #xbmc.log("Data -->" + data, xbmc.LOGNOTICE)  
        
        from xml.dom import minidom
        xmldoc = minidom.parseString(data)        
        items = xmldoc.getElementsByTagName('item')
        
        countS = 0
        ep= 0
        nep = 0
        
        for item in items:
            nep = nep + 1
            if item.getElementsByTagName("year"):
                
                pas = 0
                
                for node in item.getElementsByTagName("year"):
                    if not node.getAttribute('type'):
                        pas = 1
                        ep = 0
                
                for link in item.getElementsByTagName("link"):
                    if link.firstChild and 'extendedinfo' in link.firstChild.data:
                        pas = 0
                        break
                if pas == 1:
                    countS = countS + 1
            else:        
                ep = ep + 1
                EpName = 's' + str(countS) + 'e' + str(ep)
                Lw = os.path.join(LW , EpName + '.strm')
                f = xbmcvfs.File(Lw, 'w')
                urlx = "?url=" + urllib.quote_plus(url + "&t=" + str(nep)) + "&name=" + urllib.quote_plus(name) + "&mode=3"
                f.write('plugin://plugin.video.kodilivetv/' + urlx)
                f.close()
        
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(all, true)')
        xbmc.executebuiltin('XBMC.UpdateLibrary(video,' + LSFolder + ')')
        xbmc.executebuiltin('XBMC.CleanLibrary(video)')  
        
        sys.exit()
        
elif mode == 301:
    url = common.ReadFile(url)
    xbmc.executebuiltin('RunPlugin('+url+')')
elif mode == 400:
    sys.exit()
elif mode == 99999:
    import linkschecker
    linkschecker.check_links_thread()
    sys.exit()
###########################
#end directory
xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
